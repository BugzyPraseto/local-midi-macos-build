#!/bin/bash
set -euo pipefail
task_root="$(cd "$(dirname "$0")" && pwd)"
if /bin/bash "$task_root/BuildMac.sh" "$@"; then
    printf '\n%s\n' 'Build finished. The installer is in dist/macOS.'
else
    task_status=$?
    printf '\n%s\n' 'The build did not finish; read the error above. No installer was installed.' >&2
    if [[ -t 0 ]]; then read -r -p 'Press Return to close this window. ' _; fi
    exit "$task_status"
fi
if [[ -t 0 ]]; then read -r -p 'Press Return to close this window. ' _; fi
