from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
import re
import uuid
import subprocess
from functools import lru_cache

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator

from .audio_io import prepare_audio
from .backends import available_models
from .jobs import JobManager, write_json
from .midi_io import midi_bytes, read_midi
from .paths import DATA, STATIC, ROOT, initialize
from .runtime import module_command

initialize()
manager = JobManager()


@asynccontextmanager
async def lifespan(app):
    # A server restart cannot resume a model process from an old job.
    for path in (DATA / "jobs").glob("*/status.json"):
        status = json.loads(path.read_text(encoding="utf-8"))
        if status.get("state") in ("queued", "running"):
            write_json(path, {**status, "state": "interrupted", "message": "Interrupted by server restart"})
    yield
    manager.shutdown()


app = FastAPI(title="Local MIDI", lifespan=lifespan)


@app.get("/api/health")
def health():
    # Cheap startup handshake for native clients; never initializes CUDA.
    return {"application": "localmidi", "native_protocol": 1,
            "root": str(ROOT), "data": str(DATA), "pid": os.getpid()}


def safe_id(value):
    if not re.fullmatch(r"[a-f0-9]{32}", value):
        raise HTTPException(404, "Unknown item")
    return value


def job_directory(job_id):
    path = DATA / "jobs" / safe_id(job_id)
    if not path.is_dir():
        raise HTTPException(404, "Unknown transcription")
    return path


@app.get("/api/status")
def status():
    return {"models": available_models(), "hardware": hardware(),
            "privacy": "All transcription stays on this computer."}


@lru_cache(maxsize=1)
def hardware():
    try:
        process = subprocess.run(module_command("localmidi.probe"), cwd=ROOT,
                                 capture_output=True, text=True, timeout=30,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if process.returncode == 0:
            return json.loads(process.stdout.strip().splitlines()[-1])
    except (subprocess.SubprocessError, ValueError):
        pass
    return {"cuda": False, "gpu_name": None, "vram_gib": None,
            "message": "GPU detection failed; CPU processing is available."}


@app.get("/api/audio")
def list_audio():
    items = []
    for path in sorted((DATA / "audio").glob("*/metadata.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        item = json.loads(path.read_text(encoding="utf-8"))
        items.append({key: value for key, value in item.items() if key != "peaks"})
    return items


@app.post("/api/audio")
def upload_audio(file: UploadFile = File(...)):
    audio_id = uuid.uuid4().hex
    directory = DATA / "audio" / audio_id
    directory.mkdir(parents=True)
    suffix = Path(file.filename or "audio.wav").suffix.lower()
    if suffix not in (".wav", ".mp3", ".flac", ".aif", ".aiff", ".ogg", ".m4a", ".aac"):
        raise HTTPException(400, "Supported audio: WAV, MP3, FLAC, AIFF, OGG, M4A, AAC")
    source = directory / ("upload" + suffix)
    size = 0
    with source.open("wb") as output:
        while chunk := file.file.read(1024 * 1024):
            size += len(chunk)
            if size > 300 * 1024 * 1024:
                raise HTTPException(413, "Maximum audio file size is 300 MB")
            output.write(chunk)
    try:
        metadata = {**prepare_audio(source, directory), "id": audio_id,
                    "name": Path(file.filename or "audio").name}
    except Exception as error:
        raise HTTPException(400, str(error)) from error
    write_json(directory / "metadata.json", metadata)
    return metadata


@app.get("/api/audio/{audio_id}")
def get_audio(audio_id: str):
    path = DATA / "audio" / safe_id(audio_id) / "metadata.json"
    if not path.exists():
        raise HTTPException(404, "Unknown audio")
    return json.loads(path.read_text(encoding="utf-8"))


class CaptureImport(BaseModel):
    name: str = Field(default="DAW capture.wav", min_length=1, max_length=256)
    host_start_seconds: float = Field(default=0, ge=-86400, le=86400, allow_inf_nan=False)


@app.post("/api/native/captures/{capture_id}/import")
def import_native_capture(capture_id: str, request: CaptureImport):
    capture_id = safe_id(capture_id)
    directory = DATA / "audio" / capture_id
    metadata_path = directory / "metadata.json"
    if metadata_path.exists():
        current = json.loads(metadata_path.read_text(encoding="utf-8"))
        if current.get("capture_id") != capture_id:
            raise HTTPException(409, "Capture identifier is already in use")
        return current
    capture_root = (DATA / "native-captures").resolve()
    source = capture_root / (capture_id + ".wav")
    if not source.is_file() or source.is_symlink() or not source.resolve().is_relative_to(capture_root):
        raise HTTPException(404, "Native capture does not exist")
    directory.mkdir(parents=True, exist_ok=True)
    try:
        metadata = {**prepare_audio(source, directory), "id": capture_id,
                    "name": Path(request.name).name, "capture_id": capture_id,
                    "host_start_seconds": request.host_start_seconds, "origin": "native_capture"}
    except Exception as error:
        raise HTTPException(400, str(error)) from error
    write_json(metadata_path, metadata)
    return metadata


@app.get("/api/audio/{audio_id}/source.wav")
def source_audio(audio_id: str):
    path = DATA / "audio" / safe_id(audio_id) / "source.wav"
    if not path.exists():
        raise HTTPException(404, "Unknown audio")
    return FileResponse(path, media_type="audio/wav")


class TranscriptionRequest(BaseModel):
    audio_id: str
    instrument: str
    backend: str
    device: str = "auto"


@app.post("/api/jobs")
def create_job(request: TranscriptionRequest):
    get_audio(request.audio_id)
    model = next((item for item in available_models() if item["id"] == request.backend), None)
    if not model or not model["ready"] or request.instrument not in model["instruments"]:
        raise HTTPException(400, "Choose an installed model for the selected instrument")
    if request.device not in ("auto", "cpu", "cuda"):
        raise HTTPException(400, "Unknown compute device")
    return {"id": manager.create(request.model_dump())}


@app.get("/api/jobs")
def list_jobs(audio_id: str):
    safe_id(audio_id)
    results = []
    for path in (DATA / "jobs").glob("*/request.json"):
        request = json.loads(path.read_text(encoding="utf-8"))
        if request["audio_id"] == audio_id:
            results.append(manager.get(path.parent.name))
    return sorted(results, key=lambda x: x["created"], reverse=True)


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    job_directory(job_id)
    return manager.get(job_id)


@app.post("/api/jobs/{job_id}/cancel")
def cancel_job(job_id: str):
    job_directory(job_id)
    if manager.get(job_id)["state"] in ("queued", "running"):
        manager.cancel(job_id)
    return {"ok": True}


@app.get("/api/jobs/{job_id}/result")
def result(job_id: str):
    directory = job_directory(job_id)
    path = directory / "edited.json"
    if not path.exists():
        path = directory / "result.json"
    if not path.exists():
        raise HTTPException(409, "Transcription is not complete")
    return json.loads(path.read_text(encoding="utf-8"))


class Note(BaseModel):
    id: str
    start: float = Field(ge=0, allow_inf_nan=False)
    end: float = Field(gt=0, allow_inf_nan=False)
    pitch: int = Field(ge=0, le=127)
    velocity: int = Field(ge=1, le=127)
    track: int = Field(default=0, ge=0, le=255)
    program: int = Field(default=0, ge=0, le=127)
    is_drum: bool = False

    @model_validator(mode="after")
    def positive_duration(self):
        if self.end <= self.start:
            raise ValueError("Note end must follow its start")
        return self


class NoteEdit(BaseModel):
    notes: list[Note] = Field(max_length=100000)


@app.put("/api/jobs/{job_id}/notes")
def save_notes(job_id: str, edit: NoteEdit):
    current = result(job_id)
    current["notes"] = [note.model_dump() for note in edit.notes]
    current["edited"] = True
    write_json(job_directory(job_id) / "edited.json", current)
    return {"ok": True, "count": len(edit.notes)}


@app.post("/api/jobs/{job_id}/restore")
def restore(job_id: str):
    directory = job_directory(job_id)
    raw = directory / "result.json"
    if not raw.exists():
        raise HTTPException(409, "No raw prediction exists")
    write_json(directory / "edited.json", json.loads(raw.read_text(encoding="utf-8")))
    return result(job_id)


@app.get("/api/jobs/{job_id}/prediction")
def original_prediction(job_id: str):
    raw = job_directory(job_id) / "result.json"
    if not raw.exists():
        raise HTTPException(409, "No raw prediction exists")
    return json.loads(raw.read_text(encoding="utf-8"))


class ExportRequest(NoteEdit):
    bpm: float = Field(default=120, ge=20, le=400, allow_inf_nan=False)
    quantize: bool = False
    subdivision: int = 16
    selection_only: bool = False
    start_at_first_note: bool = False


@app.post("/api/jobs/{job_id}/export")
def export(job_id: str, request: ExportRequest):
    current = result(job_id)
    try:
        content = midi_bytes([note.model_dump() for note in request.notes], current["controls"],
                             current["pitch_bends"], bpm=request.bpm, quantize=request.quantize,
                             subdivision=request.subdivision, selection_only=request.selection_only,
                             start_at_first_note=request.start_at_first_note)
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    return Response(content, media_type="audio/midi",
                    headers={"Content-Disposition": 'attachment; filename="transcription.mid"'})


@app.get("/api/jobs/{job_id}/raw.mid")
def raw_midi(job_id: str):
    path = job_directory(job_id) / "raw.mid"
    if not path.exists():
        raise HTTPException(404, "No raw MIDI available")
    return FileResponse(path, media_type="audio/midi", filename="original-prediction.mid")


@app.post("/api/audio/{audio_id}/reference")
def import_reference(audio_id: str, file: UploadFile = File(...), instrument: str = Form("piano")):
    get_audio(audio_id)
    if instrument not in ("piano", "guitar"):
        raise HTTPException(400, "Unknown instrument")
    job_id = uuid.uuid4().hex
    directory = DATA / "jobs" / job_id
    directory.mkdir()
    content = file.file.read(20 * 1024 * 1024 + 1)
    if len(content) > 20 * 1024 * 1024:
        raise HTTPException(413, "MIDI file is too large")
    (directory / "raw.mid").write_bytes(content)
    try:
        parsed = read_midi(directory / "raw.mid")
    except Exception as error:
        raise HTTPException(400, "Invalid MIDI file") from error
    request = {"id": job_id, "audio_id": audio_id, "backend": "reference", "instrument": instrument,
               "created": directory.stat().st_mtime, "label": Path(file.filename or "Reference MIDI").name}
    # Use the same string sort key as transcription jobs.
    from datetime import datetime, timezone
    request["created"] = datetime.now(timezone.utc).isoformat()
    write_json(directory / "request.json", request)
    write_json(directory / "status.json", {"state": "complete", "progress": 1, "message": "Imported reference MIDI"})
    write_json(directory / "result.json", {**parsed, **request, "elapsed": 0, "metadata": {"imported": True}})
    return {"id": job_id}


app.mount("/", StaticFiles(directory=STATIC, html=True), name="ui")
