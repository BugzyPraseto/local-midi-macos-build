"""Shared CPU/CUDA adapter for the pinned Aria model.

Uses upstream cached attention with device-aware cache construction. Keeps FP32,
the author's mel transform and event decoder. No training-time augmentation.
"""
import hashlib
import math
import sys

from .paths import MODELS


def add_vendor_paths():
    for directory in (MODELS / "vendors/aria-amt", MODELS / "vendors/aria-utils"):
        sys.path.insert(0, str(directory))


def setup_cache(model, device):
    import torch
    from amt.inference.model import KVCache
    decoder = model.decoder
    decoder.causal_mask = torch.tril(torch.ones(4096, 4096, dtype=torch.bool, device=device))
    for block in decoder.blocks:
        for attention, length in ((block.attn, 4096), (block.cross_attn, 1500)):
            attention.kv_cache = KVCache(1, length, decoder.n_head,
                                         decoder.n_state // decoder.n_head,
                                         dtype=torch.float32).to(device)


def refine_token(logits):
    import torch
    logits[:, 389] *= 1.05
    selected = logits.argmax(dim=-1)
    index = int(selected.item())
    if 392 <= index <= 3418:
        low, high = max(392, index - 2), min(3418, index + 2)
        indices = torch.arange(low, high + 1, device=logits.device)
        probabilities = torch.softmax(logits[:, low:high + 1], dim=-1)
        index = int((probabilities * indices).sum().round().item())
    return index


def decode_window(model, features, prefix, tokenizer, on_tokens=None):
    import torch
    device = features.device
    setup_cache(model, device)
    ids = tokenizer.encode(prefix)
    if len(ids) >= 4095:
        raise RuntimeError("Aria's musical context is full. Try a shorter or less dense recording.")
    positions = torch.arange(len(ids), device=device)
    audio_positions = torch.arange(features.shape[1], device=device)
    current = torch.tensor([ids], dtype=torch.long, device=device)
    for index in range(len(ids), 4095):
        logits = model.decoder(current, features, positions, audio_positions)[:, -1]
        if not torch.isfinite(logits).all():
            raise RuntimeError("Aria returned non-finite predictions.")
        next_id = refine_token(logits)
        if next_id == 1:
            break
        if next_id >= 2418:
            # Upstream rejects the preceding event-type token with a >20s onset.
            ids = ids[:-1]
            break
        ids.append(next_id)
        current = torch.tensor([[next_id]], dtype=torch.long, device=device)
        positions = torch.tensor([index], dtype=torch.long, device=device)
        audio_positions = torch.empty(0, dtype=torch.long, device=device)
        if on_tokens and index % 32 == 0:
            on_tokens(index)
    else:
        raise RuntimeError("Aria reached its 4096-token limit. The partial take was not marked complete.")
    return tokenizer.decode(ids)


def truncate_prefix(sequence, tokenizer):
    midi = tokenizer.detokenize(sequence, 30000)
    if not midi.note_msgs:
        return [tokenizer.bos_tok]
    prefix = tokenizer.tokenize(midi, 10000, 19999)
    if prefix and prefix[-1] == tokenizer.eos_tok:
        prefix.pop()
    return prefix or [tokenizer.bos_tok]


def transcribe_aria(audio_path, output_path, device, progress):
    add_vendor_paths()
    import numpy as np
    import soundfile as sf
    import soxr
    import torch
    from safetensors.torch import load_file
    from amt.config import load_model_config
    from amt.inference.model import ModelConfig, AmtEncoderDecoder
    from amt.tokenizer import AmtTokenizer
    from amt.audio import AudioTransform, pad_or_trim
    from amt.inference.transcribe import _get_silent_intervals, _process_silent_intervals

    tokenizer = AmtTokenizer()
    if tokenizer.vocab_size != 3419 or tokenizer.tok_to_id[("pedal", 0)] != 389:
        raise RuntimeError("Aria tokenizer does not match the pinned decoder.")
    config = ModelConfig(**load_model_config("medium-double"))
    config.set_vocab_size(tokenizer.vocab_size)
    model = AmtEncoderDecoder(config)
    path = MODELS / "aria-piano-medium-double-1.0.safetensors"
    checkpoint = load_file(str(path), device="cpu")
    weights = {key.removeprefix("_orig_mod."): value for key, value in checkpoint.items()}
    model.load_state_dict(weights, strict=True)
    del checkpoint, weights
    model = model.eval().to(device=device, dtype=torch.float32)
    transform = AudioTransform().eval().to(device)
    samples, rate = sf.read(audio_path, dtype="float32", always_2d=True)
    mono = samples.mean(axis=1)
    if rate != 16000:
        mono = soxr.resample(mono, rate, 16000)
    duration = len(mono) / 16000
    # Each first window commits 20s; subsequent windows add 10s. Include the tail.
    windows = max(1, 1 + math.ceil(max(0, duration - 20) / 10))
    prefix = [tokenizer.bos_tok]
    complete_sequence = [tokenizer.bos_tok]
    with torch.inference_mode():
        for index in range(windows):
            base = index * 10
            progress(.12 + .82 * index / windows, f"Aria piano · window {index + 1}/{windows}")
            segment = pad_or_trim(torch.from_numpy(np.ascontiguousarray(mono[index * 160000:index * 160000 + 480000])))
            silent_intervals = _get_silent_intervals(segment)
            features = model.encoder(transform.log_mel(segment[None].to(device)))
            sequence = decode_window(model, features, prefix, tokenizer,
                                     lambda count: progress(.12 + .82 * index / windows,
                                                            f"Aria piano · window {index + 1}/{windows} · {count} tokens"))
            if silent_intervals:
                # Preserve the author's suppression of attacks inside long
                # silent intervals, using the matching pinned helper directly.
                sequence = _process_silent_intervals(sequence, silent_intervals, tokenizer)
            if sequence and sequence[-1] == tokenizer.eos_tok:
                sequence = sequence[:-1]
            suffix = sequence[len(prefix):]
            complete_sequence.extend(("onset", token[1] + base * 1000)
                                     if isinstance(token, tuple) and token[0] == "onset" else token
                                     for token in suffix)
            if index + 1 < windows:
                prefix = truncate_prefix(sequence, tokenizer)
    midi_dict = tokenizer.detokenize(complete_sequence, max(1, round(duration * 1000)))
    midi_dict.remove_redundant_pedals()
    midi = midi_dict.to_midi()
    midi.save(str(output_path))
    # Crop predictions on padded context to the actual source duration.
    import pretty_midi
    parsed = pretty_midi.PrettyMIDI(str(output_path))
    for instrument in parsed.instruments:
        instrument.notes = [note for note in instrument.notes if note.start < duration]
        for note in instrument.notes:
            note.end = min(note.end, duration)
        instrument.notes = [note for note in instrument.notes if note.end > note.start]
        instrument.control_changes = [event for event in instrument.control_changes if event.time <= duration]
    parsed.write(str(output_path))
    return {"model": "Aria-AMT preliminary piano v1 / medium-double", "device": device,
            "precision": "float32", "adapter": "device-aware cached decoding; 30s context / 10s stride",
            "checkpoint_sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
