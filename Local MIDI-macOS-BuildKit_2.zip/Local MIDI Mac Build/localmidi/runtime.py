"""Use the bundled interpreter without depending on a DAW's Python environment."""
from pathlib import Path
import sys


def module_command(module, *arguments):
    if sys.platform == "darwin":
        entry = Path(__file__).resolve().parents[1] / "engine.py"
        return [sys.executable, "-I", "-B", str(entry), module.rsplit(".", 1)[-1], *map(str, arguments)]
    return [sys.executable, "-m", module, *map(str, arguments)]
