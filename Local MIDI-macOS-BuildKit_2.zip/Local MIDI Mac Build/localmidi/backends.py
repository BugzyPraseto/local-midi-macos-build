"""Adapters preserve model output. No automatic note quantization or merging."""
from importlib.util import find_spec
import hashlib
import json
import os
from pathlib import Path
import sys

from .paths import MODELS
from .torch_compat import model_api


def available_models():
    return [
        {"id": "transkun", "name": "Transkun v2", "instruments": ["piano"],
         "ready": find_spec("transkun") is not None, "description": "Piano specialist · velocity and pedal"},
        {"id": "aria", "name": "Aria-AMT", "instruments": ["piano"],
         "ready": (MODELS / "aria-piano-medium-double-1.0.safetensors").is_file()
                  and (MODELS / "vendors/aria-amt/amt/model.py").is_file(),
         "description": "Piano specialist · contextual decoding"},
        {"id": "gaps", "name": "GAPS guitar", "instruments": ["guitar"],
         "ready": (MODELS / "guitar-gaps.pth").is_file()
                  and (MODELS / "vendors/gaps-inference/piano_transcription_inference/inference.py").is_file(),
         "description": "Guitar specialist · polyphonic note transcription"},
        {"id": "tsumugi", "name": "Tsumugi guitar v1.5", "instruments": ["guitar"],
         "ready": (MODELS / "tsumugi-guitar-v1.5.pth").is_file()
                  and (MODELS / "vendors/tsumugi/instrument_agnostic_amt").is_dir(),
         "description": "Guitar specialist · alternative event model"},
        {"id": "basic_pitch", "name": "Basic Pitch", "instruments": ["piano", "guitar"],
         "ready": find_spec("basic_pitch") is not None,
         "description": "Comparison baseline · pitch bends · CPU"},
    ]


def choose_device(requested):
    import torch
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is not available in this installation. Choose CPU or Auto.")
    return "cuda" if requested != "cpu" and torch.cuda.is_available() else "cpu"


def transcribe(request, audio_path, output_path, progress):
    backend = request["backend"]
    if backend == "basic_pitch":
        return _basic_pitch(audio_path, output_path, request["instrument"], progress)
    import torch
    torch.set_num_threads(min(8, os.cpu_count() or 4))
    torch.set_grad_enabled(False)
    device = choose_device(request.get("device", "auto"))
    with model_api(torch):
        if backend == "transkun":
            return _transkun(audio_path, output_path, device, progress)
        if backend == "aria":
            from .aria_adapter import transcribe_aria
            return transcribe_aria(audio_path, output_path, device, progress)
        if backend == "gaps":
            return _gaps(audio_path, output_path, device, progress)
        if backend == "tsumugi":
            return _tsumugi(audio_path, output_path, device, progress)
    raise ValueError("Unknown transcription model")


def _transkun(audio_path, output_path, device, progress):
    import importlib.resources
    import moduleconf
    import numpy as np
    import soundfile as sf
    import soxr
    import torch
    from transkun.Data import writeMidi

    resources = importlib.resources.files("transkun.pretrained")
    weight = Path(str(resources / "2.0.pt"))
    manager = moduleconf.parseFromFile(str(resources / "2.0.conf"))
    model = manager["Model"].module.TransKun(conf=manager["Model"].config).to(device)
    checkpoint = torch.load(weight, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint.get("best_state_dict", checkpoint.get("state_dict")), strict=True)
    model.eval()
    audio, rate = sf.read(audio_path, dtype="float32", always_2d=True)
    if rate != model.fs:
        audio = soxr.resample(audio, rate, model.fs)
    progress(0.15, "Transcribing piano · preserving timing, velocity and pedal")
    with torch.inference_mode():
        events = model.transcribe(torch.from_numpy(np.ascontiguousarray(audio)).to(device), discardSecondHalf=False)
    writeMidi(events).write(str(output_path))
    progress(0.98, "Preparing editable MIDI")
    return {"model": "Transkun 2.0.1 / bundled augmented V2", "device": device,
            "torch": torch.__version__, "checkpoint_sha256": hashlib.sha256(weight.read_bytes()).hexdigest(),
            "note_duration_convention": "key release with separate pedal controls"}


def _gaps(audio_path, output_path, device, progress):
    sys.path.insert(0, str(MODELS / "vendors/gaps-inference"))
    import numpy as np
    import soundfile as sf
    import soxr
    import pretty_midi
    import torch
    from piano_transcription_inference import PianoTranscription
    samples, rate = sf.read(audio_path, dtype="float32", always_2d=True)
    mono = samples.mean(axis=1)
    if rate != 16000:
        mono = soxr.resample(mono, rate, 16000)
    progress(0.12, "Loading the GAPS guitar specialist")
    weight = MODELS / "guitar-gaps.pth"
    model = PianoTranscription(model_type="Regress_onset_offset_frame_velocity_CRNN",
                               checkpoint_path=str(weight), device=device, batch_size=1)
    # The upstream loader uses strict=False. Validate the complete downloaded artifact.
    checkpoint = torch.load(weight, map_location=device, weights_only=False)
    network = model.model.module if hasattr(model.model, "module") else model.model
    network.load_state_dict(checkpoint["model"], strict=True)
    network.eval()
    progress(0.2, "Transcribing guitar chords and note attacks")
    with torch.inference_mode():
        result = model.transcribe(np.ascontiguousarray(mono), None)
    duration = len(mono) / 16000
    midi = pretty_midi.PrettyMIDI(initial_tempo=120)
    guitar = pretty_midi.Instrument(program=24)
    for event in result["est_note_events"]:
        start = max(0, float(event["onset_time"]))
        end = min(duration, float(event["offset_time"]))
        if start < end:
            guitar.notes.append(pretty_midi.Note(velocity=max(1, min(127, int(event["velocity"]))),
                                                 pitch=int(event["midi_note"]), start=start, end=end))
    midi.instruments.append(guitar)
    midi.write(str(output_path))
    return {"model": "GAPS guitar / author checkpoint", "device": device,
            "checkpoint_sha256": hashlib.sha256(weight.read_bytes()).hexdigest()}


def _basic_pitch(audio_path, output_path, instrument, progress):
    import importlib.resources
    # This worker deliberately uses ONNX, independent of any global TensorFlow install.
    sys.modules["tensorflow"] = None
    from basic_pitch.inference import predict
    weight = Path(str(importlib.resources.files("basic_pitch") / "saved_models/icassp_2022/nmp.onnx"))
    progress(.2, "Basic Pitch baseline · ONNX CPU inference")
    _, midi, _ = predict(str(audio_path), model_or_model_path=weight)
    for part in midi.instruments:
        part.program = 24 if instrument == "guitar" else 0
    midi.write(str(output_path))
    return {"model": "Basic Pitch 0.4.0 / ICASSP 2022 ONNX", "device": "cpu",
            "checkpoint_sha256": hashlib.sha256(weight.read_bytes()).hexdigest()}


def _tsumugi(audio_path, output_path, device, progress):
    sys.path.insert(0, str(MODELS / "vendors/tsumugi"))
    import torch
    from instrument_agnostic_amt.amt.cli.infer import (
        _load_model_and_settings, _load_audio, run_inference, _build_midi)
    weight = MODELS / "tsumugi-guitar-v1.5.pth"
    progress(.1, "Loading Tsumugi's guitar specialist")
    model, config, settings = _load_model_and_settings(weight, device=torch.device(device),
                                                       window_ms_override=None, stride_ms_override=None,
                                                       track_batch_size_override=1)
    waveform, _, _ = _load_audio(audio_path, target_sample_rate=config.sample_rate)
    progress(.2, "Transcribing guitar · full-precision event decoding")
    with torch.inference_mode():
        notes, stats, _ = run_inference(model=model, waveform=waveform, model_config=config,
                                        settings=settings, device=torch.device(device), amp_enabled=False,
                                        amp_dtype=torch.float32, window_batch_size=1)
    midi = _build_midi(notes, sample_rate=config.sample_rate)
    midi.write(str(output_path))
    return {"model": "Tsumugi guitar v1.5", "device": device, "precision": "float32",
            "velocity": "fixed export default; separate velocity network not enabled",
            "checkpoint_sha256": hashlib.sha256(weight.read_bytes()).hexdigest()}

