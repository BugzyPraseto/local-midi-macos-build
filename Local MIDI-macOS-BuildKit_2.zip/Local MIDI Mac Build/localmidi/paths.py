from pathlib import Path
import os
import sys

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = Path.home() / "Library/Application Support/Local MIDI" if sys.platform == "darwin" else ROOT / ".local"
DATA = Path(os.environ.get("LOCALMIDI_DATA", DEFAULT_DATA)).expanduser().resolve()
MODELS = Path(os.environ.get("LOCALMIDI_MODELS", ROOT / ".models")).expanduser().resolve()
STATIC = ROOT / "static"

def initialize():
    for directory in (DATA / "audio", DATA / "jobs"):
        directory.mkdir(parents=True, exist_ok=True)
    # The installed Mac engine and its verified models are immutable shared files.
    if sys.platform != "darwin" or "LOCALMIDI_MODELS" in os.environ:
        MODELS.mkdir(parents=True, exist_ok=True)

