"""One cancellable model process at a time, with persisted job records."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
import os
import signal
import subprocess
import threading
import time
import uuid

from .paths import DATA, ROOT
from .runtime import module_command


def write_json(path, value):
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)


def terminate_process_tree(process):
    """The Windows venv redirector can own a second, real Python process.

    Killing only the redirector leaves inference running and can overlap the
    next GPU job. Terminate its entire tree before releasing the queue slot.
    """
    if process.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                       capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW,
                       timeout=15)
    else:
        # Workers own a new session; include any inference descendants in cancellation.
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            pass
        # A descendant can ignore SIGTERM even after the session leader exits.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


class JobManager:
    def __init__(self):
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="transcription")
        self.processes = {}
        self.cancelled = set()
        self.lock = threading.Lock()

    def create(self, request):
        job_id = uuid.uuid4().hex
        directory = DATA / "jobs" / job_id
        directory.mkdir(parents=True)
        request = {**request, "id": job_id, "created": datetime.now(timezone.utc).isoformat()}
        write_json(directory / "request.json", request)
        write_json(directory / "status.json", {"state": "queued", "progress": 0,
                                               "message": "Waiting for the transcription worker"})
        self.executor.submit(self._run, job_id)
        return job_id

    def _run(self, job_id):
        directory = DATA / "jobs" / job_id
        with self.lock:
            if job_id in self.cancelled:
                return
            log = (directory / "worker.log").open("w", encoding="utf-8")
            process = subprocess.Popen(module_command("localmidi.worker", job_id),
                                       cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                       start_new_session=os.name != "nt",
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            self.processes[job_id] = process
        code = process.wait()
        log.close()
        with self.lock:
            self.processes.pop(job_id, None)
            if job_id in self.cancelled:
                write_json(directory / "status.json", {"state": "cancelled", "progress": 0,
                                                       "message": "Transcription cancelled"})
                return
        if code and self.get(job_id)["state"] not in ("error", "cancelled"):
            write_json(directory / "status.json", {"state": "error", "progress": 0,
                                                   "message": "The model worker stopped. See its local log."})

    def get(self, job_id):
        directory = DATA / "jobs" / job_id
        request = json.loads((directory / "request.json").read_text(encoding="utf-8"))
        status = json.loads((directory / "status.json").read_text(encoding="utf-8"))
        if status.get("state") == "running" and status.get("started_at"):
            status["elapsed"] = max(0, time.time() - status["started_at"])
        return {**request, **status}

    def cancel(self, job_id):
        directory = DATA / "jobs" / job_id
        with self.lock:
            self.cancelled.add(job_id)
            process = self.processes.get(job_id)
            if process and process.poll() is None:
                terminate_process_tree(process)
            else:
                write_json(directory / "status.json", {"state": "cancelled", "progress": 0,
                                                       "message": "Transcription cancelled"})

    def shutdown(self):
        with self.lock:
            for job_id, process in self.processes.items():
                self.cancelled.add(job_id)
                if process.poll() is None:
                    terminate_process_tree(process)
        self.executor.shutdown(wait=False, cancel_futures=True)

