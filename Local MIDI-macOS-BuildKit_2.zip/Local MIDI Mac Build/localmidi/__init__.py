"""Local audio transcription workbench."""

