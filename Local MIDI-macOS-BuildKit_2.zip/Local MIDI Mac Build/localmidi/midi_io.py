"""Use seconds throughout editing; convert to MIDI ticks only at export."""
from collections import defaultdict
from io import BytesIO
import math
import uuid

import mido


def read_midi(path):
    import pretty_midi
    midi = pretty_midi.PrettyMIDI(str(path))
    notes, controls, bends = [], [], []
    for track, instrument in enumerate(midi.instruments):
        for note in instrument.notes:
            notes.append({"id": uuid.uuid4().hex, "start": float(note.start), "end": float(note.end),
                          "pitch": int(note.pitch), "velocity": int(note.velocity),
                          "track": track, "program": int(instrument.program),
                          "is_drum": bool(instrument.is_drum)})
        for control in instrument.control_changes:
            controls.append({"time": float(control.time), "number": int(control.number),
                             "value": int(control.value), "track": track})
        for bend in instrument.pitch_bends:
            bends.append({"time": float(bend.time), "pitch": int(bend.pitch), "track": track})
    return {"notes": sorted(notes, key=lambda n: (n["start"], n["pitch"])),
            "controls": controls, "pitch_bends": bends}


def _selection_events(notes, controls, pitch_bends, start_at_first_note):
    """Keep selected tracks, reconstruct controller state at the cut and retain pedal release."""
    if not notes:
        return [], [], []
    for note in notes:
        start, end = float(note["start"]), float(note["end"])
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start:
            raise ValueError("Every note needs a finite, positive duration.")
    beginning = min(float(note["start"]) for note in notes)
    offset = beginning if start_at_first_note else 0.0
    tracks = {note.get("track", 0) for note in notes}
    kept_controls, kept_bends = [], []
    for track in sorted(tracks):
        end = max(float(note["end"]) for note in notes if note.get("track", 0) == track)
        events = sorted((event for event in controls if event.get("track", 0) == track), key=lambda e: e["time"])
        pedal_down = False
        for event in events:
            if event["number"] == 64 and event["time"] <= end:
                pedal_down = event["value"] >= 64
        release = next((event for event in events if event["number"] == 64
                        and event["time"] > end and event["value"] < 64), None) if pedal_down else None
        if release is not None:
            end = float(release["time"])
        initial = {}
        for event in events:
            if event["time"] <= beginning:
                initial[event["number"]] = event
            elif event["time"] <= end:
                kept_controls.append({**event, "time": float(event["time"]) - offset})
        kept_controls.extend({**event, "time": beginning - offset} for event in initial.values())
        if pedal_down and release is None:
            kept_controls.append({"time": end - offset, "number": 64, "value": 0, "track": track})
        bends = sorted((event for event in pitch_bends if event.get("track", 0) == track), key=lambda e: e["time"])
        initial_bend = None
        for event in bends:
            if event["time"] <= beginning:
                initial_bend = event
            elif event["time"] <= end:
                kept_bends.append({**event, "time": float(event["time"]) - offset})
        if initial_bend is not None:
            kept_bends.append({**initial_bend, "time": beginning - offset})
        final_bend = next((event for event in reversed(bends) if event["time"] <= end), None)
        if final_bend is not None and final_bend["pitch"] != 0:
            kept_bends.append({"time": end - offset, "pitch": 0, "track": track})
    shifted = [{**note, "start": float(note["start"]) - offset,
                "end": float(note["end"]) - offset} for note in notes]
    return shifted, kept_controls, kept_bends


def midi_bytes(notes, controls=(), pitch_bends=(), *, bpm=120, quantize=False, subdivision=16,
               selection_only=False, start_at_first_note=False):
    if not math.isfinite(bpm) or not 20 <= bpm <= 400:
        raise ValueError("Tempo must be between 20 and 400 BPM.")
    if subdivision not in (4, 8, 12, 16, 24, 32):
        raise ValueError("Unsupported grid subdivision.")
    if selection_only:
        notes, controls, pitch_bends = _selection_events(notes, controls, pitch_bends, start_at_first_note)
    tempo = mido.bpm2tempo(bpm)
    ticks_per_beat = 960
    file = mido.MidiFile(type=1, ticks_per_beat=ticks_per_beat)
    conductor = mido.MidiTrack()
    conductor.extend([mido.MetaMessage("track_name", name="Local MIDI"),
                      mido.MetaMessage("set_tempo", tempo=tempo)])
    file.tracks.append(conductor)
    grouped = defaultdict(list)
    for note in notes:
        grouped[note.get("track", 0)].append(note)
    for event in (*controls, *pitch_bends):
        grouped.setdefault(event.get("track", 0), [])
    if not grouped:
        grouped[0] = []
    melodic_channels = [channel for channel in range(16) if channel != 9]
    step = 60 / bpm * 4 / subdivision
    for index, (track_id, track_notes) in enumerate(sorted(grouped.items())):
        track = mido.MidiTrack()
        first = track_notes[0] if track_notes else {}
        is_drum = first.get("is_drum", False)
        channel = 9 if is_drum else melodic_channels[index % len(melodic_channels)]
        program = int(first.get("program", 0))
        track.append(mido.MetaMessage("track_name", name=f"Part {track_id + 1}"))
        track.append(mido.Message("program_change", program=program, channel=channel))
        events = []
        for note in track_notes:
            start, end = float(note["start"]), float(note["end"])
            if not all(math.isfinite(value) for value in (start, end)) or start < 0 or end <= start:
                raise ValueError("Every note needs a finite, positive duration.")
            if quantize:
                start = round(start / step) * step
                end = max(start + step, round(end / step) * step)
            on = round(mido.second2tick(start, ticks_per_beat, tempo))
            off = max(on + 1, round(mido.second2tick(end, ticks_per_beat, tempo)))
            pitch, velocity = int(note["pitch"]), int(note.get("velocity", 80))
            if not 0 <= pitch <= 127 or not 1 <= velocity <= 127:
                raise ValueError("Pitch or velocity is out of range.")
            events.extend([(on, 2, mido.Message("note_on", note=pitch, velocity=velocity, channel=channel)),
                           (off, 0, mido.Message("note_off", note=pitch, velocity=0, channel=channel))])
        for event in controls:
            if event.get("track", 0) == track_id:
                tick = round(mido.second2tick(max(0, event["time"]), ticks_per_beat, tempo))
                events.append((tick, 1, mido.Message("control_change", control=event["number"],
                                                    value=event["value"], channel=channel)))
        for event in pitch_bends:
            if event.get("track", 0) == track_id:
                tick = round(mido.second2tick(max(0, event["time"]), ticks_per_beat, tempo))
                events.append((tick, 1, mido.Message("pitchwheel", pitch=event["pitch"], channel=channel)))
        previous = 0
        for tick, _, event in sorted(events, key=lambda e: (e[0], e[1])):
            event.time = tick - previous
            track.append(event)
            previous = tick
        file.tracks.append(track)
    output = BytesIO()
    file.save(file=output)
    return output.getvalue()

