import json
import sys
import time
import traceback

from .jobs import write_json
from .paths import DATA
from .midi_io import read_midi


def main():
    job_id = sys.argv[1]
    directory = DATA / "jobs" / job_id
    request = json.loads((directory / "request.json").read_text(encoding="utf-8"))
    started = time.perf_counter()
    started_at = time.time()

    def progress(fraction, message):
        write_json(directory / "status.json", {"state": "running", "progress": fraction,
                                               "message": message, "elapsed": time.perf_counter() - started,
                                               "started_at": started_at})
    try:
        from .backends import transcribe
        progress(0.02, "Loading the transcription model")
        output = directory / "raw.mid"
        metadata = transcribe(request, DATA / "audio" / request["audio_id"] / "source.wav", output, progress)
        result = {**read_midi(output), "id": job_id, "audio_id": request["audio_id"],
                  "backend": request["backend"], "instrument": request["instrument"],
                  "elapsed": time.perf_counter() - started, "metadata": metadata}
        write_json(directory / "result.json", result)
        write_json(directory / "status.json", {"state": "complete", "progress": 1,
                                               "message": f"Complete · {len(result['notes'])} notes",
                                               "elapsed": result["elapsed"],
                                               "device_used": "GPU" if metadata.get("device") == "cuda" else "CPU"})
    except Exception as error:
        traceback.print_exc()
        write_json(directory / "status.json", {"state": "error", "progress": 0,
                                               "message": str(error), "elapsed": time.perf_counter() - started})
        raise SystemExit(1)


if __name__ == "__main__":
    main()

