"""Probe in a short-lived process so the server retains no CUDA context."""
import json
import torch

gpu = torch.cuda.is_available()
result = {"cuda": gpu, "torch": torch.__version__, "gpu_name": None, "vram_gib": None}
if gpu:
    properties = torch.cuda.get_device_properties(0)
    result.update(gpu_name=properties.name, vram_gib=round(properties.total_memory / 1024**3, 1))
print(json.dumps(result))
