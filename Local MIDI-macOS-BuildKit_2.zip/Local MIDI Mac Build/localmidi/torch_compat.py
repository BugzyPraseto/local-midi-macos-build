"""Scoped inference API bridge for the official Intel Mac PyTorch 2.2 runtime.

The pinned models use the newer attention namespace and device-aware autocast
queries. PyTorch 2.2 already provides their underlying operations. This bridge
maps those API names to the legacy implementation during a model operation;
it never changes weights, math precision or vendor files. Newer Torch is untouched.
"""
from contextlib import contextmanager, ExitStack
import re
import sys
from types import ModuleType
from unittest.mock import patch


@contextmanager
def model_api(torch=None):
    if torch is None:
        import torch
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)", str(torch.__version__))
    version = tuple(map(int, match.groups())) if match else None
    if version is None:
        raise RuntimeError("Cannot identify the PyTorch runtime version")
    if version[:2] != (2, 2):
        if not hasattr(torch.nn, "attention") or not hasattr(torch, "get_autocast_dtype"):
            raise RuntimeError("This PyTorch version lacks the tested inference APIs; use the packaged engine")
        yield {"torch": str(torch.__version__), "legacy_bridge": False}
        return
    if getattr(torch, "_localmidi_model_api_active", False):
        yield {"torch": str(torch.__version__), "legacy_bridge": True}
        return

    legacy = torch.backends.cuda
    backend = legacy.SDPBackend
    allowed = {backend.MATH, backend.FLASH_ATTENTION, backend.EFFICIENT_ATTENTION}
    original_enabled = torch.is_autocast_enabled

    @contextmanager
    def sdpa_kernel(backends):
        selected = set(backends if isinstance(backends, (list, tuple)) else [backends])
        if not selected.issubset(allowed):
            raise ValueError("The Intel PyTorch bridge supports math, flash and efficient SDPA backends")
        with legacy.sdp_kernel(enable_flash=backend.FLASH_ATTENTION in selected,
                               enable_math=backend.MATH in selected,
                               enable_mem_efficient=backend.EFFICIENT_ATTENTION in selected):
            yield

    def is_autocast_enabled(device_type=None):
        if device_type is None or device_type == "cuda":
            return original_enabled()
        if device_type == "cpu":
            return torch.is_autocast_cpu_enabled()
        raise ValueError("Unsupported autocast device in the Intel engine: " + str(device_type))

    def get_autocast_dtype(device_type):
        if device_type == "cpu":
            return torch.get_autocast_cpu_dtype()
        if device_type == "cuda":
            return torch.get_autocast_gpu_dtype()
        raise ValueError("Unsupported autocast device in the Intel engine: " + str(device_type))

    attention = ModuleType("torch.nn.attention")
    attention.SDPBackend = backend
    attention.sdpa_kernel = sdpa_kernel
    # ExitStack restores both pre-existing values and absent attributes, even if
    # checkpoint loading or inference raises. Workers run one model per process.
    with ExitStack() as stack:
        stack.enter_context(patch.object(torch, "_localmidi_model_api_active", True, create=True))
        stack.enter_context(patch.object(torch.nn, "attention", attention, create=True))
        absent = object()
        previous_module = sys.modules.get("torch.nn.attention", absent)
        sys.modules["torch.nn.attention"] = attention
        def restore_module():
            if previous_module is absent:
                sys.modules.pop("torch.nn.attention", None)
            else:
                sys.modules["torch.nn.attention"] = previous_module
        stack.callback(restore_module)
        stack.enter_context(patch.object(torch, "is_autocast_enabled", is_autocast_enabled))
        stack.enter_context(patch.object(torch, "get_autocast_dtype", get_autocast_dtype, create=True))
        yield {"torch": str(torch.__version__), "legacy_bridge": True}
