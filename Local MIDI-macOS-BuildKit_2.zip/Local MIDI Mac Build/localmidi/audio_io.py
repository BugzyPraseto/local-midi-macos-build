import json
import subprocess
from pathlib import Path

import numpy as np
import soundfile as sf


def prepare_audio(source: Path, directory: Path):
    target = directory / "source.wav"
    try:
        samples, rate = sf.read(source, dtype="float32", always_2d=True)
    except (RuntimeError, sf.LibsndfileError):
        import imageio_ffmpeg
        process = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-v", "error", "-y",
                                  "-i", str(source), "-vn", "-c:a", "pcm_f32le", str(target)],
                                 capture_output=True, timeout=120,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if process.returncode:
            raise ValueError("This audio file could not be decoded.")
        samples, rate = sf.read(target, dtype="float32", always_2d=True)
    if len(samples) == 0 or len(samples) / rate > 1800 or samples.shape[1] > 8:
        raise ValueError("Choose a non-empty audio file up to 30 minutes and 8 channels.")
    if not np.isfinite(samples).all():
        raise ValueError("The file contains invalid audio samples.")
    sf.write(target, samples, rate, subtype="FLOAT")
    mono = samples.mean(axis=1)
    hop = max(1, int(np.ceil(len(mono) / 6000)))
    padded = np.pad(mono, (0, (-len(mono)) % hop))
    peaks = np.max(np.abs(padded.reshape(-1, hop)), axis=1)
    return {"duration": len(samples) / rate, "sample_rate": rate,
            "channels": samples.shape[1], "peaks": np.round(peaks, 5).tolist()}

