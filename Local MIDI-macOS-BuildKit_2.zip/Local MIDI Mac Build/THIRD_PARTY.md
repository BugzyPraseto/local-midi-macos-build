# Third-party sources and attribution

## Native JUCE build

The Windows native wrapper uses [JUCE 8.0.15](https://github.com/juce-framework/JUCE/releases/tag/8.0.15) and Microsoft's [WebView2 SDK](https://learn.microsoft.com/en-us/microsoft-edge/webview2/) 1.0.4258.31. Exact download URLs and SHA-256 hashes are in `native/dependencies.json`. JUCE is available under its [JUCE licence terms](https://juce.com/legal/juce-8-licence/) or AGPLv3; this project does not grant a separate JUCE commercial licence. The WebView2 NuGet package retains Microsoft's LICENSE and NOTICE files. Copies of these native SDK notices are packaged in `dist/Local MIDI/0.2.0/Licenses`.

The JUCE JavaScript interop files in `static/juce/` are copied unchanged from the pinned JUCE release, including their original notices. The interface itself is served by the local engine inside WebView2. The VST3 SDK used by this JUCE release reports version 3.8.0; its bundled notices are retained in the downloaded JUCE source. [pluginval](https://github.com/Tracktion/pluginval) 1.0.4 was used as a separate validation tool and is not linked into the product.

This private evaluation workspace downloads third-party code and model artifacts into `.models` and Python dependencies into `.venv`. The application's new source does not replace their licenses. This inventory records the observed declarations; it is not a commercial clearance opinion.

| Component | Author/source | Observed declaration | Local notice |
|---|---|---|---|
| Inter variable font, Latin subset | Inter / Rasmus Andersson, from the reference project's `@fontsource-variable/inter` package | SIL Open Font License 1.1 | `static/assets/fonts/Inter-LICENSE.txt` |
| Transkun 2.0.1 and bundled V2 checkpoint | [Yujia Yan / Transkun](https://github.com/Yujia-Yan/Transkun) | MIT in the distributed package | `.venv/Lib/site-packages/transkun-2.0.1.dist-info/LICENSE` |
| Aria-AMT code | [EleutherAI / Louis Bradshaw](https://github.com/EleutherAI/aria-amt) | Apache-2.0 | `.models/vendors/aria-amt/LICENSE` |
| Aria utilities | [EleutherAI / aria-utils](https://github.com/EleutherAI/aria-utils) | Apache-2.0 | `.models/vendors/aria-utils/LICENSE` |
| Aria preliminary piano weights | [Author's checkpoint repository](https://huggingface.co/datasets/loubb/aria-midi/tree/main) | Hosted in the Aria-MIDI dataset repository, whose metadata and dataset card declare CC-BY-NC-SA-4.0. The card separately calls its software tools Apache-2.0; checkpoint-specific scope needs clarification before commercial use. | Original source/revision/hash in `models.json` |
| GAPS guitar weights | [Xavier Riley's model repository](https://huggingface.co/xavriley/midi-transcription-models) | MIT in model card metadata | Source/revision/hash in `models.json` |
| GAPS inference fork | [Xavier Riley / Qiuqiang Kong's piano-transcription inference](https://github.com/xavriley/piano_transcription_inference) | MIT declared in `setup.py` classifiers; this fork's archive contains no standalone LICENSE file | `.models/vendors/gaps-inference/setup.py` |
| Tsumugi source | [anime-song / tsumugi](https://github.com/anime-song/tsumugi) | MIT, copyright 2026 anime-song | `.models/vendors/tsumugi/LICENSE` |
| Tsumugi guitar v1.5 weights | [anime-song model repository](https://huggingface.co/anime-song/instrument_agnostic_amt) | MIT in repository metadata; model card has no detailed prose | Source/revision/hash in `models.json` |
| Basic Pitch 0.4.0 and packaged ONNX model | [Spotify / Basic Pitch](https://github.com/spotify/basic-pitch) | Apache-2.0 | `.venv/Lib/site-packages/basic_pitch-0.4.0.dist-info/LICENSE` |

The native Windows Aria adapter imports the original model, tokenizer, audio front end and silence helpers from the pinned Aria code. The device-aware cache allocation, synchronous loop, and tail-window scheduling are local adaptations. Aria's own source acknowledges its Whisper-derived model implementation. Vendor files remain unchanged; the original notices are retained.

## Local playback samples

Piano and nylon guitar MP3 samples come from the **FluidR3_GM / Fluid Soundfont** distribution in [gleitz/midi-js-soundfonts](https://github.com/gleitz/midi-js-soundfonts). The project's README identifies the Fluid Soundfont as **[Creative Commons Attribution 3.0](https://creativecommons.org/licenses/by/3.0/)**. Credit: Fluid Soundfont and its contributors, with browser-ready renderings distributed by the MIDI.js Soundfonts project (gleitz).

Files `static/samples/piano.json` and `static/samples/guitar.json` are data-only conversions of the upstream MP3 object literals. Note labels were converted to numeric MIDI pitches and the JavaScript wrapper was removed. The encoded audio is unchanged. They are used for approximate local audition, not for transcription. Exact source URLs and hashes are retained in `static/samples/manifest.json`. No MIDI.js runtime or third-party JavaScript is executed by the app.

Python, PyTorch, FFmpeg, FastAPI, NumPy, ONNX Runtime and other dependencies retain their upstream notices in their installed distributions. Packaging an installer or shipping a commercial product requires a full dependency/license inventory and any required notices for that distribution. The current workspace is a local private prototype.
