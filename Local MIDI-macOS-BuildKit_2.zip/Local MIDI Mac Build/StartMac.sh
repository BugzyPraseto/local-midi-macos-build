#!/bin/bash
set -euo pipefail
engine_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
engine_python="$engine_root/runtime/bin/python3"
if [[ "$(uname -s)" != Darwin ]]; then
    printf '%s\n' 'StartMac.sh requires macOS. Use Start.cmd on Windows.' >&2
    exit 1
fi
if [[ ! -x "$engine_python" ]]; then
    printf '%s\n' 'The bundled Mac engine is missing. Install the Mac package or run BuildMac.command on a supported Mac.' >&2
    exit 1
fi
# Resolve the selector and CPython's own links before exec. Its dynamic loader
# and sys.prefix must use the fresh runtime, even after upgrading a flat payload.
link_count=0
while [[ -L "$engine_python" ]]; do
    link_count=$((link_count + 1))
    if [[ "$link_count" -gt 40 ]]; then
        printf '%s\n' 'The installed Python entry point contains a link cycle. Reinstall Local MIDI.' >&2
        exit 1
    fi
    link_target="$(/usr/bin/readlink "$engine_python")"
    if [[ "$link_target" = /* ]]; then
        engine_python="$link_target"
    else
        engine_python="$(dirname -- "$engine_python")/$link_target"
    fi
done
engine_python="$(cd -- "$(dirname -- "$engine_python")" && pwd -P)/$(basename -- "$engine_python")"
# DAWs can export their own Python and dynamic-library settings.
unset PYTHONHOME PYTHONPATH PYTHONUSERBASE VIRTUAL_ENV CONDA_PREFIX
unset DYLD_LIBRARY_PATH DYLD_FRAMEWORK_PATH DYLD_FALLBACK_LIBRARY_PATH
exec "$engine_python" -I -B "$engine_root/engine.py" "$@"
