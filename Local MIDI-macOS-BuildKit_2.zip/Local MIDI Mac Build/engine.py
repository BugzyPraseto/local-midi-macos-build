"""Entry point for the relocatable macOS engine. Never runs at import time."""
import argparse
import importlib
import json
import os
from pathlib import Path
import platform
import runpy
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
# The bundled interpreter runs with -I; explicitly admit only this engine's source.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def managed_environment(root=ROOT, environ=None, system=None, home=None):
    env = dict(os.environ if environ is None else environ)
    system = sys.platform if system is None else system
    home = Path.home() if home is None else Path(home)
    root = Path(root).resolve()
    mac = system == "darwin"
    default_data = home / "Library/Application Support/Local MIDI" if mac else root / ".local"
    data = Path(env.get("LOCALMIDI_DATA", default_data)).expanduser().resolve()
    cache = Path(env.get("LOCALMIDI_CACHE", home / "Library/Caches/Local MIDI" if mac else data / "cache")).expanduser().resolve()
    logs = Path(env.get("LOCALMIDI_LOGS", home / "Library/Logs/Local MIDI" if mac else data / "logs")).expanduser().resolve()
    for name in ("PYTHONHOME", "PYTHONPATH", "PYTHONUSERBASE", "VIRTUAL_ENV", "CONDA_PREFIX",
                 "DYLD_LIBRARY_PATH", "DYLD_FRAMEWORK_PATH", "DYLD_FALLBACK_LIBRARY_PATH"):
        env.pop(name, None)
    env.update(LOCALMIDI_ROOT=str(root), LOCALMIDI_DATA=str(data), LOCALMIDI_CACHE=str(cache),
               LOCALMIDI_LOGS=str(logs), LOCALMIDI_MODELS=str(Path(env.get("LOCALMIDI_MODELS", root / ".models")).expanduser().resolve()),
               PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", PYTHONUNBUFFERED="1",
               XDG_CACHE_HOME=str(cache), MPLCONFIGDIR=str(cache / "matplotlib"),
               NUMBA_CACHE_DIR=str(cache / "numba"), TORCH_HOME=str(cache / "torch"),
               HF_HOME=str(cache / "huggingface"))
    return env


def configure():
    env = managed_environment()
    os.environ.clear()
    os.environ.update(env)
    sys.dont_write_bytecode = True
    if sys.platform == "darwin":
        os.umask(0o077)
    for name in ("LOCALMIDI_DATA", "LOCALMIDI_CACHE", "LOCALMIDI_LOGS", "MPLCONFIGDIR", "NUMBA_CACHE_DIR"):
        Path(env[name]).mkdir(parents=True, exist_ok=True)
    return env


def health():
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open("http://127.0.0.1:8765/api/health", timeout=1.5) as response:
            value = json.load(response)
    except (OSError, ValueError, urllib.error.URLError):
        return None
    if (not isinstance(value, dict) or value.get("application") != "localmidi" or
            Path(value.get("root", "")).resolve() != ROOT or
            Path(value.get("data", "")).resolve() != Path(os.environ["LOCALMIDI_DATA"])):
        raise RuntimeError("Port 8765 belongs to a different installation or user's library. Close that engine before starting this one.")
    return value


def pid_file():
    return Path(os.environ["LOCALMIDI_DATA"]) / "engine.pid.json"


def read_pid():
    try:
        value = json.loads(pid_file().read_text(encoding="utf-8"))
        if isinstance(value, dict) and value.get("root") == str(ROOT) and value.get("data") == os.environ["LOCALMIDI_DATA"]:
            pid = value.get("pid")
            if isinstance(pid, int) and not isinstance(pid, bool) and pid > 1:
                return pid
    except (OSError, ValueError):
        pass
    return None


def write_pid(pid):
    target = pid_file()
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps({"pid": pid, "root": str(ROOT), "data": os.environ["LOCALMIDI_DATA"]}), encoding="utf-8")
    temporary.replace(target)


def owns_process(pid):
    if not pid or sys.platform != "darwin":
        return False
    result = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "uid=", "-o", "command="],
                            capture_output=True, text=True, timeout=3)
    fields = result.stdout.strip().split(None, 1)
    return (result.returncode == 0 and len(fields) == 2 and fields[0] == str(os.getuid())
            and str(ROOT / "engine.py") in fields[1] and fields[1].rstrip().endswith(" serve"))


def start_background():
    if sys.platform != "darwin":
        raise RuntimeError("Background engine management is available on macOS. Use Start.cmd on Windows.")
    import fcntl
    # Coordinate CLI launches as well as the native editor's interprocess lock.
    with (Path(os.environ["LOCALMIDI_DATA"]) / "startup.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if health() or owns_process(read_pid()):
            return
        logs = Path(os.environ["LOCALMIDI_LOGS"])
        with (logs / "engine.log").open("ab", buffering=0) as log:
            child = subprocess.Popen([sys.executable, "-I", "-B", str(ROOT / "engine.py"), "serve"],
                                     cwd=ROOT, env=os.environ.copy(), stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                                     close_fds=True)
        write_pid(child.pid)


def stop_background():
    if sys.platform != "darwin":
        raise RuntimeError("Use Stop.cmd on Windows.")
    pid = read_pid()
    if not owns_process(pid):
        print("No owned Local MIDI engine is running.")
        return
    status = health()
    if status is None or status.get("pid") != pid:
        raise RuntimeError("Engine identity could not be verified; no process was stopped. Check the engine log.")
    os.kill(pid, signal.SIGTERM)
    for _ in range(100):
        if not owns_process(pid):
            print("Local MIDI engine stopped.")
            return
        time.sleep(.1)
    raise RuntimeError("The engine is still stopping. Wait before installing an update.")


def serve():
    import fcntl
    with (Path(os.environ["LOCALMIDI_DATA"]) / "engine.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("A Local MIDI engine is already running for this user.")
        write_pid(os.getpid())
        try:
            import uvicorn
            uvicorn.run("localmidi.app:app", host="127.0.0.1", port=8765, log_level="info")
        finally:
            if read_pid() == os.getpid():
                pid_file().unlink(missing_ok=True)


def self_test():
    import torch
    from localmidi.torch_compat import model_api
    with model_api(torch) as compatibility:
        return _self_test(compatibility)


def _self_test(compatibility):
    # Import the installed inference paths, without loading checkpoints or user audio.
    required = ("fastapi", "uvicorn", "numpy", "scipy", "librosa", "soundfile", "soxr",
                "orjson", "ncls", "torch", "torchaudio", "torchlibrosa", "onnxruntime",
                "transkun", "moduleconf", "safetensors", "imageio_ffmpeg", "einops")
    versions = {}
    for name in required:
        module = importlib.import_module(name)
        versions[name] = getattr(module, "__version__", "installed")
    # The baseline uses ONNX, including when TensorFlow is installed on a developer Mac.
    sys.modules["tensorflow"] = None
    importlib.import_module("basic_pitch.inference")
    from localmidi.aria_adapter import add_vendor_paths
    add_vendor_paths()
    importlib.import_module("amt.inference.model")
    models = Path(os.environ["LOCALMIDI_MODELS"])
    sys.path.insert(0, str(models / "vendors/tsumugi"))
    importlib.import_module("instrument_agnostic_amt.amt.modeling.blocks.transformer")
    sys.path.insert(0, str(models / "vendors/gaps-inference"))
    importlib.import_module("piano_transcription_inference")
    from localmidi.backends import available_models
    available = available_models()
    missing = [model["id"] for model in available if not model["ready"]]
    if missing:
        raise RuntimeError("Missing packaged models: " + ", ".join(missing))
    for relative in ("static/index.html", "static/native-bridge.js", "static/juce/index.js",
                     "static/samples/piano.json", "static/samples/guitar.json", "static/samples/manifest.json"):
        if not (ROOT / relative).is_file():
            raise RuntimeError("Missing engine resource: " + relative)
    import imageio_ffmpeg
    result = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-version"], capture_output=True, timeout=15)
    if result.returncode:
        raise RuntimeError("The bundled audio decoder could not run.")
    print(json.dumps({"ok": True, "root": str(ROOT), "data": os.environ["LOCALMIDI_DATA"],
                      "platform": sys.platform, "architecture": platform.machine(), "python": platform.python_version(),
                      "models": [model["id"] for model in available], "versions": versions,
                      "torch_compatibility": compatibility,
                      "inference_device": "cpu", "transcription_tested": False}))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--background", action="store_true")
    group.add_argument("--stop", action="store_true")
    group.add_argument("--self-test", action="store_true")
    parser.add_argument("command", choices=("serve", "probe", "worker"), nargs="?", default="serve")
    parser.add_argument("arguments", nargs="*")
    args = parser.parse_args(argv)
    if (args.background or args.stop or args.self_test) and (args.command != "serve" or args.arguments):
        parser.error("Management flags cannot be combined with worker/probe commands")
    configure()
    if args.background:
        start_background()
    elif args.stop:
        stop_background()
    elif args.self_test:
        self_test()
    elif args.command in ("probe", "worker"):
        if len(args.arguments) != (1 if args.command == "worker" else 0):
            parser.error("worker requires one job ID; probe takes no arguments")
        sys.argv = ["localmidi." + args.command, *args.arguments]
        runpy.run_module("localmidi." + args.command, run_name="__main__")
    else:
        if args.arguments:
            parser.error("serve takes no arguments")
        serve()


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, ImportError) as error:
        print("Local MIDI engine: " + str(error), file=sys.stderr)
        raise SystemExit(1)
