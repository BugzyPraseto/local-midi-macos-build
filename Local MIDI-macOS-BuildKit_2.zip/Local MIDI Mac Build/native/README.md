# Local MIDI — JUCE standalone and VST3

Windows x64 builds of the local piano/guitar transcription workbench, made with JUCE 8.0.15 and WebView2. Both versions use the existing local Python/CUDA engine and model files. You do not have to start the web app manually.

The **macOS installer build** is documented in [macos/README.md](macos/README.md). It targets Apple Silicon and Intel/macOS 12+, with universal2 app/VST3 bundles and a processor-matched CPU engine in standard Mac locations, using WKWebView. It must be compiled and validated on a Mac; the Windows binaries below are not Mac installers.

## Run the app

Double-click **`StartNative.cmd`** in `E:\Audio to Midi`, or run **`dist\Local MIDI\0.2.0\Local MIDI.exe`** directly.

The app starts the installed local engine, then opens the existing interface inside its native window. Import a recording, choose Piano or Guitar, select models and transcribe. **Automatic** uses the NVIDIA GPU for Transkun, Aria, GAPS and Tsumugi when CUDA is available. Basic Pitch uses CPU.

Use **Audio settings** to choose your audio interface, input, output, sample rate and buffer size. Playback runs through JUCE's audio engine. The standalone app does not monitor live input to the speakers; its input is available for **Capture new**. Captures are 32-bit floating-point WAV files. Press **Finish capture**, then select models and transcribe.

## Compact workspace and Full view

The native editor can be resized up to 7680×4320 and the web interface uses the full available width.

The standalone title bar includes **Minimize, Maximize/Restore and Close**. Maximize fills the available desktop area; clicking Restore returns to the previous window size. Double-clicking the title bar also toggles this. This is separate from the piano roll's Full view mode. The DAW controls the VST3 window's title bar.

Version 0.2 uses the Dock design with a separate **Compare** view. Compact controls are the default: the source/model controls occupy small top strips, leaving most of the window for notes. Press **F** or **Full view** to expand the note workspace. Press **F** again, or **Escape**, to leave Full view. Audition, take selection, lasso and MIDI transfer stay available. The settings gear also offers a Comfortable density.

The AETHER-inspired editor uses a charcoal interface, a wider piano keyboard, adjustable note height and a larger velocity lane. **Source & models** collapses the recording controls. **V** selects and moves notes, **B** draws notes, and **E** erases them. Drag either note edge to resize; **H** fits selected notes, or all notes when the selection is empty. Ctrl/Cmd-wheel zooms around the pointer and Shift-wheel pans horizontally. The editing grid defaults to **Free timing**; beat snapping affects only new or edited notes, and **Alt** temporarily bypasses it. Export quantization remains a separate setting. **Escape** cancels an active note or velocity gesture before leaving Full view, preserving undo/redo history. Reopen the native editor after updating the shared static UI; no C++ rebuild is needed.

The take chooser keeps imported MIDI filenames visible in Edit, Compare and export summaries. The **Edit** menu contains clipboard commands, duplicate, transpose, explicit grid alignment and restore. Arrow keys move a selection in time or pitch; Shift adds octaves to vertical arrows and multiplies horizontal steps by ten. Alt plus a horizontal arrow uses a 1 ms step. Ctrl/Cmd+C/X/V uses an internal note clipboard; paste starts at the playhead and snaps only its anchor when an editing grid is active. Ctrl/Cmd+D duplicates after the selection. **Q** aligns selected onsets to the editing grid while preserving note durations. Multi-note selections show their actual pitch, time and velocity ranges, with relative mean-velocity editing.

The note overview above the ruler shows the entire take. Drag its visible-range rectangle to navigate without seeking; click outside the rectangle to center that part of the timeline. Focus the overview and use arrows or Home/End to navigate from the keyboard. Manual navigation suspends playback following. Hover notes for pitch, timing, duration and velocity; hover piano keys for pitch feedback. Overview and hover feedback keep playback and note-grid painting separate.

Choose **Reference overlay** in the take chooser to show another completed take as hollow dashed notes behind the active take. The outline is read-only; editing, audition and export still use the active take. Choose **None** to hide it. The overview and timeline include a longer reference's tail, and loading or switching takes clears stale outlines.

**View** groups timeline zoom, note height, interface density and overview/velocity visibility. Drag the divider above the velocity lane to resize it, or focus the divider and use arrow keys (Shift for larger steps), Home or End. Double-click the divider to return to automatic sizing. Escape cancels an active resize. Short windows prioritize the note grid and restore the lane when space returns. **Reset lane layout** restores automatic sizing and both lanes. Native project state retains lane preferences and the reference choice alongside the other editor settings.

**Compare** displays completed takes on a shared timeline and pitch range. Click a lane to seek; **Audition** selects and plays one take at a time, preserving the listening position. **Edit** returns to detailed editing. The optional difference display dims notes that match the selected take within 50 ms onset and 100 ms release; it is a visual aid, not a quality score.

The pinned timeline ruler stays visible while scrolling through pitches. Choose **Seconds** or **Bars · beats** above the editor; bars use 4/4 and the tempo in Settings. Click or drag the ruler to seek. **Follow** (shortcut **A**) keeps playback in view in both Edit and Compare. Settings offers **Page turn** or **Smooth follow**. Manually scrolling horizontally pauses following; click **Resume**, press A, or start playback again to resume. Dragging notes or a lasso near an editor edge scrolls the view in that direction.

Playback moves a separate playhead layer, leaving the note grid and waveform cached. Notes are drawn only for the visible pitch/time area and pointer updates are combined into one render per display frame. The JUCE transport is interpolated between status reports. Native playback also avoids loading a duplicate audio recording into WebView.

## Lasso and selected-note MIDI

Drag empty piano-roll space for a rectangular selection, or turn on **Lasso** (shortcut **L**) and draw a freehand outline. **Shift** adds another area; Shift-click toggles individual notes. Ctrl+A selects all notes. **Clear selection** or Escape clears the selection. Selected notes can be moved/deleted together and changes can be undone.

A lasso selection automatically switches **File export** to **Selected notes (N)**. Both **Export N notes** and **Drag N notes to host** use only that selection. Choose **All notes** to transfer the complete take. Selection timing offers:

- **Start at first note**: the first selected note starts at zero and the relative timing remains intact.
- **Keep source position**: selected notes retain their timing relative to the recording.

Selected exports retain the selected tracks' relevant pedal/bend state, including the pedal release after the last selected note. They omit unrelated tracks and later events. Selection and file-export settings do not limit internal audition or live host MIDI output; those continue to follow the full chosen take.

The native drag handle prepares an actual Standard MIDI File and transfers it with Windows file-copy drag, usable by hosts that accept dropped MIDI files. The handle is disabled while edits or export settings are being prepared. Every prepared file is an immutable snapshot under `.local/native-exports`, so a later edit does not overwrite an earlier dropped file. Saved MIDI export remains available when a host does not accept a drop. Universal compatibility has not been claimed or exhaustively tested across DAWs.

## Install the plug-in

Run **`InstallVST3.cmd`** from the project folder. The default per-user destination is:

```text
%LOCALAPPDATA%\Programs\Common\VST3\Local MIDI.vst3
```

Rescan VST3 plug-ins in your DAW. If it does not scan this folder automatically, add it to the DAW's plug-in paths. The plug-in is named **Local MIDI** and appears as an audio effect/tool. Copy the entire `.vst3` folder, not just the binary inside `Contents`.

For the system-wide VST3 folder, run `InstallVST3.ps1 -AllUsers` from PowerShell with the permissions required for `C:\Program Files\Common Files\VST3`. The installer checks the existing class ID before updating a previous build of this plug-in. Close hosts using the plug-in before replacing its files.

## Work inside a DAW

1. Insert **Local MIDI** on the audio track containing the isolated piano/guitar recording, or import a file in its editor.
2. To capture the track, press **Capture new**, then start the DAW transport. The plug-in records its mono/stereo input without running inference on the audio thread.
3. Press **Finish capture** or stop the DAW transport. The first captured block's host time becomes the take's starting position. A transport seek or loop boundary ends the current capture.
4. Choose the instrument and models, then press **Transcribe audio**. Results are independent takes. Multiple models run sequentially to share GPU memory.
5. Compare, edit, and use **Export .mid** to open a native save dialog, or press and drag **Drag MIDI to host** into a MIDI/instrument track. File-drop support depends on the host.

For MIDI output from the plug-in, enable **Send MIDI to host** and route its MIDI output to an instrument track in the DAW. The exact routing controls differ between hosts. **Start** is the timeline placement in seconds. Captured clips use their capture origin; imported files start at zero until you change it. **At playhead** sets the current take's start to the DAW playhead.

The plug-in sends note events, available pedal CC and pitch bends according to the host timeline. Stopping, seeking, changing takes and bypassing release the generated MIDI notes. MIDI output is off by default. The internal sampled MIDI audition is separate from sending MIDI to another plug-in. Use a DAW instrument to assess guitar bends and articulation; the simple internal sample player does not reproduce these details.

Original/MIDI/Blend preview is rendered by JUCE through the app's audio device or the DAW's audio engine. The VST3 passes its incoming audio normally; while an internal preview is playing, that instance replaces its input audio with the audition signal. Its ordinary input passthrough returns when preview stops. If the DAW suspends audio processing while stopped, start its audio engine/transport to audition. Space inside the editor controls preview; use the DAW's own Play control to begin an armed capture.

Host placement is based on seconds and does not time-stretch the transcription when the project tempo changes. MIDI grid alignment applies to file export/drag only. Timing adjustments may be necessary if other plug-ins or routing add latency.

## Projects and multiple instances

Each native instance keeps its own note edits, selected source/take, model choices and MIDI placement. Saving the DAW project saves these settings and the selected MIDI data in plug-in state. The standalone wrapper retains its plug-in state on normal exit. Changes in one native instance do not overwrite another instance's note edits or the browser app's edited MIDI.

The audio library, original model predictions, model files and Python engine remain shared on disk. Keep the project folder and `.local` data available: source audio and model weights are not embedded in DAW project files. Save/export MIDI before moving a session to a different computer. The first build is intended for private use on this configured Windows machine, rather than as a portable installer.

Closing an editor stops its internal audition. Background inference belongs to the local service and can finish after an editor closes. Use the app's Cancel button to cancel jobs; `Stop.cmd` stops the shared service and affects every connected instance.

## Engine location and requirements

The current build points to `E:\Audio to Midi`. Keep this folder with `.venv`, `.models`, `localmidi`, `static`, and the startup scripts. To relocate the engine, set **`LOCALMIDI_ROOT`** before starting the app/DAW, or provide **`Local MIDI.engine.json`** beside the native executable/module. The environment variable takes precedence:

```json
{"project_root": "D:\\My Audio Tools\\Audio to Midi"}
```

The engine uses loopback port **8765**. A different Local MIDI installation already using that port must be stopped first. Microsoft Edge WebView2 Evergreen Runtime and the Visual C++ runtime must be available. Both are present on the build machine. Initial engine/model installation uses the existing `Setup.cmd`; the native binary does not download model weights during audio processing or plug-in scans.

## Build from source

Requirements: Windows x64, Visual Studio 2022 C++ Build Tools with the Windows SDK, CMake 3.24+, and the configured Python engine environment.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\BuildNative.ps1
```

The script downloads/verifies the pinned JUCE and WebView2 SDK archives from `native/dependencies.json`, builds Release standalone/VST3 binaries, runs the native MIDI timing tests and packages both into `dist\Local MIDI\0.2.0`. It does not modify the older system JUCE installation at `C:\JUCE`. Close running copies before rebuilding or installing updates.

Build the real-WebView/audio integration harness with `BuildNative.ps1 -NativeQA`. It uses a simulated audio callback and an actual recording fixture, runs real CUDA transcription, adds a known test note, verifies native audio/MIDI output, and checks project recall. It creates test captures/jobs in `.local` and JSON reports in `.local/native-validation`; it does not record the microphone or require a physical audio interface. Run the built `Local MIDI Native QA.exe` with `--vst3` or `--standalone`, one mode at a time.

Sources: `native/Source/PluginProcessor.*`, `MidiTimeline.*`, `PluginEditor.*` and `BackendService.*`. The existing browser interface is shared, with optional integration in `static/native-bridge.js`. Model inference remains in isolated Python worker processes. Native instance state and host audio/MIDI processing belong to C++.

## Validation and limits

The VST3 has passed pluginval strictness level 5. Native MIDI timing tests and backend API tests pass. Both standalone and VST3 modes have completed real-WebView capture → CUDA transcription → editing/export → native audition, with project recall and MIDI output checked in the integration harness. The harness uses the same processor/editor code as the binaries; pluginval separately loads the actual VST3 module. DAW-specific routing and real mouse-driven MIDI drops still need confirmation in the user's chosen host.

This is file/capture-based transcription, not a real-time audio-to-MIDI converter or an ARA plug-in. It supports mono/stereo host buses. Long captures up to the engine's 30-minute limit have not been exhaustively tested. The native build uses the same model weights and transcription settings; it does not establish Songscription-equivalent accuracy. See the root `VALIDATION.md` and `.local/native-validation/` for evidence.

JUCE, WebView2, model weights and preview samples have separate licenses. The relevant native SDK notices are included in `Licenses`; see `THIRD_PARTY.md` and the root research before commercial redistribution.
