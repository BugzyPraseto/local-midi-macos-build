#include "../Source/PluginProcessor.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include <cmath>

namespace
{
class Playhead final : public juce::AudioPlayHead
{
public:
    std::atomic<double> seconds {10};
    juce::Optional<PositionInfo> getPosition() const override
    {
        PositionInfo position;position.setTimeInSeconds(seconds.load());position.setBpm(120);
        position.setPpqPosition(seconds.load()*2);position.setIsPlaying(true);return position;
    }
};
class AudioRunner final : public juce::Thread
{
public:
    explicit AudioRunner(LocalMidiProcessor& owner) : Thread("Native QA audio"),processor(owner)
    {
        juce::AudioFormatManager formats;formats.registerBasicFormats();
        auto path=juce::File(LOCALMIDI_PROJECT_ROOT).getChildFile(".models/vendors/aria-amt/tests/test_data/147.wav");
        std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(path));
        if (reader && reader->sampleRate==48000)
        {
            piano.setSize(2,480000);
            pianoFixture=reader->read(&piano,0,480000,30*48000,true,true);
        }
    }
    std::atomic<bool> signal {true};
    std::atomic<float> peak {0};
    std::atomic<int> noteOns {0};
    Playhead playhead;
    bool pianoFixture=false;
    void run() override
    {
        juce::AudioBuffer<float> buffer(2,480);juce::MidiBuffer midi;midi.ensureSize(65536);
        double phase=0;int pianoPosition=0;
        while (!threadShouldExit())
        {
            buffer.clear();midi.clear();
            if (signal.load()) for (int frame=0;frame<480;++frame)
            {
                if (pianoFixture)
                {
                    for (int channel=0;channel<2;++channel) buffer.setSample(channel,frame,piano.getSample(channel,pianoPosition));
                    pianoPosition=(pianoPosition+1)%piano.getNumSamples();continue;
                }
                float sample=0;
                for (const auto frequency : {261.625565,329.627557,391.995436})
                    sample+=static_cast<float>(.065*std::sin(phase*frequency)+.012*std::sin(phase*frequency*2));
                phase+=juce::MathConstants<double>::twoPi/48000;
                buffer.setSample(0,frame,sample);buffer.setSample(1,frame,sample);
            }
            { const juce::ScopedLock lock(processor.getCallbackLock());processor.processBlock(buffer,midi); }
            if (!signal.load()) peak.store(juce::jmax(peak.load(),buffer.getMagnitude(0,480)));
            for (const auto event : midi) if (event.getMessage().isNoteOn()) noteOns.fetch_add(1);
            playhead.seconds.store(playhead.seconds.load()+.01);
            wait(10);
        }
    }
private:
    LocalMidiProcessor& processor;
    juce::AudioBuffer<float> piano;
};
class Window final : public juce::DocumentWindow
{
public:
    Window() : DocumentWindow("Local MIDI native integration test",juce::Colour(0xff16191d),allButtons) {setUsingNativeTitleBar(true);}
    void closeButtonPressed() override {juce::JUCEApplicationBase::quit();}
};
}

class NativeQaApplication final : public juce::JUCEApplication,private juce::Timer
{
public:
    const juce::String getApplicationName() override {return "Local MIDI native QA";}
    const juce::String getApplicationVersion() override {return "0.1.0";}
    void initialise(const juce::String& arguments) override
    {
        standalone=arguments.contains("--standalone");
        performanceOnly=arguments.contains("--ui-performance");
        report=juce::File(LOCALMIDI_PROJECT_ROOT).getChildFile(standalone ? ".local/native-validation/standalone.json" : ".local/native-validation/vst3-ui.json");
        if(performanceOnly)report=juce::File(LOCALMIDI_PROJECT_ROOT).getChildFile(standalone ? ".local/native-validation/editor-performance-standalone.json" : ".local/native-validation/editor-performance-vst3.json");
        report.getParentDirectory().createDirectory();
        juce::AudioProcessor::setTypeOfNextNewPlugin(standalone ? juce::AudioProcessor::wrapperType_Standalone : juce::AudioProcessor::wrapperType_VST3);
        processor=std::make_unique<LocalMidiProcessor>();
        juce::AudioProcessor::setTypeOfNextNewPlugin(juce::AudioProcessor::wrapperType_Undefined);
        processor->prepareToPlay(48000,480);
        runner=std::make_unique<AudioRunner>(*processor);processor->setPlayHead(&runner->playhead);runner->startThread();
        window=std::make_unique<Window>();
        editor=processor->createEditor();window->setContentOwned(editor,true);
        window->centreWithSize(arguments.contains("--compact")?980:1280,arguments.contains("--compact")?760:950);window->setVisible(true);
        started=juce::Time::getMillisecondCounterHiRes();startTimer(250);
    }
    void shutdown() override
    {
        stopTimer();if (runner) {runner->signalThreadShouldExit();runner->stopThread(2000);}
        if (processor) processor->setPlayHead(nullptr);
        window.reset();restored.reset();runner.reset();processor.reset();
    }
private:
    void fail(const juce::String& text)
    {
        auto* value=new juce::DynamicObject();value->setProperty("ok",false);value->setProperty("error",text);
        report.replaceWithText(juce::JSON::toString(juce::var(value),false));setApplicationReturnValue(1);quit();
    }
    void execute(const juce::String& script) {browser->evaluateJavascript(script);}
    void timerCallback() override
    {
        if (juce::Time::getMillisecondCounterHiRes()-started>150000) {fail("Native integration test timed out");return;}
        if (busy) return;
        if (stage==3)
        {
            juce::MemoryBlock bytes;restored->getStateInformation(bytes);
            juce::MemoryInputStream input(bytes,false);
            auto saved=juce::JSON::parse(input.readString());
            if (saved["take"].toString().isEmpty()) return;
            if (saved["take"].toString()!=expectedTake) {fail("Project recall changed the MIDI payload");return;}
            Playhead head;head.seconds.store(.11);restored->setPlayHead(&head);
            restored->setHostMidi(true);restored->setPlacement(0);
            juce::AudioBuffer<float> audio(2,480);audio.clear();juce::MidiBuffer midi;
            {const juce::ScopedLock lock(restored->getCallbackLock());restored->processBlock(audio,midi);}
            restored->setPlayHead(nullptr);
            int recalled=0;for (const auto event : midi) if (event.getMessage().isNoteOn()) ++recalled;
            if (recalled<1) {fail("Recalled MIDI did not reach the host output");return;}
            midi.clear();restored->processBlockBypassed(audio,midi);
            bool released=false;for (const auto event : midi) released|=event.getMessage().isAllNotesOff();
            if (!released) {fail("Bypass did not release the generated MIDI notes");return;}
            pendingReport.getDynamicObject()->setProperty("restored_midi_note_ons",recalled);
            pendingReport.getDynamicObject()->setProperty("project_recall",true);
            pendingReport.getDynamicObject()->setProperty("bypass_releases_midi",true);
            report.replaceWithText(juce::JSON::toString(pendingReport,false));setApplicationReturnValue(0);stage=4;quit();return;
        }
        if (!browser)
            for (int i=0;i<editor->getNumChildComponents();++i)
                if (auto* candidate=dynamic_cast<juce::WebBrowserComponent*>(editor->getChildComponent(i))) browser=candidate;
        if (!browser) return;
        if (stage==0)
        {
            busy=true;
            browser->evaluateJavascript("typeof state !== 'undefined' && !!state.native && state.models.length===5",[this](auto result)
            {
                busy=false;
                if (const auto* value=result.getResult();value && static_cast<bool>(*value))
                {
                    stage=1;
                    if(performanceOnly)
                    {
                        const auto checks=juce::File(LOCALMIDI_PROJECT_ROOT).getChildFile("scripts/check_editor_render.js").loadFileAsString();
                        execute(juce::String(R"JS((async()=>{try{
                          const check=(v,m)=>{if(!v)throw Error(m);};
                          const sources=await api('/api/audio');
                          const source=sources.find(s=>s.duration>300);
                          check(source,'Missing long-recording regression fixture');
                          await selectAudio(source.id);
                          const job=state.jobs.find(j=>j.state==='complete'&&j.backend==='aria');
                          check(job,'Missing Aria regression take');await loadResult(job.id);
                          const metrics=await (
                        )JS")+checks+R"JS();
                          check(metrics.ok,'Editor render checks failed');
                          check(!audio.getAttribute('src'),'WebView is decoding a duplicate native audio source');
                          const context=roll.getContext('2d'),fill=context.fillRect;let paints=0;
                          context.fillRect=function(x,y,w,h){if(x===0&&y===0&&w>=roll.logicalWidth&&h>=roll.logicalHeight)paints++;return fill.call(this,x,y,w,h);};
                          const positions=[];
                          state.px=80;document.querySelector('#zoom').value=80;document.querySelector('#zoom').dispatchEvent(new Event('input'));
                          await new Promise(requestAnimationFrame);
                          await document.querySelector('[data-listen="original"]').onclick();
                          seek(1);await play();
                          try{for(let i=0;i<30;i++){await new Promise(requestAnimationFrame);positions.push(document.querySelector('#roll-playhead').style.transform);}}
                          finally{pause();context.fillRect=fill;}
                          metrics.real_playback_frames=positions.length;metrics.unique_playhead_positions=new Set(positions).size;metrics.real_playback_paints=paints;
                          check(metrics.unique_playhead_positions>5,'Native playhead still advances in coarse status-poll steps');
                          check(paints<=3,'Native playback repaints static notes');
                          LocalMidiUI.setView('compare');
                          for(let i=0;i<100&&document.querySelectorAll('.comparison-row').length<2;i++)await new Promise(r=>setTimeout(r,50));
                          state.px=48;document.querySelector('#zoom').value=48;resizeRoll();state.follow=true;state.followSuspended=false;followPlayback(60,true);
                          await new Promise(requestAnimationFrame);
                          check(document.querySelector('#comparison-scroll').scrollLeft>0,'Compare follow failed');
                          metrics.comparison_lanes=document.querySelectorAll('.comparison-row').length;metrics.native_bridge=true;metrics.stage='performance-complete';window.__nativeQa=metrics;
                        }catch(e){window.__nativeQa={error:String(e.stack||e)};}})())JS");
                        return;
                    }
                    execute(R"JS((async()=>{try{
                      const check=(v,m)=>{if(!v)throw Error(m);};
                      document.querySelector('[data-instrument="guitar"]').click();
                      check(document.querySelector('#model-gaps')&&document.querySelector('#model-tsumugi'),'Guitar models missing');
                      document.querySelector('[data-instrument="piano"]').click();
                      await document.querySelector('#capture-start').onclick();
                      await new Promise(r=>setTimeout(r,3800));
                      await document.querySelector('#capture-stop').onclick();
                      for(let i=0;i<100&&!state.audio;i++)await new Promise(r=>setTimeout(r,100));
                      check(state.audio?.origin==='native_capture','Capture was not imported');
                      check(state.audio.duration>.2,'Capture is empty');
                      window.__nativeQa={stage:'captured',audio_id:state.audio.id,duration:state.audio.duration,origin:state.audio.host_start_seconds};
                    }catch(e){window.__nativeQa={error:String(e.stack||e)};}})())JS");
                }
            });
            return;
        }
        busy=true;
        browser->evaluateJavascript("JSON.stringify(window.__nativeQa||null)",[this](auto result)
        {
            busy=false;
            const auto* raw=result.getResult();if (!raw) return;
            auto value=juce::JSON::parse(raw->toString());if (!value.isObject()) return;
            if (value.hasProperty("error")) {fail(value["error"].toString());return;}
            if (stage==1 && value["stage"].toString()=="captured")
            {
                runner->signal.store(false);stage=2;
                execute(R"JS((async()=>{try{
                  const captured=window.__nativeQa;
                  for(const input of document.querySelectorAll('#model-options input'))if(input.checked!==(input.id==='model-transkun'))input.click();
                  await document.querySelector('#transcribe').onclick();
                  for(let i=0;i<1000;i++){await new Promise(r=>setTimeout(r,100));if(state.result&&state.activeJobs.size===0)break;}
                  if(!state.result)throw Error('Transcription did not finish');
                  const predictedNotes=state.notes.length;
                  const device=state.result.metadata.device;
                  const testNote={id:crypto.randomUUID(),start:.1,end:.65,pitch:72,velocity:95,track:0,program:0,is_drum:false};
                  checkpoint();state.notes.push(testNote);changed();await persistNotes();
                  const midi=await midiBlob();if(String.fromCharCode(...new Uint8Array(await midi.arrayBuffer()).slice(0,4))!=='MThd')throw Error('MIDI export failed');
                  const {base64}=await import('/native-bridge.js');
                  LocalMidiUI.setSelection([testNote.id],true,false);await syncNativeTake();
                  const selectionMidi=await midiBlob();
                  const selectedFile=await state.native('prepareDrag',{bytes:base64(new Uint8Array(await selectionMidi.arrayBuffer())),name:midiFilename(),revision:dragRevision()});
                  LocalMidiUI.setSelection([],false,false);await syncNativeTake();
                  const allFile=await state.native('prepareDrag',{bytes:base64(new Uint8Array(await midi.arrayBuffer())),name:midiFilename(),revision:dragRevision()});
                  LocalMidiUI.setSelection([testNote.id],false,false);
                  if(document.querySelector('#drag-midi').disabled)throw Error('Selecting a note disabled all-note drag');
                  LocalMidiUI.setSelection([testNote.id],true,true);
                  if(!document.querySelector('#drag-midi').disabled)throw Error('A stale drag remained enabled after export scope changed');
                  for(let i=0;i<50&&document.querySelector('#drag-midi').disabled;i++)await new Promise(r=>setTimeout(r,100));
                  if(document.querySelector('#drag-midi').disabled)throw Error('Selection drag did not become ready');
                  LocalMidiUI.setSelection([],false,true);
                  for(let i=0;i<50&&document.querySelector('#drag-midi').disabled;i++)await new Promise(r=>setTimeout(r,100));
                  if(document.querySelector('#drag-midi').disabled)throw Error('All-note drag did not recover');
                  let staleRejected=false;try{await state.native('drag',{revision:'deliberately-stale-qa-revision'});}catch(e){staleRejected=true;}
                  if(!staleRejected)throw Error('Stale MIDI drag was accepted');
                  const reference=new FormData();reference.append('file',midi,'QA reference.mid');reference.append('instrument','piano');
                  await api('/api/audio/'+state.audio.id+'/reference',{method:'POST',body:reference});await refreshJobs();
                  document.querySelector('#view-compare').click();
                  for(let i=0;i<50&&document.querySelectorAll('.comparison-row').length<2;i++)await new Promise(r=>setTimeout(r,100));
                  const lanes=[...document.querySelectorAll('.comparison-roll')];
                  if(lanes.length<2)throw Error('Native Compare did not render both takes');
                  const origin=document.querySelector('#comparison-wave').getBoundingClientRect().left;
                  if(lanes.some(lane=>Math.abs(lane.getBoundingClientRect().left-origin)>1))throw Error('Comparison timelines are misaligned');
                  document.querySelector('#view-edit').click();
                  const normalHeight=document.querySelector('#roll-scroll').clientHeight;
                  document.querySelector('#focus-roll').click();
                  const fullHeight=document.querySelector('#roll-scroll').clientHeight;
                  if(fullHeight<normalHeight+100)throw Error('Full view did not expand the piano roll');
                  if(document.querySelector('#drag-midi').getBoundingClientRect().bottom>innerHeight+1)throw Error('Full view hid MIDI drag below the window');
                  document.querySelector('#focus-roll').click();
                  if(document.documentElement.scrollWidth>innerWidth+1)throw Error('Native UI overflows horizontally');
                  await document.querySelector('[data-listen="midi"]').onclick();
                  await document.querySelector('#play').onclick();
                  await new Promise(r=>setTimeout(r,900));pause();
                  if(!state.nativeStatus.standalone){await state.native('placeAtPlayhead');await state.native('hostMidi',true);await new Promise(r=>setTimeout(r,1000));await state.native('hostMidi',false);}
                  await new Promise(r=>setTimeout(r,200));
                  window.__nativeQa={stage:'complete',audio_id:captured.audio_id,capture_duration:captured.duration,capture_origin:captured.origin,job_id:state.result.id,device,predicted_notes:predictedNotes,edited_notes:state.notes.length,export_bytes:midi.size,native_bridge:true,selected_file:selectedFile.path,all_file:allFile.path,stale_drag_rejected:staleRejected,comparison_lanes:lanes.length,normal_roll_height:normalHeight,full_roll_height:fullHeight,drag_readiness:true,layout_width:innerWidth};
                }catch(e){window.__nativeQa={error:String(e.stack||e)};}})())JS");
            }
            else if(performanceOnly && value["stage"].toString()=="performance-complete")
            {
                value.getDynamicObject()->setProperty("standalone",standalone);
                report.replaceWithText(juce::JSON::toString(value,false));setApplicationReturnValue(0);stage=4;quit();return;
            }
            else if (stage==2 && value["stage"].toString()=="complete")
            {
                const auto peak=runner->peak.load();const auto notes=runner->noteOns.load();
                if (peak<=.0001f || (!standalone && notes<1)) {fail("Native audio/MIDI output was silent: peak="+juce::String(peak)+", MIDI="+juce::String(notes));return;}
                if (value["device"].toString()!="cuda") {fail("The native test did not use CUDA");return;}
                const auto selectedPath=juce::File(value["selected_file"].toString());
                const auto allPath=juce::File(value["all_file"].toString());
                auto countNotes=[](const juce::File& path,double& firstOn)
                {
                    auto stream=path.createInputStream();juce::MidiFile midi;
                    if (!stream || !midi.readFrom(*stream)) return -1;
                    midi.convertTimestampTicksToSeconds();int count=0;firstOn=1e10;
                    for (int i=0;i<midi.getNumTracks();++i)
                        for (const auto* event : *midi.getTrack(i))
                            if (event->message.isNoteOn()) {++count;firstOn=juce::jmin(firstOn,event->message.getTimeStamp());}
                    return count;
                };
                double selectedStart=0,allStart=0;
                const auto selectedCount=countNotes(selectedPath,selectedStart),allCount=countNotes(allPath,allStart);
                if (selectedPath==allPath || selectedCount!=1 || allCount!=static_cast<int>(value["edited_notes"]) || selectedStart>.002)
                {fail("Selected MIDI snapshot was not isolated, rebased or immutable");return;}
                value.getDynamicObject()->setProperty("selected_export_notes",selectedCount);
                value.getDynamicObject()->setProperty("immutable_midi_snapshots",true);
                juce::MemoryBlock saved;processor->getStateInformation(saved);
                juce::MemoryInputStream input(saved,false);expectedTake=juce::JSON::parse(input.readString())["take"].toString();
                // A freshly published UI snapshot must survive a host save
                // even before asynchronous playback preparation has run.
                juce::MemoryInputStream savedInput(saved,false);
                const auto savedObject=juce::JSON::parse(savedInput.readString());
                auto fastSave=std::make_unique<LocalMidiProcessor>();fastSave->setUiState(savedObject["ui"]);
                juce::MemoryBlock fastBytes;fastSave->getStateInformation(fastBytes);
                juce::MemoryInputStream fastInput(fastBytes,false);
                if (juce::JSON::parse(fastInput.readString())["take"].toString()!=expectedTake)
                {fail("An immediate host save lost the UI note snapshot");return;}
                value.getDynamicObject()->setProperty("immediate_save_snapshot",true);
                restored=std::make_unique<LocalMidiProcessor>();restored->prepareToPlay(48000,480);restored->setStateInformation(saved.getData(),static_cast<int>(saved.getSize()));
                value.getDynamicObject()->setProperty("saved_project_bytes",static_cast<juce::int64>(saved.getSize()));
                value.getDynamicObject()->setProperty("preview_peak",peak);value.getDynamicObject()->setProperty("host_midi_note_ons",notes);
                value.getDynamicObject()->setProperty("standalone",standalone);value.getDynamicObject()->setProperty("ok",true);
                value.getDynamicObject()->setProperty("real_piano_fixture",runner->pianoFixture);
                pendingReport=value;stage=3;
            }
        });
    }
    bool standalone=false,busy=false,performanceOnly=false;
    int stage=0;
    double started=0;
    juce::File report;
    juce::var pendingReport;
    juce::String expectedTake;
    std::unique_ptr<LocalMidiProcessor> processor;
    std::unique_ptr<LocalMidiProcessor> restored;
    std::unique_ptr<AudioRunner> runner;
    std::unique_ptr<Window> window;
    juce::AudioProcessorEditor* editor=nullptr;
    juce::WebBrowserComponent* browser=nullptr;
};
START_JUCE_APPLICATION(NativeQaApplication)
