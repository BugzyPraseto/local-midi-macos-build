#include "../Source/MidiTimeline.h"
#include <iostream>
#include <stdexcept>

int main()
{
    try
    {
        auto data=juce::JSON::parse(R"({"notes":[{"start":1.25,"end":2.0,"pitch":60,"velocity":53},{"start":2.0,"end":2.5,"pitch":60,"velocity":90}],"controls":[{"time":1,"number":64,"value":127}],"pitch_bends":[{"time":1.5,"pitch":1200}]})");
        const auto timeline=MidiTimeline::fromJson(data);
        juce::MidiBuffer first;timeline.addBlock(first,1.0,12000,48000);
        for (const auto item : first) if (item.getMessage().isNoteOn()) throw std::runtime_error("Block-end note was emitted too early");
        juce::MidiBuffer next;timeline.addBlock(next,1.25,36001,48000);
        int notes=0;bool off=false,onAfterOff=false;
        for (const auto item : next)
        {
            const auto message=item.getMessage();
            if (message.isNoteOn()) { ++notes;if (message.getVelocity()==53 && item.samplePosition!=0) throw std::runtime_error("Leading timing changed"); }
            if (item.samplePosition==36000 && message.isNoteOff()) off=true;
            if (item.samplePosition==36000 && message.isNoteOn()) onAfterOff=off;
        }
        if (notes!=2 || !onAfterOff) throw std::runtime_error("Repeated-note event order is wrong");
        juce::MidiBuffer restart;timeline.restartAt(restart,1.75);
        bool held=false,pedal=false,bend=false;
        for (const auto item : restart)
        {
            auto message=item.getMessage();held|=message.isNoteOn()&&message.getVelocity()==53;
            pedal|=message.isControllerOfType(64)&&message.getControllerValue()==127;
            bend|=message.isPitchWheel()&&message.getPitchWheelValue()==9392;
        }
        if (!held||!pedal||!bend) throw std::runtime_error("Seek did not restore MIDI state");
        const auto sustained=MidiTimeline::fromJson(juce::JSON::parse(R"({"notes":[{"start":0,"end":0.5,"pitch":64,"velocity":80}],"controls":[{"time":0,"number":64,"value":127},{"time":2,"number":64,"value":0}]})"));
        juce::MidiBuffer heldByPedal;sustained.restartAt(heldByPedal,1);
        bool pedalNote=false;
        for (const auto event : heldByPedal) pedalNote|=event.getMessage().isNoteOn();
        if (!pedalNote) throw std::runtime_error("Seek dropped a pedal-sustained note");
        bool rejected=false;
        try { MidiTimeline::fromJson(juce::JSON::parse(R"({"notes":[{"start":2,"end":1,"pitch":60}]})")); }
        catch (...) { rejected=true; }
        if (!rejected) throw std::runtime_error("Invalid note was accepted");
        std::cout<<"MIDI timing, block boundaries, note ordering, seek state and validation passed.\n";
        return 0;
    }
    catch (const std::exception& error) { std::cerr<<error.what()<<'\n';return 1; }
}
