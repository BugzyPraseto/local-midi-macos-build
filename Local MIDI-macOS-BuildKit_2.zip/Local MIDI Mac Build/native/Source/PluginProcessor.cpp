#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <mutex>

namespace
{
juce::var object(std::initializer_list<std::pair<juce::String,juce::var>> fields)
{
    auto* result = new juce::DynamicObject();
    for (const auto& entry : fields) result->setProperty(entry.first,entry.second);
    return juce::var(result);
}
juce::var success() { return object({{"ok",true}}); }
juce::var failure(const juce::String& error) { return object({{"ok",false},{"error",error}}); }

// Immutable sample sounds are shared across instances. Decoding occurs on a loader
// thread, never in processBlock. Each instance has its own voices and envelopes.
struct SampleLibrary
{
    std::mutex mutex;
    std::map<juce::String,std::vector<juce::SynthesiserSound::Ptr>> banks;
    std::unique_ptr<juce::Synthesiser> create(const juce::File& root, const juce::String& instrument,
                                              const std::atomic<bool>& stopping)
    {
        std::lock_guard<std::mutex> lock(mutex);
        const auto path = root.getChildFile("static/samples/"+instrument+".json");
        const auto key=path.getFullPathName();
        if (banks.find(key)==banks.end())
        {
            auto bank=juce::JSON::parse(path);
            auto* properties=bank.getDynamicObject();
            if (properties==nullptr) throw std::runtime_error("Local preview samples are missing. Run Setup.cmd.");
            juce::AudioFormatManager formats; formats.registerBasicFormats();
            std::vector<juce::SynthesiserSound::Ptr> sounds;
            for (const auto& item : properties->getProperties())
            {
                if (stopping.load()) return {};
                juce::MemoryOutputStream bytes;
                const auto encoded=item.value.toString().fromFirstOccurrenceOf(",",false,false);
                if (!juce::Base64::convertFromBase64(bytes,encoded)) throw std::runtime_error("Invalid preview sample");
                auto input=std::make_unique<juce::MemoryInputStream>(bytes.getData(),bytes.getDataSize(),true);
                std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(std::move(input)));
                if (!reader) throw std::runtime_error("Could not decode local MP3 preview samples");
                const int pitch=item.name.toString().getIntValue();
                juce::BigInteger range; range.setBit(pitch);
                sounds.emplace_back(new juce::SamplerSound(instrument,*reader,range,pitch,.003,.12,12.0));
            }
            banks.emplace(key,std::move(sounds));
        }
        auto synth=std::make_unique<juce::Synthesiser>();
        for (int voice=0;voice<64;++voice) synth->addVoice(new juce::SamplerVoice());
        for (const auto& sound : banks.at(key)) synth->addSound(sound);
        return synth;
    }
};
}

LocalMidiProcessor::LocalMidiProcessor()
    : AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true)
                                     .withOutput("Output",juce::AudioChannelSet::stereo(),true))
{
    timeline=std::make_unique<MidiTimeline>();
}

LocalMidiProcessor::~LocalMidiProcessor()
{
    shuttingDown.store(true);
    stopTimer();
    loader.removeAllJobs(true,-1);
    finishCapture();
    diskThread.stopThread(3000);
}

bool LocalMidiProcessor::validId(const juce::String& id)
{ return id.length()==32 && id.containsOnly("0123456789abcdef"); }

void LocalMidiProcessor::prepareToPlay(double rate,int block)
{
    const juce::ScopedLock audioLock(getCallbackLock());
    currentRate.store(rate);
    synthBuffer.setSize(2,juce::jmax(8192,block));
    previewEvents.ensureSize(65536); chunkEvents.ensureSize(65536);
    if (sampler) sampler->setCurrentPlaybackSampleRate(rate);
    resetPreview.store(true); resetHost.store(true);
}
void LocalMidiProcessor::releaseResources()
{
    previewPlaying.store(false);
    currentRate.store(0);
    if (activeWriter.load()!=nullptr) finishRequested.store(1);
    resetHost.store(true);
}
bool LocalMidiProcessor::isBusesLayoutSupported(const BusesLayout& layout) const
{
    const auto output=layout.getMainOutputChannelSet();
    return (output==juce::AudioChannelSet::mono() || output==juce::AudioChannelSet::stereo())
           && layout.getMainInputChannelSet()==output;
}

void LocalMidiProcessor::processBlock(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    bypassed.store(false);
    const auto rate=currentRate.load();
    if (rate<=0) {if (isStandalone()) audio.clear();return;}
    bool positionAvailable=false;
    if (auto* playhead=getPlayHead())
        if (auto info=playhead->getPosition())
        {
            hostPlaying.store(info->getIsPlaying());
            if (auto seconds=info->getTimeInSeconds()) { hostSeconds.store(*seconds); positionAvailable=true; }
            else if (auto samples=info->getTimeInSamples()) { hostSeconds.store(static_cast<double>(*samples)/rate); positionAvailable=true; }
            if (auto bpm=info->getBpm()) hostBpm.store(*bpm);
        }
    hostPositionKnown.store(positionAvailable);
    if (auto* writer=activeWriter.load())
    {
        const bool captureNow=isStandalone() || !positionAvailable || hostPlaying.load();
        const auto frames=captureFrames.load();
        const auto time=hostSeconds.load();
        if (rate!=captureRate.load() || getTotalNumInputChannels()!=captureChannels) finishRequested.store(3);
        else if ((!captureNow && frames>0) || (frames>0 && positionAvailable && capturePreviousHostEnd>=0
                  && std::abs(time-capturePreviousHostEnd)>juce::jmax(.1,audio.getNumSamples()/rate*2))) finishRequested.store(1);
        else if (captureNow && finishRequested.load()==0)
        {
            if (frames==0) captureOrigin.store(positionAvailable ? time : 0);
            if (writer->write(audio.getArrayOfReadPointers(),audio.getNumSamples()))
                captureFrames.fetch_add(audio.getNumSamples());
            else finishRequested.store(4);
            capturePreviousHostEnd=positionAvailable ? time+audio.getNumSamples()/rate : -1;
            if (captureFrames.load()>=static_cast<juce::int64>(rate*1800)) finishRequested.store(1);
        }
    }
    for (int channel=getTotalNumInputChannels();channel<audio.getNumChannels();++channel) audio.clear(channel,0,audio.getNumSamples());
    if (isStandalone()) audio.clear(); // Never monitor a live microphone by default.
    renderPreview(audio);
    renderHostMidi(midi,audio.getNumSamples());
}

void LocalMidiProcessor::processBlockBypassed(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi)
{
    bypassed.store(true);previewPlaying.store(false);
    if (hostWasSending) MidiTimeline::allOff(midi);
    hostWasSending=false;resetHost.store(true);resetPreview.store(true);
    if (sampler) sampler->allNotesOff(0,false);
    if (activeWriter.load()!=nullptr) finishRequested.store(1);
    if (isStandalone()) audio.clear();
}

void LocalMidiProcessor::renderPreview(juce::AudioBuffer<float>& output)
{
    const auto rate=currentRate.load();
    const bool playing=previewPlaying.load();
    const auto requested=seekTo.exchange(-1);
    bool restart=resetPreview.exchange(false) || requested>=0 || (playing && !previewWasPlaying);
    if (requested>=0) position.store(requested);
    if ((!playing && previewWasPlaying) || restart)
        if (sampler) sampler->allNotesOff(0,false);
    previewWasPlaying=playing;
    if (!playing || rate<=0) return;
    output.clear();
    const double start=position.load();
    const int samples=output.getNumSamples();
    const float original=static_cast<float>(originalGain.load()*volume.load());
    const float musical=static_cast<float>(midiGain.load()*volume.load());
    if (sourceAudio && original>0)
    {
        const auto& source=sourceAudio->samples;
        for (int frame=0;frame<samples;++frame)
        {
            const double sourcePosition=(start+frame/rate)*sourceAudio->sampleRate;
            const auto index=static_cast<juce::int64>(sourcePosition);
            if (index<0 || index>=source.getNumSamples()) continue;
            const float fraction=static_cast<float>(sourcePosition-index);
            for (int channel=0;channel<output.getNumChannels();++channel)
            {
                const auto* data=source.getReadPointer(juce::jmin(channel,source.getNumChannels()-1));
                const auto at=[&](juce::int64 i) { return data[juce::jlimit(0,source.getNumSamples()-1,static_cast<int>(i))]; };
                const float a=at(index-1),b=at(index),c=at(index+1),d=at(index+2);
                const float value=b+.5f*fraction*(c-a+fraction*(2*a-5*b+4*c-d+fraction*(3*(b-c)+d-a)));
                output.setSample(channel,frame,value*original);
            }
        }
    }
    if (sampler && timeline && musical>0 && synthBuffer.getNumSamples()>0)
    {
        previewEvents.clear();
        if (restart) timeline->restartAt(previewEvents,start);
        timeline->addBlock(previewEvents,start,samples,rate);
        for (int base=0;base<samples;base+=synthBuffer.getNumSamples())
        {
            const auto count=juce::jmin(synthBuffer.getNumSamples(),samples-base);
            synthBuffer.clear();chunkEvents.clear();
            chunkEvents.addEvents(previewEvents,base,count,-base);
            sampler->renderNextBlock(synthBuffer,chunkEvents,0,count);
            for (int channel=0;channel<output.getNumChannels();++channel)
                output.addFrom(channel,base,synthBuffer,juce::jmin(channel,1),0,count,musical);
        }
    }
    const double end=start+samples/rate;
    position.store(end);
    const double duration=juce::jmax(sourceAudio ? sourceAudio->duration : 0,timeline ? timeline->duration : 0);
    if (end>=duration+.15) { previewPlaying.store(false); position.store(0); }
}

void LocalMidiProcessor::renderHostMidi(juce::MidiBuffer& output,int samples)
{
    const bool sending=!isStandalone() && hostMidiEnabled.load() && hostPlaying.load()
                       && hostPositionKnown.load() && !loadingTake.load() && timeline;
    const auto rate=currentRate.load();
    const double start=hostSeconds.load()-midiOffset.load();
    const bool discontinuity=resetHost.exchange(false) || (hostWasSending && std::abs(start-previousHostEnd)>juce::jmax(.02,samples/rate));
    if (hostWasSending && (!sending || discontinuity)) MidiTimeline::allOff(output);
    if (sending)
    {
        if (!hostWasSending || discontinuity) timeline->restartAt(output,start);
        timeline->addBlock(output,start,samples,rate);
        previousHostEnd=start+samples/rate;
    }
    hostWasSending=sending;
}

void LocalMidiProcessor::setPlayback(bool playing,double seconds)
{
    if (std::isfinite(seconds) && seconds>=0) seekTo.store(seconds);
    previewPlaying.store(playing);
}
void LocalMidiProcessor::setMix(const juce::var& settings)
{
    const auto mode=settings.getProperty("mode","original").toString();
    const double blend=mode=="original" ? 0 : mode=="midi" ? 1 : juce::jlimit(0.0,1.0,static_cast<double>(settings.getProperty("blend",.5)));
    originalGain.store(1-blend); midiGain.store(blend);
    volume.store(juce::jlimit(0.0,1.0,static_cast<double>(settings.getProperty("volume",.7)))*.75);
    resetPreview.store(true);
}
void LocalMidiProcessor::setError(const juce::String& error) { const juce::ScopedLock lock(stateLock); lastError=error; }
void LocalMidiProcessor::setUiState(const juce::var& value) { const juce::ScopedLock lock(stateLock); uiState=value; }

void LocalMidiProcessor::loadSource(const juce::String& id,Completion completion,bool preserveTake)
{
    if (!validId(id)) { completion(failure("Invalid audio identifier")); return; }
    previewPlaying.store(false);
    bool changed=false;
    { const juce::ScopedLock lock(stateLock);changed=sourceId!=id; }
    if (changed && !preserveTake) {hostMidiEnabled.store(false);resetHost.store(true);}
    loader.addJob([this,id,changed,preserveTake,completion=std::move(completion)]
    {
        if (shuttingDown.load()) return;
        try
        {
            juce::AudioFormatManager formats;formats.registerBasicFormats();
            const auto file=backend->getData().getChildFile("audio/"+id+"/source.wav");
            std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(file));
            if (!reader || reader->lengthInSamples<=0 || reader->lengthInSamples>2147483647LL)
                throw std::runtime_error("The source recording is missing or too large");
            auto next=std::make_unique<SourceAudio>();
            next->samples.setSize(juce::jmin(2,static_cast<int>(reader->numChannels)),static_cast<int>(reader->lengthInSamples));
            if (!reader->read(&next->samples,0,next->samples.getNumSamples(),0,true,true))
                throw std::runtime_error("Could not read the source recording");
            next->sampleRate=reader->sampleRate;next->duration=reader->lengthInSamples/reader->sampleRate;
            if (shuttingDown.load()) return;
            std::unique_ptr<SourceAudio> previous;
            std::unique_ptr<MidiTimeline> previousTake;
            auto empty=std::make_unique<MidiTimeline>();
            { const juce::ScopedLock audioLock(getCallbackLock());previous=std::move(sourceAudio);sourceAudio=std::move(next);position.store(0);resetPreview.store(true);
              if (changed && !preserveTake) {previousTake=std::move(timeline);timeline=std::move(empty);resetHost.store(true);} }
            { const juce::ScopedLock lock(stateLock); sourceId=id; lastError={};if (changed && !preserveTake) lastTakeJson={}; }
            completion(success());
        }
        catch (const std::exception& error) { setError(error.what());completion(failure(error.what())); }
    });
}

void LocalMidiProcessor::loadTake(juce::var payload,Completion completion)
{
    const auto serialized=juce::JSON::toString(payload,true);
    { const juce::ScopedLock lock(stateLock);
      if (!loadingTake.load() && lastTakeJson==serialized) { completion(success());return; } }
    loadingTake.store(true);
    loader.addJob([this,payload=std::move(payload),serialized,completion=std::move(completion)]
    {
        if (shuttingDown.load()) return;
        try
        {
            auto next=std::make_unique<MidiTimeline>(MidiTimeline::fromJson(payload));
            static SampleLibrary library;
            const auto instrument=payload.getProperty("instrument","piano").toString()=="guitar" ? juce::String("guitar") : juce::String("piano");
            auto nextSampler=library.create(backend->getRoot(),instrument,shuttingDown);
            if (!nextSampler || shuttingDown.load()) return;
            std::unique_ptr<MidiTimeline> previous;
            std::unique_ptr<juce::Synthesiser> previousSampler;
            { const juce::ScopedLock audioLock(getCallbackLock());
              nextSampler->setCurrentPlaybackSampleRate(currentRate.load()>0 ? currentRate.load() : 44100.0);
              previous=std::move(timeline);previousSampler=std::move(sampler);
              timeline=std::move(next);sampler=std::move(nextSampler);
              resetPreview.store(true);resetHost.store(true); }
            { const juce::ScopedLock lock(stateLock);lastTakeJson=serialized;lastError={}; }
            loadingTake.store(false);
            completion(success());
        }
        catch (const std::exception& error) { loadingTake.store(false);hostMidiEnabled.store(false);setError(error.what());completion(failure(error.what())); }
    });
}

juce::var LocalMidiProcessor::startCapture()
{
    previewPlaying.store(false);hostMidiEnabled.store(false);resetHost.store(true);
    if (activeWriter.load()!=nullptr) return failure("A capture is already running");
    if (bypassed.load()) return failure("Enable the plug-in before capturing audio.");
    const auto rate=currentRate.load();
    const int channels=getTotalNumInputChannels();
    if (rate<=0 || channels<1 || channels>2) return failure("Start the audio engine with a mono or stereo input first");
    const auto id=juce::Uuid().toString().removeCharacters("-");
    const auto folder=backend->getData().getChildFile("native-captures");
    if (folder.createDirectory().failed()) return failure("Could not create the capture folder");
    std::unique_ptr<juce::OutputStream> stream=folder.getChildFile(id+".wav").createOutputStream();
    if (!stream) return failure("Could not open the capture file");
    juce::WavAudioFormat format;
    auto writer=format.createWriterFor(stream,juce::AudioFormatWriterOptions().withSampleRate(rate).withNumChannels(channels)
        .withBitsPerSample(32).withSampleFormat(juce::AudioFormatWriterOptions::SampleFormat::floatingPoint));
    if (!writer) return failure("Could not create the WAV writer");
    diskThread.startThread();
    auto threaded=std::make_unique<juce::AudioFormatWriter::ThreadedWriter>(writer.release(),diskThread,131072);
    { const juce::ScopedLock audioLock(getCallbackLock());
      captureFrames.store(0);captureRate.store(rate);captureOrigin.store(hostSeconds.load());
      capturePreviousHostEnd=-1;captureChannels=channels;finishRequested.store(0);
      captureWriter=std::move(threaded);activeWriter.store(captureWriter.get()); }
    captureId=id;capturePhase="recording";captureError={};
    startTimerHz(10);
    return object({{"ok",true},{"id",id}});
}

void LocalMidiProcessor::finishCapture()
{
    std::unique_ptr<juce::AudioFormatWriter::ThreadedWriter> stopped;
    { const juce::ScopedLock audioLock(getCallbackLock());activeWriter.store(nullptr);stopped=std::move(captureWriter); }
    if (!stopped) return;
    stopped.reset(); // Flush on the control thread, after releasing the audio lock.
    const int reason=finishRequested.exchange(0);
    if (reason==3 || reason==4 || captureFrames.load()==0)
    {
        capturePhase="error";
        captureError=reason==4 ? "Capture overflowed. Retry with fewer active tasks or a faster disk."
                     : reason==3 ? "Audio rate/layout changed during capture. Please record again."
                     : "No audio was captured. Start DAW playback after arming capture.";
    }
    else capturePhase="ready";
    stopTimer();
}
void LocalMidiProcessor::consumeCapture() { if (capturePhase=="ready" || capturePhase=="error") capturePhase="idle"; }
void LocalMidiProcessor::timerCallback() { if (finishRequested.load()!=0) finishCapture(); }

juce::var LocalMidiProcessor::getNativeState(bool includeUi) const
{
    juce::var ui; juce::String error;
    { const juce::ScopedLock lock(stateLock);if (includeUi) ui=uiState;error=lastError; }
    return object({{"ok",true},{"standalone",isStandalone()},{"instance_id",instanceId},
        {"ui",ui},{"playing",previewPlaying.load()},{"position",position.load()},
        {"host_playing",hostPlaying.load()},{"host_position",hostSeconds.load()},
        {"host_position_known",hostPositionKnown.load()},{"bpm",hostBpm.load()},
        {"host_midi",hostMidiEnabled.load()},{"offset",midiOffset.load()},
        {"sample_rate",currentRate.load()},{"loading_take",loadingTake.load()},{"error",error},
        {"bypassed",bypassed.load()},
        {"capture",object({{"id",captureId},{"phase",capturePhase},{"error",captureError},
            {"seconds",static_cast<double>(captureFrames.load())/captureRate.load()},{"origin",captureOrigin.load()}})}});
}

void LocalMidiProcessor::getStateInformation(juce::MemoryBlock& destination)
{
    juce::var ui;juce::String take;
    { const juce::ScopedLock lock(stateLock);ui=uiState;take=lastTakeJson; }
    // UI edits are published immediately; sampler/file preparation is debounced.
    // A host save in that interval must still serialize the latest note edits.
    const auto selectedJob=ui.getProperty("job_id",{}).toString();
    const auto currentTake=ui.getProperty("take_edits",{}).getProperty(selectedJob,{});
    if (currentTake.isObject() && currentTake.getProperty("notes",{}).isArray())
        take=juce::JSON::toString(currentTake,false);
    const auto state=object({{"version",1},{"ui",ui},{"take",take},
        {"host_midi",hostMidiEnabled.load()},{"offset",midiOffset.load()}});
    juce::MemoryOutputStream stream(destination,false);stream.writeString(juce::JSON::toString(state,true));
}
void LocalMidiProcessor::setStateInformation(const void* data,int size)
{
    if (size<=0 || size>128*1024*1024) return;
    juce::MemoryInputStream stream(data,static_cast<size_t>(size),false);
    auto state=juce::JSON::parse(stream.readString());
    if (static_cast<int>(state.getProperty("version",0))!=1) return;
    const auto ui=state.getProperty("ui",{});setUiState(ui);
    setPlacement(static_cast<double>(state.getProperty("offset",0)));
    auto take=juce::JSON::parse(state.getProperty("take",{}).toString());
    if (take.isObject()) loadTake(take,[](juce::var){});
    auto id=ui.getProperty("audio_id",{}).toString();
    if (validId(id)) loadSource(id,[](juce::var){},true);
    hostMidiEnabled.store(static_cast<bool>(state.getProperty("host_midi",false)));
}

juce::AudioProcessorEditor* LocalMidiProcessor::createEditor() { return new LocalMidiEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new LocalMidiProcessor(); }
