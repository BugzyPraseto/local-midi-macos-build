#include "BackendService.h"

BackendService::BackendService() : Thread("Local MIDI engine startup")
{
    const auto overridePath = juce::SystemStats::getEnvironmentVariable("LOCALMIDI_ROOT", {});
   #if JUCE_MAC
    root = juce::File(overridePath.isNotEmpty() ? overridePath
                                              : juce::String("/Library/Application Support/Local MIDI/Engine"));
   #else
    root = juce::File(overridePath.isNotEmpty() ? overridePath : juce::String(LOCALMIDI_PROJECT_ROOT));
   #endif
    const auto configuration = juce::File::getSpecialLocation(juce::File::currentExecutableFile)
                                   .getSiblingFile("Local MIDI.engine.json");
    if (overridePath.isEmpty() && configuration.existsAsFile())
    {
        auto value = juce::JSON::parse(configuration);
        auto configured = value.getProperty("project_root", {}).toString();
        if (configured.isNotEmpty()) root = juce::File(configured);
    }
   #if JUCE_MAC
    const auto defaultData = juce::File::getSpecialLocation(juce::File::userHomeDirectory)
                                 .getChildFile("Library/Application Support/Local MIDI");
   #else
    const auto defaultData = root.getChildFile(".local");
   #endif
    data = juce::File(juce::SystemStats::getEnvironmentVariable("LOCALMIDI_DATA", defaultData.getFullPathName()));
}

BackendService::~BackendService() { signalThreadShouldExit(); stopThread(3000); }
void BackendService::ensureRunning() { if (!isThreadRunning()) { ready.store(false);startThread(); } }
juce::String BackendService::getMessage() const { const juce::ScopedLock lock(messageLock); return message; }
void BackendService::setMessage(const juce::String& text) { const juce::ScopedLock lock(messageLock); message = text; }

bool BackendService::checkHealth()
{
    int status = 0;
    auto stream = juce::URL(getUrl() + "/api/health").createInputStream(
        juce::URL::InputStreamOptions(juce::URL::ParameterHandling::inAddress)
            .withConnectionTimeoutMs(900).withStatusCode(&status));
    if (!stream || status != 200) return false;
    auto response = juce::JSON::parse(stream->readEntireStreamAsString());
    if (response.getProperty("application", {}).toString() != "localmidi") return false;
    if (juce::File(response.getProperty("root", {}).toString()) != root)
    {
        setMessage("Port 8765 is serving a different Local MIDI installation. Stop it and retry.");
        return false;
    }
    auto location=response.getProperty("data",{}).toString();
   #if JUCE_MAC
    // A shared installed engine must not attach one login to another user's library.
    if (location.isEmpty() || juce::File(location) != getData())
    {
        setMessage("Port 8765 is serving Local MIDI with a different user's data directory. "
                   "Close that engine before opening this user's Local MIDI library.");
        return false;
    }
   #else
    if (location.isNotEmpty()) {const juce::ScopedLock lock(messageLock);data=juce::File(location);}
   #endif
    return true;
}

void BackendService::run()
{
   #if JUCE_MAC
    setMessage("Starting the local transcription engine...");
   #endif
    if (checkHealth()) { ready.store(true); return; }
   #if JUCE_MAC
    if (getMessage().startsWith("Port 8765")) return;
    const auto script = root.getChildFile("StartMac.sh");
    const auto python = root.getChildFile("runtime/bin/python3");
    constexpr int startupAttempts = 100;
   #else
    const auto script = root.getChildFile("Start.ps1");
    const auto python = root.getChildFile(".venv/Scripts/python.exe");
    constexpr int startupAttempts = 45;
   #endif
    if (!script.existsAsFile() || !python.existsAsFile())
    {
       #if JUCE_MAC
        setMessage("The Mac transcription engine is missing. Reinstall Local MIDI, or set LOCALMIDI_ROOT "
                   "to a configured engine. Expected engine: " + root.getFullPathName());
       #else
        setMessage("The local engine is missing. Run Setup.cmd in " + root.getFullPathName()
                   + ". Set LOCALMIDI_ROOT if the project has moved.");
       #endif
        return;
    }
    juce::InterProcessLock startupLock("LocalMidiEngineStartup8765");
    if (!startupLock.enter(1000))
    {
       #if JUCE_MAC
        constexpr int otherInstanceAttempts = startupAttempts;
       #else
        constexpr int otherInstanceAttempts = 30;
       #endif
        for (int attempt = 0; attempt < otherInstanceAttempts && !threadShouldExit(); ++attempt)
        {
            if (checkHealth()) { ready.store(true); return; }
           #if JUCE_MAC
            if (getMessage().startsWith("Port 8765")) return;
           #endif
            wait(300);
        }
        setMessage("Another instance is starting the engine. Close and reopen this editor to retry.");
        return;
    }
    if (!checkHealth())
    {
       #if JUCE_MAC
        if (getMessage().startsWith("Port 8765")) { startupLock.exit(); return; }
       #endif
        juce::ChildProcess launcher;
       #if JUCE_MAC
        const auto started = launcher.start(juce::StringArray {
            "/bin/bash", script.getFullPathName(), "--background" }, 0);
        if (!started) setMessage("Could not launch the Mac transcription engine. Reinstall Local MIDI "
                                 "and check ~/Library/Logs/Local MIDI for details.");
       #else
        const auto started = launcher.start(juce::StringArray {
            "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
            script.getFullPathName(), "-NoBrowser" }, 0);
        if (!started) setMessage("Could not launch the engine. Run Start.cmd in the project folder.");
       #endif
        for (int attempt = 0; started && attempt < startupAttempts && !threadShouldExit(); ++attempt)
        {
            if (checkHealth()) { ready.store(true); break; }
           #if JUCE_MAC
            if (getMessage().startsWith("Port 8765")) break;
           #endif
            wait(300);
        }
    }
    else ready.store(true);
    startupLock.exit();
    if (!ready.load() && !threadShouldExit())
    {
       #if JUCE_MAC
        if (!getMessage().startsWith("Port 8765"))
            setMessage("Mac engine unavailable. Check ~/Library/Logs/Local MIDI/engine.log, "
                       "then retry. Reinstall Local MIDI if the installed engine is incomplete.");
       #else
        setMessage("Engine unavailable or out of date. Run Stop.cmd, then Start.cmd in " + root.getFullPathName()
                   + ". Check .local/server-error.log for details.");
       #endif
    }
}

