#pragma once
#include <juce_audio_basics/juce_audio_basics.h>

struct MidiTimeline
{
    struct Event { double seconds; juce::MidiMessage message; };
    std::vector<Event> events;
    double duration = 0;
    static MidiTimeline fromJson(const juce::var&);
    void addBlock(juce::MidiBuffer&, double startSeconds, int samples, double sampleRate) const;
    void restartAt(juce::MidiBuffer&, double seconds) const;
    static void allOff(juce::MidiBuffer&, int sample = 0);
};

