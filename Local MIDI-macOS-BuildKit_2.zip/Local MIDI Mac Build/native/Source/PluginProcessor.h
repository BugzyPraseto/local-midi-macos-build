#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "BackendService.h"
#include "MidiTimeline.h"
#include <cmath>

class LocalMidiProcessor final : public juce::AudioProcessor, private juce::Timer
{
public:
    LocalMidiProcessor();
    ~LocalMidiProcessor() override;
    void prepareToPlay(double, int) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Local MIDI"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    double getTailLengthSeconds() const override { return 0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int,const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*,int) override;

    using Completion = std::function<void(juce::var)>;
    void loadSource(const juce::String&, Completion, bool preserveTake=false);
    void loadTake(juce::var, Completion);
    void setUiState(const juce::var&);
    juce::var getNativeState(bool includeUi=false) const;
    juce::var startCapture();
    void finishCapture();
    void consumeCapture();
    void setPlayback(bool playing, double seconds);
    void setMix(const juce::var&);
    void setHostMidi(bool enabled) { hostMidiEnabled.store(enabled); }
    void setPlacement(double seconds) { if (std::isfinite(seconds)) { midiOffset.store(juce::jlimit(-86400.0,86400.0,seconds)); resetHost.store(true); } }
    void placeAtPlayhead() { setPlacement(hostSeconds.load()); }
    bool isStandalone() const { return wrapperType == wrapperType_Standalone; }
    BackendService& engine() { return *backend; }
    const juce::String instanceId { juce::Uuid().toString().removeCharacters("-") };

private:
    struct SourceAudio { juce::AudioBuffer<float> samples; double sampleRate=44100, duration=0; };
    void timerCallback() override;
    void renderPreview(juce::AudioBuffer<float>&);
    void renderHostMidi(juce::MidiBuffer&, int);
    void setError(const juce::String&);
    static bool validId(const juce::String&);

    // The worker finishes/cancels before any processor resources are destroyed.
    juce::SharedResourcePointer<BackendService> backend;
    juce::ThreadPool loader { 1 };
    std::atomic<bool> shuttingDown { false }, loadingTake { false };
    mutable juce::CriticalSection stateLock;
    juce::var uiState;
    juce::String lastTakeJson, lastError, sourceId;
    std::unique_ptr<SourceAudio> sourceAudio;
    std::unique_ptr<MidiTimeline> timeline;
    std::unique_ptr<juce::Synthesiser> sampler;
    juce::AudioBuffer<float> synthBuffer;
    juce::MidiBuffer previewEvents, chunkEvents;
    std::atomic<double> currentRate { 0 }, hostSeconds { 0 }, hostBpm { 120 }, position { 0 }, seekTo { -1 };
    std::atomic<double> midiOffset { 0 }, originalGain { 1 }, midiGain { 0 }, volume { .525 };
    std::atomic<bool> previewPlaying { false }, hostPlaying { false }, hostPositionKnown { false };
    std::atomic<bool> bypassed { false };
    std::atomic<bool> hostMidiEnabled { false }, resetHost { true }, resetPreview { true };
    bool previewWasPlaying=false, hostWasSending=false;
    double previousHostEnd=0, capturePreviousHostEnd=-1;

    juce::TimeSliceThread diskThread { "Local MIDI capture disk writer" };
    std::unique_ptr<juce::AudioFormatWriter::ThreadedWriter> captureWriter;
    std::atomic<juce::AudioFormatWriter::ThreadedWriter*> activeWriter { nullptr };
    std::atomic<juce::int64> captureFrames { 0 };
    std::atomic<double> captureOrigin { 0 }, captureRate { 44100 };
    std::atomic<int> finishRequested { 0 };
    juce::String captureId, capturePhase { "idle" }, captureError;
    int captureChannels=2;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LocalMidiProcessor)
};

