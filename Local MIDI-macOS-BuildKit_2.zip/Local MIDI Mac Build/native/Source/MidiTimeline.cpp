#include "MidiTimeline.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <stdexcept>

namespace
{
double number(const juce::var& object, const char* key) { return static_cast<double>(object.getProperty(key, 0)); }
int channelFor(const juce::var& object)
{
    if (static_cast<bool>(object.getProperty("is_drum", false))) return 10;
    const int track = juce::jlimit(0, 255, static_cast<int>(object.getProperty("track", 0)));
    const int channel = track % 15 + 1;
    return channel >= 10 ? channel + 1 : channel;
}
}

MidiTimeline MidiTimeline::fromJson(const juce::var& data)
{
    MidiTimeline result;
    if (auto* notes = data.getProperty("notes", {}).getArray())
    {
        if (notes->size() > 100000) throw std::runtime_error("Too many notes");
        result.events.reserve(static_cast<size_t>(notes->size()) * 2);
        for (const auto& note : *notes)
        {
            const double start = number(note, "start"), end = number(note, "end");
            const int pitch = static_cast<int>(note.getProperty("pitch", -1));
            const int velocity = static_cast<int>(note.getProperty("velocity", 80));
            if (!std::isfinite(start) || !std::isfinite(end) || start < 0 || end <= start
                || pitch < 0 || pitch > 127 || velocity < 1 || velocity > 127)
                throw std::runtime_error("Invalid MIDI note");
            const int channel = channelFor(note);
            result.events.push_back({ start, juce::MidiMessage::noteOn(channel, pitch, static_cast<juce::uint8>(velocity)) });
            result.events.push_back({ end, juce::MidiMessage::noteOff(channel, pitch) });
            result.duration = juce::jmax(result.duration, end);
        }
    }
    if (auto* controls = data.getProperty("controls", {}).getArray())
        for (const auto& control : *controls)
        {
            const double time = number(control, "time");
            if (std::isfinite(time) && time >= 0)
                result.events.push_back({ time, juce::MidiMessage::controllerEvent(channelFor(control),
                    juce::jlimit(0,127,static_cast<int>(control.getProperty("number",0))),
                    juce::jlimit(0,127,static_cast<int>(control.getProperty("value",0)))) });
        }
    if (auto* bends = data.getProperty("pitch_bends", {}).getArray())
        for (const auto& bend : *bends)
        {
            const double time = number(bend, "time");
            if (std::isfinite(time) && time >= 0)
                result.events.push_back({ time, juce::MidiMessage::pitchWheel(channelFor(bend),
                    juce::jlimit(0,16383,static_cast<int>(bend.getProperty("pitch",0)) + 8192)) });
        }
    std::stable_sort(result.events.begin(), result.events.end(), [](const auto& a, const auto& b)
    {
        if (a.seconds != b.seconds) return a.seconds < b.seconds;
        const auto priority = [](const auto& message) { return message.isNoteOff() ? 0 : message.isNoteOn() ? 2 : 1; };
        return priority(a.message) < priority(b.message);
    });
    return result;
}

void MidiTimeline::addBlock(juce::MidiBuffer& destination, double start, int samples, double rate) const
{
    if (samples <= 0 || rate <= 0) return;
    auto current = std::lower_bound(events.begin(), events.end(), start,
                                    [](const Event& event, double time) { return event.seconds < time; });
    const double end = start + samples / rate;
    for (; current != events.end() && current->seconds < end; ++current)
        destination.addEvent(current->message, juce::jlimit(0, samples-1, juce::roundToInt((current->seconds-start)*rate)));
}

void MidiTimeline::allOff(juce::MidiBuffer& destination, int sample)
{
    for (int channel = 1; channel <= 16; ++channel)
    {
        destination.addEvent(juce::MidiMessage::controllerEvent(channel,64,0),sample);
        destination.addEvent(juce::MidiMessage::allNotesOff(channel),sample);
        destination.addEvent(juce::MidiMessage::allSoundOff(channel),sample);
        destination.addEvent(juce::MidiMessage::pitchWheel(channel,8192),sample);
    }
}

void MidiTimeline::restartAt(juce::MidiBuffer& destination, double seconds) const
{
    // Reconstruct controller and held-note state when starting/seeking mid-note.
    std::array<std::array<int,128>,16> velocities {};
    std::array<std::array<bool,128>,16> released {};
    std::array<std::array<int,128>,16> controllers;
    std::array<int,16> bends;
    for (auto& row : controllers) row.fill(-1);
    bends.fill(-1);
    for (const auto& event : events)
    {
        if (event.seconds >= seconds) break;
        const auto& message = event.message;
        const auto channel = static_cast<size_t>(message.getChannel()-1);
        if (channel >= 16) continue;
        if (message.isNoteOn()) {velocities[channel][static_cast<size_t>(message.getNoteNumber())] = message.getVelocity();released[channel][static_cast<size_t>(message.getNoteNumber())]=false;}
        if (message.isNoteOff())
        {
            if (controllers[channel][64]>=64) released[channel][static_cast<size_t>(message.getNoteNumber())]=true;
            else velocities[channel][static_cast<size_t>(message.getNoteNumber())]=0;
        }
        if (message.isController())
        {
            controllers[channel][static_cast<size_t>(message.getControllerNumber())] = message.getControllerValue();
            if (message.isControllerOfType(64) && message.getControllerValue()<64)
                for (size_t key=0;key<128;++key) if (released[channel][key]) {velocities[channel][key]=0;released[channel][key]=false;}
        }
        if (message.isPitchWheel()) bends[channel] = message.getPitchWheelValue();
    }
    for (int channel=0;channel<16;++channel)
    {
        if (bends[static_cast<size_t>(channel)] >= 0)
            destination.addEvent(juce::MidiMessage::pitchWheel(channel+1,bends[static_cast<size_t>(channel)]),0);
        for (int key=0;key<128;++key)
        {
            const int control=controllers[static_cast<size_t>(channel)][static_cast<size_t>(key)];
            if (control>=0) destination.addEvent(juce::MidiMessage::controllerEvent(channel+1,key,control),0);
            const int velocity=velocities[static_cast<size_t>(channel)][static_cast<size_t>(key)];
            if (velocity>0)
            {
                destination.addEvent(juce::MidiMessage::noteOn(channel+1,key,static_cast<juce::uint8>(velocity)),0);
                if (released[static_cast<size_t>(channel)][static_cast<size_t>(key)]) destination.addEvent(juce::MidiMessage::noteOff(channel+1,key),0);
            }
        }
    }
}
