#pragma once
#include <juce_gui_extra/juce_gui_extra.h>

// Shared by plug-in instances. Creating/scanning a processor never starts Python.
// Only an editor requests startup. The engine deliberately survives editor close.
class BackendService final : private juce::Thread
{
public:
    BackendService();
    ~BackendService() override;
    void ensureRunning();
    bool isReady() const { return ready.load(); }
    juce::String getMessage() const;
    const juce::File& getRoot() const { return root; }
    juce::File getData() const { const juce::ScopedLock lock(messageLock); return data; }
    juce::String getUrl() const { return "http://127.0.0.1:8765"; }

private:
    void run() override;
    bool checkHealth();
    void setMessage(const juce::String&);
    juce::File root, data;
    mutable juce::CriticalSection messageLock;
    juce::String message { "Starting the local transcription engine…" };
    std::atomic<bool> ready { false };
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(BackendService)
};

