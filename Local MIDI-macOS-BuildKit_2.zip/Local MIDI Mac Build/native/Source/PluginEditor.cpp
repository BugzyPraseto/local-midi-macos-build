#include "PluginEditor.h"
#include <juce_cryptography/juce_cryptography.h>
#include <juce_audio_plugin_client/Standalone/juce_StandaloneFilterWindow.h>

namespace
{
juce::var reply(bool ok,const juce::String& error={})
{
    auto* object=new juce::DynamicObject();object->setProperty("ok",ok);
    if (error.isNotEmpty()) object->setProperty("error",error);
    return juce::var(object);
}
}

bool LocalMidiEditor::Browser::pageAboutToLoad(const juce::String& url)
{
    // Native filesystem functions are exposed only to our trusted loopback UI.
    return url=="about:blank" || url.startsWith("http://127.0.0.1:8765/");
}

LocalMidiEditor::LocalMidiEditor(LocalMidiProcessor& owner) : AudioProcessorEditor(owner),processor(owner)
{
    setResizable(true,true);setResizeLimits(900,650,7680,4320);setSize(1280,900);
    addAndMakeVisible(retry);
    retry.onClick=[this] { processor.engine().ensureRunning(); };
    auto options=juce::WebBrowserComponent::Options()
        .withKeepPageLoadedWhenBrowserIsHidden()
        .withNativeIntegrationEnabled()
        .withNativeFunction("localMidi",[this](const auto& args,auto completion) { command(args,std::move(completion)); });
   #if JUCE_WINDOWS
    options=options
        .withBackend(juce::WebBrowserComponent::Options::Backend::webview2)
        .withWinWebView2Options(juce::WebBrowserComponent::Options::WinWebView2()
            .withUserDataFolder(juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                                .getChildFile("LocalMidi/WebView2"))
            .withBackgroundColour(juce::Colour(0xff061221)));
   #else
    // JUCE's default backend uses the system WKWebView on macOS.
    options=options.withBackend(juce::WebBrowserComponent::Options::Backend::defaultBackend);
   #endif
    if (!juce::WebBrowserComponent::areOptionsSupported(options))
    {
       #if JUCE_WINDOWS
        startupMessage="Microsoft Edge WebView2 Runtime is required. Install the Evergreen WebView2 Runtime, then reopen this window.";
       #else
        startupMessage="The system web browser could not initialize Local MIDI's interface. "
                       "Install available macOS updates and reopen this window.";
       #endif
        retry.setVisible(false);repaint();return;
    }
    browser=std::make_unique<Browser>(options);
    addAndMakeVisible(*browser);browser->setVisible(false);
    processor.engine().ensureRunning();startTimer(250);
    if (processor.isStandalone())
        if (auto* holder=juce::StandalonePluginHolder::getInstance())
            holder->getMuteInputValue().setValue(false); // Processor deliberately does not monitor live input.
    resized();
}

LocalMidiEditor::~LocalMidiEditor() { stopTimer();processor.setPlayback(false,-1);fileChooser.reset();browser.reset(); }
void LocalMidiEditor::paint(juce::Graphics& graphics)
{
    graphics.fillAll(juce::Colour(0xff061221));
    if (pageLoaded) return;
    graphics.setColour(juce::Colour(0xff7ddff5));graphics.setFont(juce::FontOptions(26));
    graphics.drawText("Local MIDI",getLocalBounds().withHeight(100),juce::Justification::centred);
    graphics.setColour(juce::Colour(0xffc4c8cd));graphics.setFont(juce::FontOptions(15));
    graphics.drawFittedText(startupMessage,getLocalBounds().reduced(60).withTrimmedTop(90).withTrimmedBottom(100),juce::Justification::centred,5);
}
void LocalMidiEditor::resized()
{
    if (browser) browser->setBounds(getLocalBounds());
    retry.setBounds(getWidth()/2-100,getHeight()/2+95,200,36);
}
void LocalMidiEditor::timerCallback()
{
    // The stock standalone wrapper enables only Minimise and Close. Wait until
    // the editor is attached before adding Maximise/Restore to its title bar.
    // A DAW owns its plug-in window and must retain control of its decorations.
    if (processor.isStandalone())
        if (auto* window=findParentComponentOfClass<juce::DocumentWindow>(); window && standaloneWindow.getComponent()!=window)
        {
            window->setTitleBarButtonsRequired(juce::DocumentWindow::allButtons,false);
            standaloneWindow=window;
        }
    startupMessage=processor.engine().getMessage();
    if (!pageLoaded && processor.engine().isReady() && browser)
    {
        browser->goToURL(processor.engine().getUrl()+"/?native=1&instance="+processor.instanceId);
        browser->setVisible(true);retry.setVisible(false);pageLoaded=true;
    }
    if (!pageLoaded) repaint();
}

void LocalMidiEditor::command(const juce::Array<juce::var>& args,juce::WebBrowserComponent::NativeFunctionCompletion completion)
{
    if (args.size()<1) { completion(reply(false,"Missing native command"));return; }
    const auto name=args[0].toString();
    const auto payload=args.size()>1 ? args[1] : juce::var();
    if (name=="state") { completion(processor.getNativeState(static_cast<bool>(payload.getProperty("include_ui",false))));return; }
    if (name=="ui") { processor.setUiState(payload);completion(reply(true));return; }
    const auto safe=juce::Component::SafePointer<LocalMidiEditor>(this);
    const auto completeAsync=[safe,completion](juce::var value)
    {
        juce::MessageManager::callAsync([safe,completion,value=std::move(value)] { if (safe) completion(value); });
    };
    if (name=="source") { processor.loadSource(payload.getProperty("id",{}).toString(),completeAsync,static_cast<bool>(payload.getProperty("restore",false)));return; }
    if (name=="take") { processor.loadTake(payload,completeAsync);return; }
    if (name=="play" || name=="seek")
    {
        const auto current=processor.getNativeState();
        if (static_cast<bool>(payload.getProperty("playing",true)) &&
            (static_cast<double>(current["sample_rate"])<=0 || static_cast<bool>(current["bypassed"])))
        { completion(reply(false,processor.isStandalone() ? "Choose an audio device in Audio settings first." : "Enable the plug-in and start your DAW audio engine to audition."));return; }
        processor.setPlayback(static_cast<bool>(payload.getProperty("playing",true)),static_cast<double>(payload.getProperty("seconds",0)));
        completion(reply(true));return;
    }
    if (name=="pause") { processor.setPlayback(false,-1);completion(reply(true));return; }
    if (name=="mix") { processor.setMix(payload);completion(reply(true));return; }
    if (name=="hostMidi") { processor.setHostMidi(static_cast<bool>(payload));completion(reply(true));return; }
    if (name=="placement") { processor.setPlacement(static_cast<double>(payload));completion(reply(true));return; }
    if (name=="placeAtPlayhead") { processor.placeAtPlayhead();completion(reply(true));return; }
    if (name=="captureStart") { completion(processor.startCapture());return; }
    if (name=="captureStop") { processor.finishCapture();completion(reply(true));return; }
    if (name=="captureConsumed") { processor.consumeCapture();completion(reply(true));return; }
    if (name=="audioSettings")
    {
        if (processor.isStandalone())
            if (auto* holder=juce::StandalonePluginHolder::getInstance())
            { holder->showAudioSettingsDialog();completion(reply(true));return; }
        completion(reply(false,"Audio devices are controlled by your DAW."));return;
    }
    if (name=="saveMidi") { saveMidi(payload,std::move(completion));return; }
    if (name=="prepareDrag")
    {
        juce::MemoryBlock bytes;juce::String error;
        if (!decodeMidi(payload,bytes,error)) { completion(reply(false,error));return; }
        const auto folder=processor.engine().getData().getChildFile("native-exports");
        if (folder.createDirectory().failed()) { completion(reply(false,"Could not create MIDI export folder"));return; }
        auto filename=juce::File::createLegalFileName(payload.getProperty("name","transcription.mid").toString());
        if (filename.endsWithIgnoreCase(".mid")) filename=filename.dropLastCharacters(4);
        if (filename.isEmpty()) filename="transcription";
        const auto fingerprint=juce::SHA256(bytes).toHexString();
        const auto candidate=folder.getChildFile(filename.substring(0,90)+"-"+fingerprint.substring(0,16)+".mid");
        // Every prepared MIDI file is immutable. Hosts may keep the file after
        // a drop; later note edits must not change an earlier imported file.
        if (!candidate.existsAsFile() && !candidate.replaceWithData(bytes.getData(),bytes.getSize()))
        { completion(reply(false,"Could not prepare the MIDI file"));return; }
        if (juce::SHA256(candidate).toHexString()!=fingerprint)
        { completion(reply(false,"The prepared MIDI file failed verification"));return; }
        dragFile=candidate;dragRevision=payload.getProperty("revision",{}).toString();
        auto result=reply(true);result.getDynamicObject()->setProperty("path",dragFile.getFullPathName());
        result.getDynamicObject()->setProperty("sha256",fingerprint);completion(result);return;
    }
    if (name=="drag")
    {
        if (payload.getProperty("revision",{}).toString()!=dragRevision)
        { completion(reply(false,"MIDI changed. Wait for preparation, then drag again."));return; }
        if (dragInProgress) { completion(reply(false,"A MIDI file drag is already in progress."));return; }
        const bool started=dragFile.existsAsFile() && juce::DragAndDropContainer::performExternalDragDropOfFiles(
            juce::StringArray {dragFile.getFullPathName()},false,this,[safe] {if (safe) safe->dragInProgress=false;});
        dragInProgress=started;
        completion(reply(started,started ? "" : "Press and drag this button into the DAW."));return;
    }
    completion(reply(false,"Unknown native command"));
}

bool LocalMidiEditor::decodeMidi(const juce::var& payload,juce::MemoryBlock& bytes,juce::String& error)
{
    const auto encoded=payload.getProperty("bytes",{}).toString();
    juce::MemoryOutputStream decoded;
    const bool valid=encoded.length()<=28*1024*1024 && juce::Base64::convertFromBase64(decoded,encoded);
    bytes=decoded.getMemoryBlock();
    if (!valid
        || bytes.getSize()<14 || std::memcmp(bytes.getData(),"MThd",4)!=0)
    { error="Invalid MIDI export";return false; }
    return true;
}
void LocalMidiEditor::saveMidi(const juce::var& payload,juce::WebBrowserComponent::NativeFunctionCompletion completion)
{
    auto bytes=std::make_shared<juce::MemoryBlock>();juce::String error;
    if (!decodeMidi(payload,*bytes,error)) { completion(reply(false,error));return; }
    const auto name=juce::File::createLegalFileName(payload.getProperty("name","transcription.mid").toString());
    fileChooser=std::make_unique<juce::FileChooser>("Save transcription MIDI",
        juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile(name),"*.mid;*.midi");
    const auto safe=juce::Component::SafePointer<LocalMidiEditor>(this);
    fileChooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles
                            |juce::FileBrowserComponent::warnAboutOverwriting,
        [safe,bytes,completion](const juce::FileChooser& chooser)
        {
            if (!safe) return;
            auto file=chooser.getResult();
            if (file==juce::File()) { auto result=reply(true);result.getDynamicObject()->setProperty("cancelled",true);completion(result);return; }
            file=file.withFileExtension("mid");
            completion(reply(file.replaceWithData(bytes->getData(),bytes->getSize()),"Could not save the MIDI file"));
        });
}
