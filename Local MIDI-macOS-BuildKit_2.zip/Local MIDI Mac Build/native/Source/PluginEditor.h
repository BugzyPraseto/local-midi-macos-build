#pragma once
#include "PluginProcessor.h"

class LocalMidiEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit LocalMidiEditor(LocalMidiProcessor&);
    ~LocalMidiEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    class Browser final : public juce::WebBrowserComponent
    {
    public:
        explicit Browser(const Options& options) : WebBrowserComponent(options) {}
        bool pageAboutToLoad(const juce::String& url) override;
    };
    void timerCallback() override;
    void command(const juce::Array<juce::var>&,juce::WebBrowserComponent::NativeFunctionCompletion);
    void saveMidi(const juce::var&,juce::WebBrowserComponent::NativeFunctionCompletion);
    bool decodeMidi(const juce::var&,juce::MemoryBlock&,juce::String&);
    LocalMidiProcessor& processor;
    juce::Component::SafePointer<juce::DocumentWindow> standaloneWindow;
    juce::TextButton retry { "Retry local engine" };
    juce::String startupMessage;
    juce::File dragFile;
    juce::String dragRevision;
    bool dragInProgress=false;
    // Native callback dependencies precede the browser. Choosers are destroyed
    // before the browser, so no dialog callback targets a destroyed WebView.
    std::unique_ptr<Browser> browser;
    std::unique_ptr<juce::FileChooser> fileChooser;
    bool pageLoaded=false;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LocalMidiEditor)
};

