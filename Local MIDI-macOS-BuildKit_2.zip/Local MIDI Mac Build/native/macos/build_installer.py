#!/usr/bin/env python3
"""Build self-contained Apple Silicon and Intel macOS Installer packages.

The bootstrap uses only the Python standard library (3.9+). All product Python
dependencies are installed into a pinned relocatable CPython distribution, never
into the builder's Python or a virtualenv. This file is importable for portable
packaging tests; Mac tools are invoked only by main/build.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import plistlib
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tarfile
import urllib.request
import uuid
import xml.etree.ElementTree as ET
import zipfile

REPOSITORY = Path(__file__).resolve().parents[2]
PACKAGE_ID = "local.localmidi.workbench.macos"
MINIMUM_MACOS = (12, 0)
ARCHITECTURES = ("arm64", "x86_64")
NATIVE_ARCHITECTURES = ("arm64", "x86_64")
PROFILES = {
    "arm64": {"manifest": "python-runtime.json", "torch": "2.5.1", "torchaudio": "2.5.1", "constraints": None},
    "x86_64": {"manifest": "python-runtime-x86_64.json", "torch": "2.2.2", "torchaudio": "2.2.2",
               "constraints": "requirements-macos-x86_64.txt"},
}
NCLS_SOURCE = {
    "archive": "ncls-0.0.70.tar.gz",
    "url": "https://files.pythonhosted.org/packages/5f/dd/0c6a5a36ec132665f85e5e33f0480b58cf5aa8af8fbe1d5971410d789558/ncls-0.0.70.tar.gz",
    "sha256": "7d16634a8f57fa79659e9ae7e5cc6edd1e02d5acb0eb57128dbed03e9f4fdd9c",
}
INSTALL_APP = PurePosixPath("/Applications/Local MIDI.app")
INSTALL_VST3 = PurePosixPath("/Library/Audio/Plug-Ins/VST3/Local MIDI.vst3")
INSTALL_ENGINE = PurePosixPath("/Library/Application Support/Local MIDI/Engine")
MACHO_MAGIC = {bytes.fromhex(value) for value in
               ("feedface", "feedfacf", "cefaedfe", "cffaedfe", "cafebabe", "bebafeca", "cafebabf", "bfbafeca")}


def minimum_macos():
    return ".".join(map(str, MINIMUM_MACOS))


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def inside(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def payload_paths(payload):
    root = Path(payload)
    return {"app": root.joinpath(*INSTALL_APP.parts[1:]),
            "vst3": root.joinpath(*INSTALL_VST3.parts[1:]),
            "engine": root.joinpath(*INSTALL_ENGINE.parts[1:])}


def architecture_profile(architecture):
    if architecture not in PROFILES:
        raise ValueError("Unsupported Mac architecture: " + str(architecture))
    return {"architecture": architecture, **PROFILES[architecture]}


def physical_architecture(machine, translated=False):
    if translated and machine != "x86_64":
        raise ValueError("Inconsistent translated Mac processor information")
    if machine == "arm64" or (machine == "x86_64" and translated):
        return "arm64"
    if machine == "x86_64":
        return "x86_64"
    raise ValueError("Unsupported Mac processor: " + str(machine))


def select_architecture(requested, machine, translated=False):
    host = physical_architecture(machine, translated)
    architecture = host if requested == "auto" else requested
    architecture_profile(architecture)
    if architecture == "arm64" and host != "arm64":
        raise ValueError("An Intel Mac cannot execute the Apple Silicon engine for its required self-test. Build arm64 on an Apple Silicon Mac.")
    return architecture


def installation_plan(version, architecture="arm64"):
    profile = architecture_profile(architecture)
    return {"version": version, "platform": "macOS", "architecture": architecture,
            "native_wrapper_architectures": list(NATIVE_ARCHITECTURES),
            "torch": profile["torch"], "torchaudio": profile["torchaudio"],
            "minimum_macos": minimum_macos(),
            "app": str(INSTALL_APP), "vst3": str(INSTALL_VST3), "engine": str(INSTALL_ENGINE),
            "user_data": "~/Library/Application Support/Local MIDI",
            "user_cache": "~/Library/Caches/Local MIDI", "user_logs": "~/Library/Logs/Local MIDI",
            "inference": "CPU", "installer_runs_engine_as_root": False}


def validate_host(system, machine, mac_version, translated=False, architecture="auto"):
    if system != "Darwin":
        raise ValueError("A Mac is required to compile/sign/package macOS binaries; this is not a Windows converter.")
    selected = select_architecture(architecture, machine, translated)
    try:
        version = tuple(int(part) for part in mac_version.split(".")[:2])
    except (ValueError, AttributeError):
        raise ValueError("Cannot determine the macOS version") from None
    if version < MINIMUM_MACOS:
        raise ValueError("The bundled dependencies require macOS " + minimum_macos() + " or later.")
    return selected


def validate_signing(app_identity, installer_identity, notary_profile):
    if bool(app_identity) != bool(installer_identity):
        raise ValueError("Supply both --app-identity and --installer-identity, or neither for an unsigned development package.")
    if app_identity and not app_identity.startswith("Developer ID Application:"):
        raise ValueError("--app-identity must name a Developer ID Application certificate in your Mac keychain.")
    if installer_identity and not installer_identity.startswith("Developer ID Installer:"):
        raise ValueError("--installer-identity must name a Developer ID Installer certificate in your Mac keychain.")
    if notary_profile and not (app_identity and installer_identity):
        raise ValueError("Notarization requires both Developer ID signing identities and an existing notarytool keychain profile.")


def validate_tar_members(members):
    """Validate the entire pinned install_only archive before extracting it.

    Symlinks are permitted only within its python/ tree. Resolving their virtual
    targets here also catches link chains that would escape through later files.
    """
    links = {}
    names = set()
    for entry in members:
        name = PurePosixPath(entry.name)
        if (name.is_absolute() or not name.parts or name.parts[0] != "python"
                or any(part in ("..", "") for part in name.parts) or "\\" in entry.name):
            raise ValueError("Unsafe Python archive path: " + entry.name)
        if entry.name in names:
            raise ValueError("Duplicate Python archive path: " + entry.name)
        names.add(entry.name)
        if not (entry.isfile() or entry.isdir() or entry.issym() or entry.islnk()):
            raise ValueError("Unsupported Python archive entry: " + entry.name)
        if entry.issym() or entry.islnk():
            target = PurePosixPath(entry.linkname)
            if target.is_absolute() or "\\" in entry.linkname:
                raise ValueError("Unsafe Python archive link: " + entry.name)
            base = name.parent if entry.issym() else PurePosixPath()
            links[name] = base / target

    def resolve(parts, seen):
        current = []
        for part in parts:
            if part in ("", "."):
                continue
            if part == "..":
                if len(current) <= 1:
                    raise ValueError("Python archive link escapes its root")
                current.pop()
                continue
            current.append(part)
            path = PurePosixPath(*current)
            if path in links:
                if path in seen:
                    raise ValueError("Cyclic Python archive link")
                current = resolve(links[path].parts, seen | {path})
        if not current or current[0] != "python":
            raise ValueError("Python archive link escapes its root")
        return current

    for entry in members:
        resolve(PurePosixPath(entry.name).parts, set())
    return members


def extract_python(archive, runtime):
    runtime = Path(runtime)
    if runtime.exists():
        raise FileExistsError("Refusing to merge a Python runtime into an existing directory: " + str(runtime))
    unpack = runtime.parent / (".python-unpack-" + uuid.uuid4().hex)
    if not inside(unpack, runtime.parent) or not inside(runtime, runtime.parent):
        raise ValueError("Unsafe runtime extraction target")
    unpack.mkdir()
    with tarfile.open(archive, "r:gz") as source:
        entries = validate_tar_members(source.getmembers())
        # The hash and all paths/link chains are verified before extraction.
        # Older Xcode Python 3.9 does not have tarfile's filter= API.
        if hasattr(tarfile, "data_filter"):
            source.extractall(unpack, members=entries, filter="data")
        else:
            source.extractall(unpack, members=entries)
    extracted = unpack / "python"
    if not (extracted / "bin/python3").is_file():
        raise ValueError("Pinned Python archive did not contain bin/python3")
    extracted.rename(runtime)
    unpack.rmdir()


def download_runtime(manifest, downloads):
    downloads = Path(downloads)
    downloads.mkdir(parents=True, exist_ok=True)
    archive = downloads / manifest["archive"]
    if archive.name != manifest["archive"]:
        raise ValueError("Runtime archive name must be a filename")
    if not archive.exists():
        temporary = archive.with_name(archive.name + "." + uuid.uuid4().hex + ".part")
        request = urllib.request.Request(manifest["url"], headers={"User-Agent": "LocalMIDI-mac-build/1.0"})
        print("Downloading pinned CPython " + manifest["python"], flush=True)
        with urllib.request.urlopen(request, timeout=180) as response, temporary.open("wb") as target:
            shutil.copyfileobj(response, target, length=1024 * 1024)
        if digest(temporary) != manifest["sha256"]:
            raise ValueError("Python runtime checksum mismatch; the untrusted download was not installed: " + str(temporary))
        temporary.replace(archive)
    if digest(archive) != manifest["sha256"]:
        raise ValueError("Cached Python runtime checksum mismatch: " + str(archive))
    return archive


def run(arguments, *, cwd=None, env=None, capture=False):
    print("+ " + shlex.join(map(str, arguments)), flush=True)
    return subprocess.run(list(map(str, arguments)), cwd=cwd, env=env, check=True,
                          text=True, stdout=subprocess.PIPE if capture else None)


def copy_tree(source, destination):
    # ditto retains Mac bundle links, resource forks and executable permissions.
    run(["/usr/bin/ditto", source, destination])


def source_version(repository):
    text = (Path(repository) / "native/CMakeLists.txt").read_text(encoding="utf-8")
    match = re.search(r"project\(LocalMidi\s+VERSION\s+(\d+\.\d+\.\d+)", text)
    if not match:
        raise ValueError("Cannot read the native project version")
    return match.group(1)


def verify_samples(engine):
    folder = Path(engine) / "static/samples"
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    expected = {"piano.json", "guitar.json"}
    records = {record["file"]: record for record in manifest}
    if not expected.issubset(records):
        raise ValueError("The preview sample manifest is incomplete")
    for name in expected:
        if digest(folder / name) != records[name]["sha256"]:
            raise ValueError("Preview sample hash mismatch: " + name)


def effective_macos_requirements(common, overrides, allow_new=False):
    """Apply explicit Mac pins without changing the Windows requirements file."""
    pins = {}
    for line in overrides.splitlines():
        value = line.partition("#")[0].strip()
        if not value:
            continue
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^\s]+)", value)
        if not match:
            raise ValueError("Mac requirement overrides must be exact package==version pins")
        name = re.sub(r"[-_.]+", "-", match.group(1)).lower()
        if name in pins:
            raise ValueError("Duplicate Mac requirement override: " + name)
        pins[name] = value
    seen = set()
    output = ["# Effective Mac requirements; requirements-common.txt retains the shared source pins."]
    for line in common.splitlines():
        match = re.match(r"\s*([A-Za-z0-9_.-]+)\s*(?:==|[<>=!~])", line)
        name = re.sub(r"[-_.]+", "-", match.group(1)).lower() if match else None
        if name in pins:
            if name in seen:
                raise ValueError("Duplicate shared requirement for Mac override: " + name)
            output.append(pins[name])
            seen.add(name)
        else:
            output.append(line)
    if allow_new:
        output.extend(pins[name] for name in sorted(set(pins) - seen))
    elif seen != set(pins):
        raise ValueError("Mac override has no shared requirement: " + ", ".join(sorted(set(pins) - seen)))
    return "\n".join(output) + "\n"


def copy_engine_sources(repository, engine, architecture="arm64"):
    repository, engine = Path(repository), Path(engine)
    engine.mkdir(parents=True)
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store")
    shutil.copytree(repository / "localmidi", engine / "localmidi", ignore=ignore)
    shutil.copytree(repository / "static", engine / "static", ignore=ignore)
    for name in ("engine.py", "StartMac.sh", "models.json", "requirements.txt", "THIRD_PARTY.md"):
        shutil.copy2(repository / name, engine / name)
    common = (repository / "requirements.txt").read_text(encoding="utf-8")
    overrides = (repository / "native/macos/requirements-macos.txt").read_text(encoding="utf-8")
    profile = architecture_profile(architecture)
    effective = effective_macos_requirements(common, overrides)
    if profile["constraints"]:
        constraints = (repository / "native/macos" / profile["constraints"]).read_text(encoding="utf-8")
        (engine / profile["constraints"]).write_text(constraints, encoding="utf-8")
        effective = effective_macos_requirements(effective, constraints, allow_new=True)
    (engine / "requirements-common.txt").write_text(common, encoding="utf-8")
    (engine / "requirements-macos.txt").write_text(overrides, encoding="utf-8")
    (engine / "requirements.txt").write_text(effective, encoding="utf-8")
    (engine / "architecture-profile.json").write_text(json.dumps({**profile, "minimum_macos": minimum_macos(),
        "native_wrapper_architectures": list(NATIVE_ARCHITECTURES)}, indent=2) + "\n", encoding="utf-8")
    (engine / "scripts").mkdir()
    for name in ("acquire_models.py", "fetch_preview_samples.py"):
        shutil.copy2(repository / "scripts" / name, engine / "scripts" / name)
    (engine / "StartMac.sh").chmod(0o755)


def build_environment(stage, engine, architecture="arm64"):
    architecture_profile(architecture)
    environment = os.environ.copy()
    # DAWs/developer shells may inject another Python distribution or libraries.
    for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONUSERBASE", "VIRTUAL_ENV", "CONDA_PREFIX",
                "DYLD_LIBRARY_PATH", "DYLD_FRAMEWORK_PATH", "DYLD_FALLBACK_LIBRARY_PATH"):
        environment.pop(key, None)
    scratch = Path(stage) / "build-user-state"
    environment.update(LOCALMIDI_DATA=str(scratch / "data"),
                       LOCALMIDI_MODELS=str(Path(engine) / ".models"),
                       LOCALMIDI_CACHE=str(scratch / "cache"),
                       LOCALMIDI_LOGS=str(scratch / "logs"),
                       XDG_CACHE_HOME=str(scratch / "cache"),
                       MPLCONFIGDIR=str(scratch / "cache/matplotlib"),
                       NUMBA_CACHE_DIR=str(scratch / "cache/numba"),
                       TORCH_HOME=str(scratch / "cache/torch"),
                       PYTHONDONTWRITEBYTECODE="1", PIP_DISABLE_PIP_VERSION_CHECK="1",
                       MACOSX_DEPLOYMENT_TARGET=minimum_macos(), ARCHFLAGS="-arch " + architecture,
                       CFLAGS="-arch " + architecture + " -mmacosx-version-min=" + minimum_macos(),
                       CXXFLAGS="-arch " + architecture + " -mmacosx-version-min=" + minimum_macos(),
                       LDFLAGS="-arch " + architecture + " -mmacosx-version-min=" + minimum_macos())
    return environment


def compatible_wheel_options(architecture="arm64"):
    architecture_profile(architecture)
    # MACOSX_DEPLOYMENT_TARGET affects source builds, not pip's wheel selection.
    return ["--platform", "macosx_" + "_".join(map(str, MINIMUM_MACOS)) + "_" + architecture,
            "--python-version", "3.12", "--implementation", "cp", "--abi", "cp312",
            "--only-binary=:all:"]


def download_compatible_wheels(python, wheelhouse, requirements, environment, no_deps=False, architecture="arm64"):
    arguments = [python, "-I", "-m", "pip", "--isolated", "download", "--index-url", "https://pypi.org/simple",
                 "--dest", wheelhouse, "--find-links", wheelhouse] + compatible_wheel_options(architecture)
    if no_deps:
        arguments.append("--no-deps")
    run(arguments + list(requirements), env=environment)


def install_offline_wheels(python, wheelhouse, requirements, environment, no_deps=False):
    arguments = [python, "-I", "-m", "pip", "--isolated", "install", "--no-index",
                 "--find-links", wheelhouse, "--only-binary=:all:", "--no-compile"]
    if no_deps:
        arguments.append("--no-deps")
    run(arguments + list(requirements), env=environment)


def verify_pure_python_wheel(path):
    path = Path(path)
    if not path.name.endswith("-none-any.whl"):
        raise ValueError("Source-only dependency did not produce a portable pure-Python wheel: " + path.name)
    with zipfile.ZipFile(path) as archive:
        metadata = [name for name in archive.namelist() if name.endswith(".dist-info/WHEEL")]
        if len(metadata) != 1:
            raise ValueError("Source wheel has invalid WHEEL metadata: " + path.name)
        text = archive.read(metadata[0]).decode("utf-8")
        tags = re.findall(r"^Tag:\s*(\S+)\s*$", text, re.MULTILINE)
        if not re.search(r"^Root-Is-Purelib:\s*true\s*$", text, re.MULTILINE | re.IGNORECASE) or not tags or any(not tag.endswith("-none-any") for tag in tags):
            raise ValueError("Source wheel is not pure Python: " + path.name)
        if any(Path(name).suffix.lower() in (".so", ".dylib", ".pyd", ".dll", ".exe") for name in archive.namelist()):
            raise ValueError("Source wheel contains a native binary: " + path.name)


def build_pure_source_wheel(python, wheelhouse, environment):
    # sox 1.5.0 is a Python wrapper distributed only as source. Build that one
    # wrapper locally; compiled runtime dependencies must come from target wheels.
    run([python, "-I", "-m", "pip", "--isolated", "wheel", "--index-url", "https://pypi.org/simple",
         "--no-deps", "--no-build-isolation", "--wheel-dir", wheelhouse, "sox==1.5.0"], env=environment)
    wheels = list(Path(wheelhouse).glob("sox-1.5.0-*.whl"))
    if len(wheels) != 1:
        raise ValueError("Expected exactly one built sox 1.5.0 wheel")
    verify_pure_python_wheel(wheels[0])


def verify_target_interpreter(python, environment, architecture):
    try:
        value = run([python, "-I", "-c", "import json,platform,sys;print(json.dumps({'architecture':platform.machine(),'platform':sys.platform}))"],
                    env=environment, capture=True)
    except (OSError, subprocess.CalledProcessError) as error:
        raise ValueError("The " + architecture + " bundled interpreter could not run. Intel builds on Apple Silicon need Rosetta already installed, or build on an Intel Mac. No cross-build was marked successful.") from error
    report = json.loads(value.stdout.strip().splitlines()[-1])
    if report.get("architecture") != architecture or report.get("platform") != "darwin":
        raise ValueError("Bundled interpreter does not match the selected " + architecture + " Mac profile")


def verify_ncls_wheel(path, architecture):
    path = Path(path)
    with zipfile.ZipFile(path) as archive:
        records = [name for name in archive.namelist() if name.endswith(".dist-info/WHEEL")]
        if len(records) != 1:
            raise ValueError("NCLS source wheel has invalid metadata")
        text = archive.read(records[0]).decode("utf-8")
        tags = re.findall(r"^Tag:\s*(\S+)\s*$", text, re.MULTILINE)
        valid = re.compile(r"cp312-cp312-macosx_(\d+)_(\d+)_(" + re.escape(architecture) + r"|universal2)$")
        if not tags or any(not valid.fullmatch(tag) or tuple(map(int, valid.fullmatch(tag).groups()[:2])) > MINIMUM_MACOS for tag in tags):
            raise ValueError("NCLS wheel does not target the selected Mac architecture/minimum OS")
        if re.search(r"^Root-Is-Purelib:\s*true\s*$", text, re.MULTILINE | re.IGNORECASE):
            raise ValueError("NCLS native source unexpectedly produced a pure-Python wheel")
        binaries = [name for name in archive.namelist() if name.endswith(".so")]
        if not binaries or any(archive.read(name)[:4] not in MACHO_MAGIC for name in binaries):
            raise ValueError("NCLS wheel is missing its compiled Mac extension")


def build_intel_ncls_wheel(python, wheelhouse, downloads, environment):
    # The pinned NCLS release has no Intel cp312 Mac wheel. Compile only this
    # exact verified source with the target interpreter/NumPy/Cython toolchain.
    downloads = Path(downloads)
    downloads.mkdir(parents=True, exist_ok=True)
    source = downloads / NCLS_SOURCE["archive"]
    if not source.exists():
        temporary = source.with_suffix(".part")
        request = urllib.request.Request(NCLS_SOURCE["url"], headers={"User-Agent": "LocalMIDI-mac-build/1.0"})
        with urllib.request.urlopen(request, timeout=180) as response, temporary.open("wb") as output:
            shutil.copyfileobj(response, output, length=1024 * 1024)
        if digest(temporary) != NCLS_SOURCE["sha256"]:
            raise ValueError("NCLS source checksum mismatch")
        temporary.replace(source)
    if digest(source) != NCLS_SOURCE["sha256"]:
        raise ValueError("Cached NCLS source checksum mismatch")
    run([python, "-I", "-m", "pip", "--isolated", "wheel", "--no-index", "--no-deps",
         "--no-build-isolation", "--wheel-dir", wheelhouse, source], env=environment)
    wheels = list(Path(wheelhouse).glob("ncls-0.0.70-*.whl"))
    if len(wheels) != 1:
        raise ValueError("Expected exactly one compiled Intel NCLS wheel")
    verify_ncls_wheel(wheels[0], "x86_64")


def prepare_dependencies(repository, stage, engine, manifest, downloads, architecture="arm64"):
    profile = architecture_profile(architecture)
    if manifest.get("architecture") != architecture:
        raise ValueError("Python runtime manifest does not match the selected engine architecture")
    archive = download_runtime(manifest, downloads)
    runtime = Path(engine) / "runtime"
    extract_python(archive, runtime)
    python = runtime / "bin/python3"
    environment = build_environment(stage, engine, architecture)
    verify_target_interpreter(python, environment, architecture)
    wheelhouse = Path(stage) / "wheelhouse"
    wheelhouse.mkdir()
    # basic_pitch uses pkg_resources, removed by newer setuptools releases.
    bootstrap = ["setuptools==75.6.0", "wheel==0.45.1"]
    if architecture == "x86_64":
        bootstrap += ["numpy==1.26.4", "Cython==3.0.12", "setuptools_scm==8.1.0"]
    download_compatible_wheels(python, wheelhouse, bootstrap, environment, architecture=architecture)
    install_offline_wheels(python, wheelhouse, bootstrap, environment)
    build_pure_source_wheel(python, wheelhouse, environment)
    if architecture == "x86_64":
        build_intel_ncls_wheel(python, wheelhouse, downloads, environment)
    requirements = ["torch==" + profile["torch"], "torchaudio==" + profile["torchaudio"], "-r", Path(engine) / "requirements.txt"]
    download_compatible_wheels(python, wheelhouse, requirements, environment, architecture=architecture)
    install_offline_wheels(python, wheelhouse, requirements, environment)
    models = ["transkun==2.0.1", "basic-pitch==0.4.0"]
    download_compatible_wheels(python, wheelhouse, models, environment, no_deps=True, architecture=architecture)
    install_offline_wheels(python, wheelhouse, models, environment, no_deps=True)
    certificate = run([python, "-I", "-c", "from pip._vendor import certifi;print(certifi.where())"], env=environment, capture=True).stdout.strip()
    environment["SSL_CERT_FILE"] = certificate
    run([python, "-I", Path(repository) / "scripts/acquire_native_dependencies.py", "--platform", "macos"], env=environment)
    # Dependency acquisition copies the pinned JUCE browser JavaScript into the source tree.
    # Copy those files again so the engine receives exactly that verified interop layer.
    (Path(engine) / "static/juce").mkdir(exist_ok=True)
    for name in ("index.js", "check_native_interop.js"):
        shutil.copy2(Path(repository) / "static/juce" / name, Path(engine) / "static/juce" / name)
    run([python, "-I", Path(engine) / "scripts/acquire_models.py"], env=environment)
    run([python, "-I", Path(engine) / "scripts/acquire_models.py", "--verify-only"], env=environment)
    samples = Path(engine) / "static/samples"
    if not all((samples / name).is_file() for name in ("piano.json", "guitar.json", "manifest.json")):
        run([python, "-I", Path(engine) / "scripts/fetch_preview_samples.py"], env=environment)
    verify_samples(engine)
    return python, environment


def isolate_runtime_payload(engine, architecture):
    """Give every installer a fresh interpreter tree, with one stable relative link.

    pkg installation merges ordinary directories. Reusing runtime/site-packages
    would leave old architecture/version files behind when changing profiles.
    Models and user data remain outside these versioned runtime trees.
    """
    profile = architecture_profile(architecture)
    engine = Path(engine)
    runtime = engine / "runtime"
    if runtime.is_symlink() or not runtime.is_dir() or not inside(runtime / "bin/python3", runtime):
        raise ValueError("Expected a fresh, unlinked staged Python runtime")
    relative = Path("runtimes") / (architecture + "-torch" + profile["torch"] + "-" + uuid.uuid4().hex[:12])
    destination = engine / relative
    if not inside(destination, engine) or not inside(runtime, engine):
        raise ValueError("Runtime payload target escaped the staged engine")
    destination.parent.mkdir(exist_ok=True)
    runtime.rename(destination)
    # Keep the old runtime/ directory shape upgradeable. Only its entry-point
    # symlink changes; Python's actual prefix lives in the fresh versioned tree.
    runtime.mkdir()
    (runtime / "bin").mkdir()
    entry = runtime / "bin/python3"
    entry_target = Path("../..") / relative / "bin/python3"
    try:
        entry.symlink_to(entry_target)
    except OSError:
        (runtime / "bin").rmdir()
        runtime.rmdir()
        destination.rename(runtime)
        raise
    profile_path = engine / "architecture-profile.json"
    metadata = json.loads(profile_path.read_text(encoding="utf-8")) if profile_path.exists() else profile
    metadata["runtime_directory"] = relative.as_posix()
    profile_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return relative.as_posix()


def native_build(repository, directory, jobs):
    run(["cmake", "-S", Path(repository) / "native", "-B", directory,
         "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_OSX_ARCHITECTURES=" + ";".join(NATIVE_ARCHITECTURES),
         "-DCMAKE_OSX_DEPLOYMENT_TARGET=" + minimum_macos(), "-DLOCALMIDI_BUILD_QA=OFF"])
    run(["cmake", "--build", directory, "--config", "Release", "--target",
         "LocalMidi_Standalone", "LocalMidi_VST3", "LocalMidiTests", "--parallel", str(jobs)])
    run(["ctest", "--test-dir", directory, "-C", "Release", "--output-on-failure"])
    artifacts = Path(directory) / "LocalMidi_artefacts/Release"
    return artifacts / "Standalone/Local MIDI.app", artifacts / "VST3/Local MIDI.vst3"


def bundle_executable(bundle):
    bundle = Path(bundle)
    with (bundle / "Contents/Info.plist").open("rb") as stream:
        info = plistlib.load(stream)
    name = info.get("CFBundleExecutable", "")
    if not name or Path(name).name != name:
        raise ValueError("Invalid bundle executable: " + str(bundle))
    return bundle / "Contents/MacOS" / name


def verify_bundle(bundle):
    executable = bundle_executable(bundle)
    with executable.open("rb") as stream:
        if stream.read(4) not in MACHO_MAGIC:
            raise ValueError("The artifact is not a Mac Mach-O binary: " + str(executable))
    architectures = run(["/usr/bin/lipo", "-archs", executable], capture=True).stdout.split()
    if set(architectures) != set(NATIVE_ARCHITECTURES):
        raise ValueError("Expected a universal2 Mac bundle (arm64 and x86_64), got " + " ".join(architectures))
    for architecture in NATIVE_ARCHITECTURES:
        load_commands = run(["/usr/bin/otool", "-arch", architecture, "-l", executable], capture=True).stdout
        validate_macos_load_commands(load_commands, executable)


def validate_macos_load_commands(text, path):
    modern = re.findall(r"cmd LC_BUILD_VERSION\s+cmdsize\s+\d+\s+platform\s+(\w+)\s+minos\s+([\d.]+)", text)
    legacy = re.findall(r"cmd LC_VERSION_MIN_MACOSX\s+cmdsize\s+\d+\s+version\s+([\d.]+)", text)
    if any(target not in ("MACOS", "1") for target, _ in modern) or not (modern or legacy):
        raise ValueError("The Mach-O artifact does not target macOS: " + str(path))
    for version in [value for _, value in modern] + legacy:
        numbers = tuple((list(map(int, version.split("."))) + [0, 0, 0])[:3])
        if numbers > tuple((list(MINIMUM_MACOS) + [0, 0, 0])[:3]):
            raise ValueError("A dependency requires macOS " + version + ", newer than the package's " + minimum_macos() + " minimum: " + str(path))


def verify_runtime_targets(engine, architecture="arm64"):
    architecture_profile(architecture)
    # A newer builder can select a wheel whose minimum OS exceeds our installer
    # target. Inspect the actual payload rather than advertising an untested OS.
    for path in Path(engine).rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        with path.open("rb") as stream:
            if stream.read(4) not in MACHO_MAGIC:
                continue
        available = run(["/usr/bin/lipo", "-archs", path], capture=True).stdout.split()
        if architecture not in available:
            raise ValueError("Runtime dependency has no " + architecture + " slice: " + str(path))
        # Universal dependency wheels can contain an unused newer-OS slice.
        # Audit exactly the slice this package's interpreter will load.
        commands = run(["/usr/bin/otool", "-arch", architecture, "-l", path], capture=True).stdout
        validate_macos_load_commands(commands, path)


def relocation_self_test(stage, engine, architecture="arm64"):
    profile = architecture_profile(architecture)
    stage, engine = Path(stage), Path(engine)
    relocated = stage / "relocation-check/Engine"
    if not inside(engine, stage) or not inside(relocated, stage):
        raise ValueError("Relocation test escaped its staging directory")
    relocated.parent.mkdir()
    engine.rename(relocated)
    try:
        environment = build_environment(stage, relocated, architecture)
        result = run([(relocated / "runtime/bin/python3").resolve(), "-I", relocated / "engine.py", "--self-test"],
                     cwd=relocated, env=environment, capture=True)
        report = json.loads(result.stdout.strip().splitlines()[-1])
        if not report.get("ok") or report.get("architecture") != architecture or report.get("platform") != "darwin":
            raise ValueError("Relocated engine did not report a valid " + architecture + " Mac self-test")
        if report.get("versions", {}).get("torch", "").split("+", 1)[0] != profile["torch"]:
            raise ValueError("Relocated engine Torch version does not match the selected Mac profile")
        (stage / "engine-self-test.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(result.stdout, flush=True)
    finally:
        relocated.rename(engine)


def normalize_payload_permissions(payload):
    for path in Path(payload).rglob("*"):
        if path.is_symlink():
            continue
        executable = bool(path.stat().st_mode & 0o111)
        path.chmod(0o755 if path.is_dir() or executable else 0o644)


def sign_payload(paths, macos, identity):
    if not identity:
        return
    seen = set()
    for path in sorted(paths["engine"].rglob("*"), key=lambda value: len(value.parts), reverse=True):
        if not path.is_file() or path.is_symlink() or path.resolve() in seen:
            continue
        with path.open("rb") as stream:
            if stream.read(4) not in MACHO_MAGIC:
                continue
        seen.add(path.resolve())
        arguments = ["/usr/bin/codesign", "--force", "--sign", identity, "--timestamp", "--options", "runtime"]
        if path.parent.resolve() == (paths["engine"] / "runtime/bin/python3").resolve().parent:
            arguments += ["--entitlements", Path(macos) / "engine.entitlements.plist"]
        run(arguments + [path])
    for key in ("app", "vst3"):
        arguments = ["/usr/bin/codesign", "--force", "--sign", identity, "--timestamp", "--options", "runtime"]
        if key == "app":
            arguments += ["--entitlements", Path(macos) / "app.entitlements.plist"]
        run(arguments + [paths[key]])
        run(["/usr/bin/codesign", "--verify", "--strict", "--verbose=2", paths[key]])
    # Verify the entry point as well as the native bundles. Nested libraries were
    # signed explicitly from leaves upward; --deep is never used for signing.
    run(["/usr/bin/codesign", "--verify", "--strict", "--verbose=2", paths["engine"] / "runtime/bin/python3"])


def fix_component_plist(records):
    expected = {str(INSTALL_APP).lstrip("/"), str(INSTALL_VST3).lstrip("/")}
    found = set()
    for record in records:
        relative = record.get("RootRelativeBundlePath")
        if relative in expected:
            record["BundleIsRelocatable"] = False
            record["BundleIsVersionChecked"] = False
            record["BundleHasStrictIdentifier"] = True
            record["BundleOverwriteAction"] = "upgrade"
            found.add(relative)
    if found != expected:
        raise ValueError("pkgbuild did not identify both fixed-location bundles: " + ", ".join(sorted(expected - found)))
    return records


def distribution_xml(version, component_name, architecture="arm64"):
    architecture_profile(architecture)
    root = ET.Element("installer-gui-script", minSpecVersion="2")
    ET.SubElement(root, "title").text = "Local MIDI " + version
    ET.SubElement(root, "organization").text = "local.localmidi.workbench"
    ET.SubElement(root, "options", customize="never", require_scripts="false",
                  rootVolumeOnly="true", hostArchitectures=architecture)
    # Distribution XML uses hyphenated names for these attributes.
    options = root.find("options")
    options.set("require-scripts", options.attrib.pop("require_scripts"))
    ET.SubElement(root, "domains", enable_anywhere="false", enable_currentUserHome="false", enable_localSystem="true")
    ET.SubElement(root, "welcome", file="Welcome.html", **{"mime-type": "text/html"})
    ET.SubElement(root, "readme", file="Readme.html", **{"mime-type": "text/html"})
    volume = ET.SubElement(root, "volume-check")
    versions = ET.SubElement(volume, "allowed-os-versions")
    ET.SubElement(versions, "os-version", min=minimum_macos())
    choices = ET.SubElement(root, "choices-outline")
    ET.SubElement(choices, "line", choice="localmidi")
    choice = ET.SubElement(root, "choice", id="localmidi", visible="false", title="Local MIDI")
    ET.SubElement(choice, "pkg-ref", id=PACKAGE_ID)
    reference = ET.SubElement(root, "pkg-ref", id=PACKAGE_ID, version=version, auth="Root", onConclusion="none")
    reference.text = component_name
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode") + "\n"


def package_payload(stage, payload, version, macos, installer_identity, notary_profile, architecture="arm64"):
    architecture_profile(architecture)
    stage, payload = Path(stage), Path(payload)
    component_plist = stage / "components.plist"
    run(["/usr/bin/pkgbuild", "--analyze", "--root", payload, component_plist])
    with component_plist.open("rb") as stream:
        records = fix_component_plist(plistlib.load(stream))
    with component_plist.open("wb") as stream:
        plistlib.dump(records, stream)
    packages = stage / "packages"
    packages.mkdir()
    component = packages / "LocalMIDI-component.pkg"
    run(["/usr/bin/pkgbuild", "--root", payload, "--component-plist", component_plist,
         "--identifier", PACKAGE_ID, "--version", version, "--install-location", "/",
         "--ownership", "recommended", component])
    distribution = stage / "Distribution.xml"
    distribution.write_text(distribution_xml(version, component.name, architecture), encoding="utf-8")
    suffix = "" if installer_identity else "-unsigned"
    result = stage / ("Local MIDI-" + version + "-macOS-" + architecture + suffix + ".pkg")
    arguments = ["/usr/bin/productbuild", "--distribution", distribution,
                 "--resources", Path(macos) / "resources", "--package-path", packages]
    if installer_identity:
        arguments += ["--sign", installer_identity, "--timestamp"]
    run(arguments + [result])
    if installer_identity:
        run(["/usr/sbin/pkgutil", "--check-signature", result])
    if notary_profile:
        run(["/usr/bin/xcrun", "notarytool", "submit", result, "--keychain-profile", notary_profile, "--wait"])
        run(["/usr/bin/xcrun", "stapler", "staple", result])
        run(["/usr/bin/xcrun", "stapler", "validate", result])
        run(["/usr/sbin/spctl", "--assess", "--type", "install", "--verbose=2", result])
    return result


def require_tools():
    for name in ("cmake", "ctest", "xcrun", "pkgbuild", "productbuild", "codesign", "ditto", "lipo", "otool"):
        if shutil.which(name) is None:
            raise ValueError("Missing build tool: " + name + ". Install Xcode Command Line Tools and CMake 3.24+.")
    run(["/usr/bin/xcode-select", "-p"])
    version = run(["cmake", "--version"], capture=True).stdout
    match = re.search(r"cmake version (\d+)\.(\d+)", version)
    if not match or tuple(map(int, match.groups())) < (3, 24):
        raise ValueError("CMake 3.24 or later is required")


def build(args):
    translated = subprocess.run(["/usr/sbin/sysctl", "-in", "sysctl.proc_translated"],
                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True).stdout.strip() == "1" if platform.system() == "Darwin" else False
    architecture = validate_host(platform.system(), platform.machine(), platform.mac_ver()[0], translated, args.arch)
    profile = architecture_profile(architecture)
    validate_signing(args.app_identity, args.installer_identity, args.notary_profile)
    if os.geteuid() == 0:
        raise ValueError("Run the build as your normal Mac user, without sudo. Only installing the finished package requires administrator authorization.")
    require_tools()
    repository = REPOSITORY
    macos = repository / "native/macos"
    version = source_version(repository)
    work = args.work_dir.resolve() if args.work_dir else repository / ("build/macos-" + architecture)
    output = args.output_dir.resolve() if args.output_dir else repository / "dist/macOS"
    work.mkdir(parents=True, exist_ok=True)
    output.mkdir(parents=True, exist_ok=True)
    stage = work / ("stage-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8])
    stage.mkdir()
    payload = stage / "payload"
    paths = payload_paths(payload)
    print(json.dumps(installation_plan(version, architecture), indent=2), flush=True)
    print("Preparing a self-contained payload. Build downloads are needed; installation is offline.", flush=True)
    copy_engine_sources(repository, paths["engine"], architecture)
    manifest = json.loads((macos / profile["manifest"]).read_text(encoding="utf-8"))
    prepare_dependencies(repository, stage, paths["engine"], manifest, work / "downloads", architecture)
    app, vst3 = native_build(repository, work / "native", args.jobs)
    verify_bundle(app)
    verify_bundle(vst3)
    copy_tree(app, paths["app"])
    copy_tree(vst3, paths["vst3"])
    licenses = paths["engine"] / "Licenses"
    licenses.mkdir()
    shutil.copy2(repository / ".native-deps/JUCE/LICENSE.md", licenses / "JUCE-LICENSE.md")
    shutil.copy2(repository / "THIRD_PARTY.md", licenses / "THIRD_PARTY.md")
    (licenses / "python-runtime.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    isolate_runtime_payload(paths["engine"], architecture)
    verify_runtime_targets(paths["engine"], architecture)
    relocation_self_test(stage, paths["engine"], architecture)
    normalize_payload_permissions(payload)
    sign_payload(paths, macos, args.app_identity)
    result = package_payload(stage, payload, version, macos, args.installer_identity, args.notary_profile, architecture)
    destination = output / result.name
    temporary = output / (result.name + "." + uuid.uuid4().hex + ".part")
    shutil.copy2(result, temporary)
    temporary.replace(destination)
    report = {**installation_plan(version, architecture), "built_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "signed": bool(args.installer_identity), "notarized": bool(args.notary_profile),
              "package": destination.name, "sha256": digest(destination), "runtime": manifest,
              "native_tests": "passed", "relocated_runtime_self_test": "passed", "stage": str(stage)}
    (output / (destination.name + ".json")).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("\nBuilt: " + str(destination), flush=True)
    if not args.installer_identity:
        print("Unsigned development package. This is not a signed/notarized release.", flush=True)
    elif not args.notary_profile:
        print("Signed package; notarization was not requested.", flush=True)
    print("No installer was run. Native-host loading and capture still need testing on the target Mac.", flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", action="store_true", help="Print install locations without building; works on any platform")
    parser.add_argument("--arch", choices=("auto", *ARCHITECTURES), default="auto",
                        help="Engine architecture; auto selects the Mac's physical processor. Native app/VST3 are universal2.")
    parser.add_argument("--jobs", type=int, default=min(6, os.cpu_count() or 2))
    parser.add_argument("--work-dir", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--app-identity", help="Developer ID Application identity already in the Mac keychain")
    parser.add_argument("--installer-identity", help="Developer ID Installer identity already in the Mac keychain")
    parser.add_argument("--notary-profile", help="Existing notarytool keychain profile; credentials stay in the keychain")
    args = parser.parse_args(argv)
    try:
        validate_signing(args.app_identity, args.installer_identity, args.notary_profile)
        if args.jobs < 1:
            raise ValueError("--jobs must be positive")
        if args.plan:
            version = source_version(REPOSITORY)
            # No guessed Mac architecture when inspecting from Windows/Linux.
            if args.arch == "auto":
                value = {"packages": [installation_plan(version, architecture) for architecture in ARCHITECTURES],
                         "auto_selection": "The build selects the physical Mac processor, including under Rosetta."}
            else:
                value = installation_plan(version, args.arch)
            print(json.dumps(value, indent=2))
            return 0
        build(args)
    except (ValueError, OSError, subprocess.CalledProcessError, tarfile.TarError) as error:
        print("Mac installer build failed: " + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
