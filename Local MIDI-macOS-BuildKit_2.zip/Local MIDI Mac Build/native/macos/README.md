# Local MIDI macOS installer

This directory builds complete `.pkg` variants for **Apple Silicon and Intel Macs, macOS 12 or later**, with CPU inference. Both contain universal2 standalone/VST3 bundles. Each includes a Python engine matched to the selected processor family. The Windows executable and Windows virtualenv are not used in the Mac product.

**Current status:** the Mac port and installer build pipeline are implemented. Portable tests and the Windows native regression build pass. No Mac is available in this workspace, so a Mac `.pkg` has not been compiled, signed, installed or validated here.

## What the installer places

| Component | Installed location |
| --- | --- |
| Standalone application | `/Applications/Local MIDI.app` |
| VST3 bundle | `/Library/Audio/Plug-Ins/VST3/Local MIDI.vst3` |
| Python, interface, audition samples, models and notices | `/Library/Application Support/Local MIDI/Engine` |
| Each user's recordings, jobs, captures and MIDI transfers | `~/Library/Application Support/Local MIDI` |
| Each user's caches | `~/Library/Caches/Local MIDI` |
| Each user's engine log | `~/Library/Logs/Local MIDI/engine.log` |

The package fixes the app and plug-in destinations rather than relocating an existing copy elsewhere. The VST3 path follows [Steinberg's standard global plug-in location](https://steinbergmedia.github.io/vst3_dev_portal/pages/Technical%2BDocumentation/Locations%2BFormat/Plugin%2BLocations.html). Only the first three rows belong to the system package; user data is created when that user opens an editor. The installer does not run the engine as root or install a LaunchDaemon.

## Build the package on a Mac

1. Copy/extract `Local MIDI-macOS-BuildKit.zip` onto an Apple Silicon or Intel Mac running macOS 12 or later, or copy this source project without its Windows build directories.
2. Install Apple's Xcode Command Line Tools with `xcode-select --install`, and install **CMake 3.24 or later**. If using CMake.app, put its tools on PATH: `export PATH="/Applications/CMake.app/Contents/bin:$PATH"`. The build script uses Python 3 from the build machine to bootstrap; Xcode Command Line Tools provide it. No Homebrew is required by the installed app.
3. Double-click `BuildMac.command`, or open Terminal in the extracted project and run:

   ```bash
   bash BuildMac.sh
   ```

The default `--arch auto` selects the Mac's physical processor, including when the bootstrap runs under Rosetta. To select a package explicitly:

```bash
bash BuildMac.sh --arch arm64    # Apple Silicon engine
bash BuildMac.sh --arch x86_64   # Intel engine
```

Build an Intel package on an Intel Mac, or on Apple Silicon with Rosetta already installed. The bundled Intel interpreter must actually execute and pass its self-test; the build does not install Rosetta automatically. An Apple Silicon engine must be built on Apple Silicon because an Intel Mac cannot run its validation. Building both variants means running the appropriate build once per architecture.

Run the build as your normal user. It downloads the pinned CPython archive, native sources, Python dependencies and verified model checkpoints. It builds the standalone/VST3, runs native timing tests and checks the bundled engine after relocating it. It then uses Apple's `pkgbuild` and `productbuild` to create:

```text
dist/macOS/Local MIDI-0.2.0-macOS-arm64-unsigned.pkg
dist/macOS/Local MIDI-0.2.0-macOS-x86_64-unsigned.pkg
```

Each build creates the matching variant, with an adjacent JSON report recording its CPU profile, package hash, runtime pin, signing state and checks. Downloads and staging files stay in `build/macos-arm64` or `build/macos-x86_64`; each attempt has its own staging directory. Build tools and network access are needed on the build Mac. They are not needed to install the finished package: Python, models, browser assets and audition samples are included.

The Python payload is a checksum-pinned [python-build-standalone distribution](https://github.com/astral-sh/python-build-standalone/releases/tag/20251031), not a moved virtualenv. Archive URLs and hashes are in `python-runtime.json` and `python-runtime-x86_64.json`. Mac builds use native Mac wheels, without CUDA. Runtime libraries must contain the selected processor slice with a deployment target compatible with macOS 12. The native app and VST3 must contain both slices. This lets an Intel DAW under Rosetta load the universal VST3 while the engine uses the installed Mac's profile.

### Engine profiles

| Profile | Python | Torch / Torchaudio | Additional handling |
| --- | --- | --- | --- |
| Apple Silicon `arm64` | 3.12.12 arm64 | 2.5.1 | Existing inference APIs |
| Intel `x86_64` | 3.12.12 x86_64 | 2.2.2 | Scoped attention/autocast API bridge; compatible Intel dependency pins; hash-pinned NCLS source build |

Both use the same model checkpoint files and ONNX Runtime 1.19.2. The Intel profile pins NumPy 1.26.4, SciPy 1.16.1, Numba 0.62.1, llvmlite 0.45.1, scikit-learn 1.7.2, pandas 2.3.3 and Matplotlib 3.10.8. The engine records common, Mac and architecture-specific requirements. NCLS 0.0.70 is compiled from its checksum-pinned source because the release lacks an Intel CPython 3.12 wheel. The compiler uses the target interpreter, architecture and OS minimum.

Each installer gets a fresh runtime directory under `Engine/runtimes/`, selected through the stable `runtime/bin/python3` entry. The launcher resolves the interpreter before execution. This keeps Python prefixes and libraries from different installed profiles or versions separate. Models and user recordings are outside those runtime trees. Previous runtime trees may remain on disk after an upgrade; they are not loaded by the new entry point.

### Why macOS 12 is the current binary target

The initial macOS 14 gate came from the selected ONNX Runtime 1.31 binary, rather than an inherent JUCE or piano-roll requirement. The Mac-specific profile now uses ONNX Runtime 1.19.2, whose [CPython 3.12 universal2 wheel targets macOS 11+](https://pypi.org/project/onnxruntime/1.19.2/). The bundled Basic Pitch model and its hash are unchanged. Shared Windows dependencies retain their existing versions.

The lowest prebuilt Apple Silicon wheel for the pinned [SciPy 1.16.1 targets macOS 12](https://pypi.org/project/scipy/1.16.1/), so the complete binary payload currently targets 12.0. Going lower requires building or replacing additional dependencies and validating them; it is not blocked by an installer policy. Browser drawing and viewport-height fallbacks cover APIs absent from older WebKit versions.

Dependency wheels are resolved explicitly for macOS 12 and the selected processor, then installed offline from that wheelhouse. A newer build Mac cannot silently select a macOS 14/15-only wheel. The Mach-O audit checks the selected slice of runtime libraries and both slices of universal native bundles. The source-only `sox` wrapper is built separately and verified to contain pure Python.

The Intel API bridge maps newer model-facing names to the underlying operations in Torch 2.2 and restores its changes after an inference operation. All five models completed real checkpoint loading/transcription under isolated Torch 2.2.2 and the existing 2.5.1 runtime on the same synthetic Windows CPU fixture, producing identical MIDI bytes. Model weights and pinned vendor files were unchanged. This is model compatibility evidence, not native Mac validation. Apple GPU/MPS acceleration has not been added.

## Signed and notarized releases

The default output is explicitly an **unsigned development package**. A normal distributable release needs signing identities already installed in the build Mac's keychain, and optionally an existing `notarytool` keychain profile:

```bash
bash BuildMac.sh \
  --app-identity 'Developer ID Application: Your Name (TEAMID)' \
  --installer-identity 'Developer ID Installer: Your Name (TEAMID)' \
  --notary-profile 'local-midi-notary'
```

The strings above are placeholders for your identities/profile. Credentials stay in the Mac keychain. Both signing identities must be supplied together. Nested native Python libraries and executables are signed before the native bundles; the package is then signed. With a notary profile, the build submits it to Apple, waits, staples the ticket and verifies it. The pipeline does not disable Gatekeeper or strip quarantine attributes. See Apple's [packaging guide](https://developer.apple.com/documentation/xcode/packaging-mac-software-for-distribution) and [notarization guide](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution).

## Install and update

Choose the `.pkg` matching the Mac's processor and complete Apple's Installer. These are alternative engine packages for the same installed product; install one matching variant. Installer requests administrator authorization for `/Applications` and `/Library`. Launch Local MIDI from Applications, or rescan VST3 plug-ins in your DAW. Allow microphone access when using standalone capture. No Python or model setup is required on the destination Mac.

Before an update, quit Local MIDI and DAWs using its plug-in, then stop this user's shared engine:

```bash
/bin/bash '/Library/Application Support/Local MIDI/Engine/StartMac.sh' --stop
```

The stop command verifies the process, installation and user library before signalling it. Closing an editor alone intentionally leaves the shared engine available. User recordings and project data are outside the installer payload and are not replaced by updates.

## Validation to complete on the build/target Mac

After producing the package, install it on a clean supported Mac. Confirm app launch, WKWebView controls, import, CPU transcription for all five model paths, note editing, MIDI export, audition and microphone capture. Load the VST3 in the chosen DAW and check capture, MIDI output/drag, editor reopening and project recall. Check signing/notarization when preparing a release. These checks are not established by portable unit tests or the Windows build.

The package retains the workspace's existing third-party and model notices in the engine payload. Existing model licence restrictions still apply; see `THIRD_PARTY.md` and `models.json`.
