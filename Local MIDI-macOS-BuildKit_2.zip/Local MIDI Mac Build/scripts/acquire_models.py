"""Acquire the exact private evaluation stack, or verify it entirely offline."""
import argparse
import hashlib
from importlib import metadata, util
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MODELS = Path(os.environ.get("LOCALMIDI_MODELS", ROOT / ".models")).expanduser().resolve()


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def acquire(path, record, verify_only):
    if not path.exists():
        if verify_only:
            raise FileNotFoundError(f"Missing artifact: {path}")
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".part")
        request = urllib.request.Request(record["url"], headers={"User-Agent": "LocalMIDI-setup/1.0"})
        print(f"Downloading {path.name}", flush=True)
        with urllib.request.urlopen(request, timeout=180) as response, temporary.open("wb") as stream:
            shutil.copyfileobj(response, stream, length=1024 * 1024)
        if digest(temporary) != record["sha256"]:
            raise ValueError(f"Hash mismatch: {temporary}. Expected artifact was not installed.")
        temporary.replace(path)
    if digest(path) != record["sha256"]:
        raise ValueError(f"Hash mismatch: {path}. Existing files are never silently replaced.")


def source_tree(archive, target, verify_only):
    with zipfile.ZipFile(archive) as bundle:
        for entry in bundle.infolist():
            parts = PurePosixPath(entry.filename).parts
            if not parts or any(part in ("..", ".") for part in parts) or PurePosixPath(entry.filename).is_absolute():
                raise ValueError("Unsafe source archive")
            if entry.is_dir() or len(parts) < 2:
                continue
            output = target.joinpath(*parts[1:])
            if not output.resolve().is_relative_to(target.resolve()):
                raise ValueError("Unsafe source archive path")
            if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Source archive contains a symbolic link")
            content = bundle.read(entry)
            if output.exists():
                if hashlib.sha256(output.read_bytes()).digest() != hashlib.sha256(content).digest():
                    raise ValueError(f"Vendor source differs from pinned archive: {output}")
            elif verify_only:
                raise FileNotFoundError(f"Missing vendor file: {output}")
            else:
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(content)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true", help="No network and no changes")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "models.json").read_text(encoding="utf-8"))
    for record in manifest["weights"]:
        acquire(MODELS / record["path"], record, args.verify_only)
        print(f"Verified {record['id']} checkpoint", flush=True)
    for record in manifest["sources"]:
        archive = MODELS / record["archive"]
        acquire(archive, record, args.verify_only)
        source_tree(archive, MODELS / record["directory"], args.verify_only)
        print(f"Verified {record['id']} source at {record['revision'][:12]}", flush=True)
    for record in manifest["packaged_weights"]:
        distribution = record.get("distribution", record["package"])
        if metadata.version(distribution) != record["version"]:
            raise ValueError(f"Unexpected {distribution} version")
        package = util.find_spec(record["package"])
        path = Path(package.origin).parent / record["path"]
        if digest(path) != record["sha256"]:
            raise ValueError(f"Packaged checkpoint differs: {path}")
        print(f"Verified {distribution} {record['version']} packaged weights", flush=True)


if __name__ == "__main__":
    main()
