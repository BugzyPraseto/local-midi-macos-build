"""Exercise one real model with an isolated Torch directory; no user jobs/server.

Invoke separately per runtime and model. Output is private MIDI and JSON under a
named build directory. This is a Windows CPU compatibility check when run here;
it does not claim validation of Mac binaries or DAW behavior.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--torch-dir", type=Path)
    parser.add_argument("--model", choices=("imports", "transkun", "aria", "gaps", "tsumugi", "basic_pitch"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=2.0)
    args = parser.parse_args()
    sys.path.insert(0, str(ROOT))
    if args.torch_dir:
        sys.path.insert(0, str(args.torch_dir.resolve()))
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    for variable, name in (("LOCALMIDI_DATA", "data"), ("LOCALMIDI_CACHE", "cache"), ("LOCALMIDI_LOGS", "logs")):
        os.environ[variable] = str(folder / name)
    import engine
    engine.configure()
    started = time.perf_counter()
    import torch
    torch.manual_seed(123)
    torch.set_num_threads(4)
    absent = object()
    original_api = {"attention": getattr(torch.nn, "attention", absent),
                    "enabled": torch.is_autocast_enabled,
                    "dtype": getattr(torch, "get_autocast_dtype", absent),
                    "marker": getattr(torch, "_localmidi_model_api_active", absent)}
    report = {"model": args.model, "torch": str(torch.__version__), "platform": sys.platform,
              "device": "cpu", "mac_binaries_tested": False, "ok": False}
    try:
        if args.model == "imports":
            engine.self_test()
            report["all_model_imports"] = True
        else:
            import numpy as np
            import soundfile as sf
            from localmidi.backends import transcribe
            from localmidi.midi_io import read_midi
            rate = 22050
            samples = np.arange(int(rate * args.seconds), dtype=np.float32) / rate
            audio = np.zeros_like(samples)
            for onset, frequency in ((.1, 261.6256), (.15, 329.6276), (.2, 391.9954), (1.0, 220.0)):
                age = np.maximum(0, samples - onset)
                envelope = (samples >= onset) * np.minimum(age * 50, 1) * np.exp(-age * 2)
                voice = sum(np.sin(2 * np.pi * frequency * harmonic * age) / harmonic for harmonic in range(1, 5))
                audio += .07 * envelope * voice
            source = folder / "synthetic.wav"
            target = folder / (args.model + ".mid")
            sf.write(source, audio, rate, subtype="FLOAT")
            def progress(fraction, message):
                print(json.dumps({"progress": fraction, "message": message}), flush=True)
            metadata = transcribe({"backend": args.model, "instrument": "guitar" if args.model in ("gaps", "tsumugi") else "piano", "device": "cpu"}, source, target, progress)
            midi = read_midi(target)
            report.update(metadata=metadata, notes=len(midi["notes"]), midi=str(target), result=midi)
        report["scoped_api_restored"] = (
            getattr(torch.nn, "attention", absent) is original_api["attention"]
            and torch.is_autocast_enabled is original_api["enabled"]
            and getattr(torch, "get_autocast_dtype", absent) is original_api["dtype"]
            and getattr(torch, "_localmidi_model_api_active", absent) is original_api["marker"])
        if not report["scoped_api_restored"]:
            raise RuntimeError("The compatibility scope leaked a modified Torch API")
        report["ok"] = True
    except Exception as error:
        report["error"] = str(error)
        traceback.print_exc()
    report["elapsed_seconds"] = round(time.perf_counter() - started, 3)
    (folder / (args.model + ".json")).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "result"}), flush=True)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
