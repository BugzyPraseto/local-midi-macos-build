"""Compare Basic Pitch's bundled ONNX graph across isolated runtime versions.

Run twice with distinct --output paths and, for the compatibility runtime,
--module-dir pointing to a separate pip --target directory. No user audio,
installed packages, application service or model files are changed.
"""
import argparse
import hashlib
from importlib import metadata
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--module-dir", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.module_dir:
        sys.path.insert(0, str(args.module_dir.resolve()))
    import numpy as np
    import onnxruntime as ort
    model = Path(metadata.distribution("basic-pitch").locate_file("basic_pitch/saved_models/icassp_2022/nmp.onnx"))
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(str(model), sess_options=options, providers=["CPUExecutionProvider"])
    shape = session.get_inputs()[0].shape
    frames = next(size for size in shape[1:] if isinstance(size, int) and size > 1)
    time = np.arange(frames, dtype=np.float32) / 22050
    envelope = np.minimum(time * 10, 1) * np.exp(-time * 1.1)
    chord = sum(np.sin(2 * np.pi * frequency * time) for frequency in (261.63, 329.63, 392.00)) / 9
    pluck = sum(np.sin(2 * np.pi * 110 * harmonic * time) / harmonic for harmonic in range(1, 7)) / 6
    noise = np.random.default_rng(123).normal(0, .03, frames).astype(np.float32)
    cases = {"silence": np.zeros(frames), "chord": chord * envelope,
             "pluck": pluck * envelope, "noisy_chord": (chord + noise) * envelope}
    outputs = {}
    for name, waveform in cases.items():
        tensors = session.run(None, {session.get_inputs()[0].name: waveform.astype(np.float32).reshape(1, frames, 1)})
        for index, tensor in enumerate(tensors):
            if not np.isfinite(tensor).all():
                raise ValueError("Non-finite inference output: " + name)
            outputs[name + "_" + str(index)] = tensor
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(args.output, **outputs)
    report = {"onnxruntime": ort.__version__, "platform": sys.platform, "provider": "CPUExecutionProvider",
              "model_sha256": hashlib.sha256(model.read_bytes()).hexdigest(),
              "cases": list(cases), "output_tensors": len(outputs), "finite": True}
    args.output.with_suffix(".json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
