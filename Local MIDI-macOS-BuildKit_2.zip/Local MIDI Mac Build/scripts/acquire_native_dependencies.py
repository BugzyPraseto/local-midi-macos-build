"""Fetch the pinned JUCE/WebView2 source archives without altering system SDKs."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / ".native-deps"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--platform", choices=("windows", "macos"),
                        default="macos" if sys.platform == "darwin" else "windows")
    args = parser.parse_args()
    records = json.loads((ROOT / "native/dependencies.json").read_text(encoding="utf-8"))
    TARGET.mkdir(exist_ok=True)
    for record in records:
        if args.platform == "macos" and record["name"] == "WebView2":
            continue
        archive = TARGET / (record["name"] + ".zip")
        if not archive.exists():
            if args.verify_only:
                raise FileNotFoundError(archive)
            temporary = archive.with_suffix(".part")
            request = urllib.request.Request(record["url"], headers={"User-Agent": "LocalMIDI-native-build/1.0"})
            print(f"Downloading {record['name']} {record['version']}", flush=True)
            with urllib.request.urlopen(request, timeout=180) as response, temporary.open("wb") as stream:
                shutil.copyfileobj(response, stream)
            if digest(temporary) != record["sha256"]:
                raise ValueError(f"Unexpected {record['name']} archive hash")
            temporary.replace(archive)
        if digest(archive) != record["sha256"]:
            raise ValueError(f"Unexpected {record['name']} archive hash")
        target = TARGET / record["directory"]
        with zipfile.ZipFile(archive) as source:
            for entry in source.infolist():
                parts = PurePosixPath(entry.filename).parts
                if record["strip_root"]:
                    parts = parts[1:]
                if not parts or entry.is_dir():
                    continue
                output = target.joinpath(*parts)
                if not output.resolve().is_relative_to(target.resolve()):
                    raise ValueError("Unsafe dependency archive path")
                content = source.read(entry)
                if output.exists():
                    if hashlib.sha256(output.read_bytes()).digest() != hashlib.sha256(content).digest():
                        raise ValueError(f"Dependency source was modified: {output}")
                elif args.verify_only:
                    raise FileNotFoundError(output)
                else:
                    output.parent.mkdir(parents=True, exist_ok=True)
                    output.write_bytes(content)
        print(f"Verified {record['name']} {record['version']}", flush=True)
    (ROOT / "static/juce").mkdir(exist_ok=True)
    if not args.verify_only:
        for name in ("index.js", "check_native_interop.js"):
            shutil.copyfile(TARGET / "JUCE/modules/juce_gui_extra/native/javascript" / name,
                            ROOT / "static/juce" / name)


if __name__ == "__main__":
    main()
