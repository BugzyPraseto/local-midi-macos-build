"""Create a small Mac source/build transfer kit; never label it as a built installer."""
import argparse
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FOLDER = "Local MIDI Mac Build"
SOURCES = ("BuildMac.sh", "BuildMac.command", "StartMac.sh", "engine.py", "requirements.txt",
           "models.json", "README.md", "THIRD_PARTY.md", "native", "localmidi", "static",
           "tests", "scripts/acquire_native_dependencies.py", "scripts/acquire_models.py",
           "scripts/fetch_preview_samples.py", "scripts/make_mac_build_kit.py", "scripts/check_onnx_compatibility.py",
           "scripts/check_torch_compatibility.py", "scripts/audit_macos_payload.py")
TEXT_EXTENSIONS = {".py", ".sh", ".command", ".json", ".md", ".txt", ".cpp", ".h", ".cmake", ".plist", ".html", ".js", ".css", ".svg"}


def source_files():
    found = set()
    for name in SOURCES:
        source = ROOT / name
        if not source.exists():
            raise FileNotFoundError("Missing build-kit source: " + name)
        for path in source.rglob("*") if source.is_dir() else (source,):
            if not path.is_file():
                continue
            relative = path.relative_to(ROOT)
            if any(part in {"__pycache__", ".pytest_cache", "build", "dist", ".local", ".venv", ".models", ".native-deps"} for part in relative.parts):
                continue
            if path.suffix in {".pyc", ".pyo"} or path.name == ".DS_Store":
                continue
            if path.is_symlink():
                raise ValueError("Unexpected source symlink: " + str(relative))
            found.add(relative)
    return sorted(found)


def write_entry(archive, relative, content, executable=False):
    record = zipfile.ZipInfo(FOLDER + "/" + str(relative).replace("\\", "/"))
    record.create_system = 3
    record.external_attr = (stat.S_IFREG | (0o755 if executable else 0o644)) << 16
    record.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(record, content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "dist/macOS/Local MIDI-macOS-BuildKit.zip")
    args = parser.parse_args()
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    files = source_files()
    temporary = output.with_name(output.name + ".part")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for relative in files:
            data = (ROOT / relative).read_bytes()
            if relative.suffix in TEXT_EXTENSIONS:
                data = data.replace(b"\r\n", b"\n")
            write_entry(archive, relative, data, relative.suffix in {".sh", ".command"})
        write_entry(archive, "READ ME FIRST.txt", (
            "LOCAL MIDI MAC BUILD KIT\n\n"
            "This is source/build tooling, not a compiled Mac installer.\n"
            "Targets: Apple Silicon and Intel, macOS 12 or later, CPU inference.\n\n"
            "On the Mac: install Xcode Command Line Tools and CMake 3.24+,\n"
            "then double-click BuildMac.command or run: bash BuildMac.sh\n"
            "The build selects the Mac's physical CPU automatically.\n"
            "Explicit variants: --arch arm64 or --arch x86_64.\n"
            "Both include universal2 app/VST3 bundles and a CPU-matched engine.\n"
            "The build downloads its pinned dependencies and model files.\n"
            "The finished installer is written to dist/macOS.\n"
            "That installer includes Python and models for offline installation.\n\n"
            "Read native/macos/README.md for signing, install paths and validation.\n"
        ).encode("utf-8"))
    temporary.replace(output)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError("Build-kit archive verification failed")
    sha256 = hashlib.sha256(output.read_bytes()).hexdigest()
    report = {"artifact": "source build kit, not a compiled installer", "file": output.name,
              "sha256": sha256, "files": len(files) + 1, "bytes": output.stat().st_size,
              "target": "Apple Silicon and Intel macOS 12+", "mac_build_required": True,
              "included": [str(path).replace("\\", "/") for path in files]}
    output.with_suffix(".zip.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "included"}, indent=2))
    print(output)


if __name__ == "__main__":
    main()
