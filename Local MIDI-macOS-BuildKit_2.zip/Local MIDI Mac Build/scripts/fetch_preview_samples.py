"""Download local preview samples as data, never execute third-party JavaScript."""
import hashlib
import json
from pathlib import Path
import re
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "static/samples"


def main():
    TARGET.mkdir(parents=True, exist_ok=True)
    records = []
    for name, instrument in (("piano", "acoustic_grand_piano"), ("guitar", "acoustic_guitar_nylon")):
        url = f"https://raw.githubusercontent.com/gleitz/midi-js-soundfonts/gh-pages/FluidR3_GM/{instrument}-mp3.js"
        request = urllib.request.Request(url, headers={"User-Agent": "LocalMIDI-setup/1.0"})
        source = urllib.request.urlopen(request, timeout=90).read()
        text = source.decode("utf-8")
        marker = re.search(r"MIDI\.Soundfont\.\w+\s*=\s*", text)
        if not marker:
            raise ValueError("Unexpected sample format")
        # The upstream object literal has a final trailing comma; data URLs
        # contain neither braces nor commas followed by a closing brace.
        payload = re.sub(r",(\s*})", r"\1", text[marker.end():])
        samples, _ = json.JSONDecoder().raw_decode(payload)
        if not all(re.fullmatch(r"[A-G][b#]?-?\d+", key) and value.startswith("data:audio/mp3;base64,")
                   for key, value in samples.items()):
            raise ValueError("Unexpected sample payload")
        names = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
        numbered = {}
        for key, value in samples.items():
            letter, accidental, octave = re.fullmatch(r"([A-G])([b#]?)(-?\d+)", key).groups()
            pitch = (int(octave) + 1) * 12 + names[letter] + {"b": -1, "#": 1, "": 0}[accidental]
            numbered[str(pitch)] = value
        output = TARGET / f"{name}.json"
        output.write_text(json.dumps(numbered, separators=(",", ":")), encoding="utf-8")
        records.append({"instrument": instrument, "file": output.name, "source": url,
                        "source_sha256": hashlib.sha256(source).hexdigest(),
                        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
                        "license": "CC-BY-3.0", "samples": len(samples)})
        print(f"{name}: {len(samples)} samples, {output.stat().st_size:,} bytes", flush=True)
    (TARGET / "manifest.json").write_text(json.dumps(records, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
