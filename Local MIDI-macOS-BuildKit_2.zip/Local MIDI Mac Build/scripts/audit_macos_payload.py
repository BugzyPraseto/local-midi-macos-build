"""Inspect Mac CPU/OS load commands inside wheels or runtime archives, without executing them."""
import argparse
import json
from pathlib import Path
import struct
import tarfile
import zipfile

CPU_NAMES = {0x01000007: "x86_64", 0x0100000C: "arm64"}
THIN = {b"\xcf\xfa\xed\xfe": ("<", 32), b"\xfe\xed\xfa\xcf": (">", 32),
        b"\xce\xfa\xed\xfe": ("<", 28), b"\xfe\xed\xfa\xce": (">", 28)}
FAT = {b"\xca\xfe\xba\xbe": (">", False), b"\xbe\xba\xfe\xca": ("<", False),
       b"\xca\xfe\xba\xbf": (">", True), b"\xbf\xba\xfe\xca": ("<", True)}


def version(number):
    return [number >> 16, (number >> 8) & 255, number & 255]


def macho_slices(data):
    """Return each slice's real deployment commands; unrecognized data is not code."""
    magic = bytes(data[:4])
    if magic in FAT:
        endian, large = FAT[magic]
        if len(data) < 8:
            raise ValueError("Truncated universal binary header")
        count = struct.unpack_from(endian + "I", data, 4)[0]
        size = 32 if large else 20
        if not 1 <= count <= 128 or 8 + count * size > len(data):
            raise ValueError("Invalid universal binary slice table")
        output = []
        for index in range(count):
            start = 8 + index * size
            cpu = struct.unpack_from(endian + "I", data, start)[0]
            offset, length = struct.unpack_from(endian + ("QQ" if large else "II"), data, start + 8)
            if offset < 8 + count * size or not length or offset + length > len(data):
                raise ValueError("Universal binary slice escaped its container")
            slices = macho_slices(data[offset:offset + length])
            if len(slices) != 1 or slices[0]["cpu_type"] != cpu:
                raise ValueError("Universal slice CPU header mismatch")
            output.extend(slices)
        return output
    if magic not in THIN:
        return []
    endian, header = THIN[magic]
    if len(data) < header:
        raise ValueError("Truncated Mach-O header")
    cpu, _, file_type, commands, command_bytes = struct.unpack_from(endian + "IIIII", data, 4)
    limit = header + command_bytes
    if commands > 16384 or limit > len(data):
        raise ValueError("Mach-O load commands escaped their container")
    deployments, position = [], header
    for _ in range(commands):
        if position + 8 > limit:
            raise ValueError("Truncated Mach-O load command")
        command, size = struct.unpack_from(endian + "II", data, position)
        if size < 8 or position + size > limit:
            raise ValueError("Invalid Mach-O load-command size")
        if command == 0x32:  # LC_BUILD_VERSION
            if size < 24:
                raise ValueError("Truncated LC_BUILD_VERSION")
            target, minimum = struct.unpack_from(endian + "II", data, position + 8)
            deployments.append({"platform": target, "minimum": version(minimum)})
        elif command == 0x24:  # LC_VERSION_MIN_MACOSX
            if size < 16:
                raise ValueError("Truncated LC_VERSION_MIN_MACOSX")
            deployments.append({"platform": 1, "minimum": version(struct.unpack_from(endian + "I", data, position + 8)[0])})
        position += size
    if position != limit:
        raise ValueError("Mach-O load-command byte count does not match its header")
    return [{"cpu_type": cpu, "architecture": CPU_NAMES.get(cpu, str(cpu)),
             "file_type": file_type, "deployments": deployments}]


def audit_binary(data, architecture, minimum):
    slices = macho_slices(data)
    if not slices:
        return None
    selected = [item for item in slices if item["architecture"] == architecture]
    if len(selected) != 1:
        raise ValueError("Expected one " + architecture + " slice")
    commands = selected[0]["deployments"]
    if not commands or any(item["platform"] != 1 for item in commands):
        raise ValueError("Selected slice is missing a macOS deployment target")
    maximum = max(tuple(item["minimum"]) for item in commands)
    requested = tuple((list(minimum) + [0, 0, 0])[:3])
    if maximum > requested:
        raise ValueError("Selected slice requires macOS " + ".".join(map(str, maximum)))
    return {"architecture": architecture, "minimum_macos": list(maximum)}


def archive_binaries(path):
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if name.endswith(("/", ".class")):
                    continue
                with archive.open(name) as stream:
                    head = stream.read(4)
                    if head in THIN or head in FAT:
                        yield name, head + stream.read()
    else:
        with tarfile.open(path, "r:*") as archive:
            for item in archive:
                if not item.isfile() or item.name.endswith(".class"):
                    continue
                with archive.extractfile(item) as stream:
                    head = stream.read(4)
                    if head in THIN or head in FAT:
                        yield item.name, head + stream.read()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archives", type=Path, nargs="+")
    parser.add_argument("--architecture", choices=CPU_NAMES.values(), required=True)
    parser.add_argument("--minimum-macos", default="12.0")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    minimum = tuple(map(int, args.minimum_macos.split(".")))
    result = {"architecture": args.architecture, "minimum_macos": args.minimum_macos,
              "executed_mac_code": False, "archives": []}
    for path in args.archives:
        rows = []
        for name, data in archive_binaries(path):
            try:
                rows.append({"file": name, **audit_binary(data, args.architecture, minimum)})
            except ValueError as error:
                raise ValueError(str(path) + ": " + name + ": " + str(error)) from error
        result["archives"].append({"archive": path.name, "native_files": len(rows), "files": rows})
    result["passed"] = True
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({**result, "archives": [{key: row[key] for key in ("archive", "native_files")} for row in result["archives"]]}))


if __name__ == "__main__":
    main()
