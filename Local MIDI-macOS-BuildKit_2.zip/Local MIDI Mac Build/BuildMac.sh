#!/bin/bash
# Build for Apple Silicon or Intel; the installed product includes its own Python.
set -euo pipefail
task_root="$(cd "$(dirname "$0")" && pwd)"
if [[ "$(uname -s)" != "Darwin" ]]; then
    printf '%s\n' 'BuildMac.sh must run on macOS. It cannot turn the Windows executable into a Mac app.' >&2
    exit 1
fi
if ! /usr/bin/xcode-select -p >/dev/null 2>&1; then
    printf '%s\n' 'Install the Xcode Command Line Tools first: xcode-select --install' >&2
    exit 1
fi
build_python=/usr/bin/python3
if [[ ! -x "$build_python" ]]; then build_python="$(command -v python3 || true)"; fi
if [[ -z "$build_python" ]]; then
    printf '%s\n' 'Python 3 is needed only to run the build script. Xcode Command Line Tools provides it.' >&2
    exit 1
fi
exec "$build_python" "$task_root/native/macos/build_installer.py" "$@"
