"use strict";
// Read-only geometry, deliberately separate from active notes, hit testing and MIDI.
(() => {
  let elements = null, source, sourceTicket, active, resultTicket;
  let choice = null, pendingRestore = null, cache = new Map(), data = null;
  let request = null, ticket = 0, frame = 0, visual = null, optionKey = "", notice = "";
  let committed = null;
  const interacting = () => !!window.LocalMidiUI?.isInteracting?.();
  const sourceId = () => state.audio?.id ?? null;
  const activeId = () => state.result?.id ?? null;
  const setText = (element, text) => { if (element && element.textContent !== text) element.textContent = text; };
  function attribute(element, name, value) {
    if (element && element.getAttribute(name) !== String(value)) element.setAttribute(name, String(value));
  }
  function hidden(element, value) {
    if (!element) return;
    if (element.hidden !== value) element.hidden = value;
    if (element.classList.contains("hidden") !== value) element.classList.toggle("hidden", value);
  }
  const belongs = item => item && (item.audio_id == null || item.audio_id === source);
  const jobs = () => source == null ? [] : (state.jobs || []).filter(item => belongs(item) && item.state === "complete");
  const jobFor = id => jobs().find(item => item.id === id && item.id !== active);
  const nameFor = item => item?.label || modelName(item?.backend);
  const revision = item => JSON.stringify([item.revision ?? null, item.updated_at ?? null, item.edit_version ?? null]);
  const enabled = () => source != null && source === sourceId() && sourceTicket === state.sourceTicket &&
    active != null && active === activeId() && belongs(state.result) && resultTicket === state.resultTicket &&
    !!choice && choice !== active && !state.loadingResult && state.view === "edit";
  const visibleData = () => enabled() && data?.id === choice && data.source === source && data.notes.length ? data : null;

  function cancelRequest() {
    ++ticket;
    request?.controller?.abort();
    request = null;
  }
  function queueVisual() {
    if (!frame) frame = requestAnimationFrame(() => {
      frame = 0;
      // resizeRoll reads the cached duration. It must not call overlay.update().
      resizeRoll();
      drawRoll();
    });
  }
  function syncVisual() {
    const next = visibleData();
    if (next !== visual) { visual = next; queueVisual(); }
  }
  function syncContext() {
    const nextSource = sourceId(), nextActive = activeId();
    const changedSource = source !== nextSource || sourceTicket !== state.sourceTicket;
    if (changedSource) {
      const awaitingInitialSource = source == null && pendingRestore &&
        (pendingRestore.source == null || pendingRestore.source === nextSource);
      cancelRequest(); cache.clear(); data = null; choice = null; committed = null; notice = ""; optionKey = "";
      if (!awaitingInitialSource) pendingRestore = null;
      else if (nextSource != null) pendingRestore.source = nextSource;
    }
    if (changedSource || active !== nextActive || resultTicket !== state.resultTicket) {
      cancelRequest(); data = null;
      // A formerly active browser take may have been saved, restored or undone.
      // Never reuse its earlier GET response after visiting it in the editor.
      cache.delete(active); cache.delete(nextActive); committed = null; optionKey = "";
      if (choice === nextActive) { choice = null; notice = "The active take cannot be its own outline."; }
      if (pendingRestore?.id === nextActive) { pendingRestore = null; notice = "The active take cannot be its own outline."; }
    }
    source = nextSource; sourceTicket = state.sourceTicket;
    active = nextActive; resultTicket = state.resultTicket;
  }
  function resolveRestore() {
    if (!pendingRestore || source == null) return;
    if (pendingRestore.source != null && pendingRestore.source !== source) { pendingRestore = null; return; }
    pendingRestore.source = source;
    if (jobFor(pendingRestore.id)) {
      choice = pendingRestore.id; pendingRestore = null; notice = "";
    } else {
      const item = (state.jobs || []).find(item => belongs(item) && item.id === pendingRestore.id);
      if (!item && ((state.jobs || []).length || pendingRestore.jobs !== state.jobs)) {
        pendingRestore = null; notice = "The saved outline take is unavailable. Choose another completed take.";
      }
    }
  }
  function syncOptions() {
    if (!elements) return;
    const items = jobs().filter(item => item.id !== active);
    const key = JSON.stringify([source, active, items.map(item => [item.id, nameFor(item)])]);
    if (key !== optionKey) {
      optionKey = key;
      const none = document.createElement("option"); none.value = ""; none.textContent = "None"; none.disabled = false;
      const options = items.map(item => {
        const option = document.createElement("option"); option.value = item.id; option.textContent = nameFor(item); return option;
      });
      elements.select.replaceChildren(none, ...options);
    }
    elements.select.disabled = false;
    if (elements.select.value !== (choice || "")) elements.select.value = choice || "";
  }
  function syncStatus() {
    if (!elements) return;
    const item = choice && jobFor(choice), label = item ? nameFor(item) : "";
    const shown = visibleData(), busy = !!request && enabled();
    let text = notice || "No outline. Editing and export use the active take.";
    if (pendingRestore) text = "Waiting for the saved outline take…";
    else if (item) {
      if (!active) text = `Choose an active take to see the outline from ${label}.`;
      else if (state.loadingResult) text = `Outline from ${label} is paused while the active take loads.`;
      else if (state.view !== "edit") text = `Outline from ${label} is available in Edit. Editing and export use the active take.`;
      else if (request) text = `Loading outline from ${label}… Editing and export use the active take.`;
      else if (cache.get(choice)?.error) text = `Could not load outline from ${label}: ${cache.get(choice).error} Choose None, then this take to retry.`;
      else if (data && !data.notes.length) text = `${label} has no notes to outline. Editing and export use the active take.`;
      else if (shown) text = `Outline: ${label} · ${shown.notes.length} read-only notes. Editing and export use the active take.`;
    }
    setText(elements.status, text);
    attribute(elements.select, "aria-busy", busy);
    const title = shown ? `Read-only outline from ${label}. Editing, playback and export use the active take.` : "";
    hidden(elements.badge, !shown); attribute(elements.badge, "title", title);
    attribute(elements.badge, "aria-label", shown ? `Read-only overlay: ${label}` : "");
    const legend = document.getElementById("overlay-legend");
    hidden(legend, !shown); setText(legend, shown ? `Outline: ${label}` : ""); attribute(legend, "title", title);
  }
  function snapshot(id, notes, origin, identity, jobRevision, takeRevision) {
    const geometry = [];
    let maxEnd = 0;
    for (const note of notes) {
      if (!note || !Number.isFinite(note.start) || !Number.isFinite(note.end) ||
          !Number.isInteger(note.pitch) || note.pitch < 0 || note.pitch > HIGH || note.start < 0 || note.end <= note.start) continue;
      geometry.push({start: note.start, end: note.end, pitch: note.pitch});
      maxEnd = Math.max(maxEnd, note.end);
    }
    return {id, source, notes: geometry, maxEnd, origin, identity, jobRevision, takeRevision};
  }
  function committedReference(id) {
    const take = window.LocalMidiUI?.getReferenceTake?.(id);
    const validTake = take && (take.id == null || take.id === id) && belongs(take) && Array.isArray(take.notes);
    // Instance edits always win, even before a backend result has entered the UI cache.
    const native = state.native && state.nativeEdits?.get(id);
    if (native && Array.isArray(native.notes)) return {notes: native.notes, origin: "native", revision: native.revision};
    return validTake ? {notes: take.notes, origin: "committed", revision: take.revision ?? take.editVersion} : null;
  }
  function currentRequest(value) {
    return request === value && ticket === value.ticket && enabled() && choice === value.id &&
      source === value.source && active === value.active && sourceTicket === value.sourceTicket &&
      resultTicket === value.resultTicket && !!jobFor(value.id) && revision(jobFor(value.id)) === value.jobRevision;
  }
  function load(item) {
    const value = {id: choice, source, active, sourceTicket, resultTicket, jobRevision: revision(item), ticket: ++ticket,
      controller: typeof AbortController === "function" ? new AbortController() : null};
    request = value;
    // GET only. Rejections are cached until an explicit retry or revision invalidation.
    Promise.resolve().then(() => {
      if (!currentRequest(value)) return null;
      return api(`/api/jobs/${encodeURIComponent(value.id)}/result`, {method: "GET", signal: value.controller?.signal});
    }).then(result => {
      if (!currentRequest(value)) return;
      if (!result || result.id !== value.id || result.audio_id !== value.source || !Array.isArray(result.notes)) {
        throw Error("The reference result does not match this source and take.");
      }
      value.loaded = result;
      update();
    }).catch(error => {
      if (!currentRequest(value)) return;
      value.error = error?.message || "The take could not be read.";
      update();
    });
  }
  function bind() {
    if (elements) return true;
    const select = document.getElementById("overlay-take"), status = document.getElementById("overlay-status");
    if (!select || !status) return false;
    elements = {select, status, badge: document.getElementById("overlay-badge")};
    attribute(select, "aria-label", "Read-only outline from another take");
    attribute(select, "aria-describedby", "overlay-status");
    attribute(status, "role", "status"); attribute(status, "aria-live", "polite"); attribute(status, "aria-atomic", true);
    select.addEventListener("change", () => {
      syncContext();
      const previous = choice || pendingRestore?.id || null;
      const next = jobFor(select.value) ? select.value : null;
      cancelRequest(); pendingRestore = null; choice = next; data = null; notice = "";
      if (next && cache.get(next)?.error) cache.delete(next);
      update();
      if (previous !== choice) publishNativeUi();
    });
    return true;
  }
  function update() {
    bind(); syncContext(); resolveRestore();
    if (request && !currentRequest(request)) cancelRequest();
    const item = choice && jobFor(choice);
    if (choice && !item) { cancelRequest(); choice = null; data = null; notice = "The outline take is no longer available."; }
    syncOptions();
    if (!choice || !enabled()) {
      if (request) cancelRequest();
      data = null; syncVisual(); syncStatus(); return;
    }
    // Live gesture previews must not become committed reference snapshots, nor
    // should unrelated UI updates rescan any note array during those gestures.
    if (!interacting()) {
      if (!committed || committed.id !== active || committed.version !== state.editVersion || committed.notes !== state.notes) {
        cache.delete(active);
        committed = {id: active, version: state.editVersion, notes: state.notes};
      }
      const ref = committedReference(choice), jobRevision = revision(item);
      let entry = cache.get(choice);
      if (ref) {
        if (request) cancelRequest();
        if (!entry || entry.identity !== ref.notes || entry.origin !== ref.origin ||
            entry.jobRevision !== jobRevision || entry.takeRevision !== ref.revision) {
          entry = snapshot(choice, ref.notes, ref.origin, ref.notes, jobRevision, ref.revision);
          cache.set(choice, entry);
        }
      } else {
        if (entry && (entry.origin !== "fetch" || entry.jobRevision !== jobRevision)) { cache.delete(choice); entry = null; }
        if (request?.loaded || request?.error) {
          entry = request.error ? {origin: "fetch", jobRevision, error: request.error} :
            snapshot(choice, request.loaded.notes, "fetch", request.loaded.notes, jobRevision);
          cache.set(choice, entry); request = null;
        }
        if (!entry && !request) load(item);
      }
      data = entry && !entry.error ? entry : null;
    }
    syncVisual(); syncStatus();
  }
  function paint(context, width, height, scrollLeft, scrollTop) {
    const current = visibleData(), px = Number(state.px);
    if (!current || !(px > 0) || !(ROW > 3) || !(width > KEYS) || !(height > 0)) return;
    const high = Math.min(HIGH, HIGH - Math.floor(scrollTop / ROW));
    const low = Math.max(0, HIGH - Math.ceil((scrollTop + height) / ROW));
    const start = (scrollLeft - KEYS) / px, end = (scrollLeft + width - KEYS) / px;
    context.save();
    try {
      context.globalAlpha = .62; context.globalCompositeOperation = "source-over";
      context.strokeStyle = "#8f9ca8"; context.lineWidth = 1; context.setLineDash([3, 3]); context.lineDashOffset = 0;
      context.beginPath(); context.rect(KEYS, 0, width - KEYS, height); context.clip();
      context.beginPath();
      for (const note of current.notes) {
        if (note.pitch < low || note.pitch > high || note.end + 3 / px < start || note.start > end) continue;
        const x = KEYS + note.start * px - scrollLeft, y = (HIGH - note.pitch) * ROW + 2 - scrollTop;
        const w = Math.max(3, (note.end - note.start) * px), h = ROW - 3;
        // Inset the one-pixel stroke: ghost and active bodies share outer bounds.
        MidiCanvasGeometry.roundRect(context, x + .5, y + .5, w - 1, h - 1, Math.min(3, (w - 1) / 2, (h - 1) / 2));
      }
      context.stroke();
    } finally { context.restore(); }
  }
  function duration() { return visibleData()?.maxEnd || 0; }
  function getPreferences() {
    const id = choice || pendingRestore?.id || null;
    return {overlay_take: source === sourceId() && sourceTicket === state.sourceTicket && id !== activeId() ? id : null};
  }
  function restore(saved = {}) {
    syncContext(); cancelRequest(); choice = null; data = null; notice = "";
    const id = typeof saved.overlay_take === "string" && saved.overlay_take ? saved.overlay_take : null;
    pendingRestore = id && id !== active && (saved.audio_id == null || source == null || saved.audio_id === source) ?
      {id, source: saved.audio_id ?? source, jobs: state.jobs} : null;
    update();
  }
  function invalidate(id = null) {
    if (id == null) cache.clear(); else cache.delete(id);
    if (id == null || id === choice) { cancelRequest(); data = null; }
    update();
  }
  // Browser QA gets an opaque, one-shot rollback; no note data or cache setters
  // escape this module. Call it after restoring the parent's source/state/hooks.
  function checkpoint() {
    const saved = {source, sourceTicket, active, resultTicket, choice, pendingRestore: pendingRestore && {...pendingRestore},
      cache: new Map(cache), data, committed, notice};
    let restored = false;
    return () => {
      if (restored) return;
      restored = true; cancelRequest();
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
      ({source, sourceTicket, active, resultTicket, choice, pendingRestore, cache, data, committed, notice} = saved);
      optionKey = ""; visual = null;
      update(); queueVisual();
    };
  }
  window.LocalMidiOverlay = {update, paint, duration, getPreferences, restore, invalidate, checkpoint};
  update();
})();
