"use strict";
// Note commands share app.js history/persistence and workspace.js selection hooks.
(() => {
  const MAX_NOTES=100000,EPSILON=1e-9;
  const element=id=>document.getElementById(id);
  const buttons=new Map([
    ["notes-copy","copy"],["notes-cut","cut"],["notes-paste","paste"],["notes-duplicate","duplicate"],
    ["notes-quantize","quantize"],["notes-down","down"],["notes-up","up"],
    ["selection-down","down"],["selection-up","up"],["selection-duplicate","duplicate"]
  ]);
  const menu=element("note-actions"),panel=menu?.querySelector(".actions-panel"),summary=menu?.querySelector("summary");
  const velocity=element("selection-velocity");
  let clipboard=[],idSequence=0,menuFrame=0;
  const editable=()=>!!state.result&&!state.loadingResult&&state.view!=="compare";
  const selectedNotes=()=>state.notes.filter(note=>state.selectedIds.has(note.id)||note.id===state.selected);
  const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
  function gridStep(){
    const division=Number(element("editor-snap")?.value);
    return Number.isFinite(division)&&division>0?240/clamp(Number(element("bpm")?.value)||120,20,400)/division:0;
  }
  function statistics(notes){
    const result={count:notes.length,start:Infinity,end:-Infinity,low:127,high:0,velocityLow:127,velocityHigh:1,mean:0};
    for(const note of notes){
      result.start=Math.min(result.start,note.start);result.end=Math.max(result.end,note.end);
      result.low=Math.min(result.low,note.pitch);result.high=Math.max(result.high,note.pitch);
      result.velocityLow=Math.min(result.velocityLow,note.velocity);result.velocityHigh=Math.max(result.velocityHigh,note.velocity);
      result.mean+=note.velocity;
    }
    if(notes.length)result.mean/=notes.length;
    return result;
  }
  function text(id,value){const node=element(id);if(node&&node.textContent!==value)node.textContent=value;}
  function hidden(id,value){element(id)?.classList.toggle("hidden",value);}
  function update(){
    const stats=statistics(selectedNotes()),available=editable()&&stats.count>0,step=gridStep();
    for(const [id,command] of buttons){
      const button=element(id);if(!button)continue;
      let enabled=available;
      if(command==="paste")enabled=editable()&&clipboard.length>0&&state.notes.length+clipboard.length<=MAX_NOTES;
      if(command==="duplicate")enabled=available&&state.notes.length+stats.count<=MAX_NOTES;
      if(command==="quantize")enabled=available&&step>0;
      if(command==="down")enabled=available&&stats.low>0;
      if(command==="up")enabled=available&&stats.high<127;
      button.disabled=!enabled;
    }
    hidden("inspector-empty",stats.count>0);hidden("inspector-fields",stats.count!==1);hidden("selection-inspector",stats.count<=1);
    if(velocity)velocity.disabled=!available||stats.count<=1;
    if(stats.count>1){
      text("selection-size",stats.count+" notes selected");
      const pitches=stats.low===stats.high?pitchName(stats.low):pitchName(stats.low)+"\u2013"+pitchName(stats.high);
      text("selection-range",pitches+" \u00b7 velocity "+stats.velocityLow+"\u2013"+stats.velocityHigh);
      text("selection-time",stats.start.toFixed(3)+"\u2013"+stats.end.toFixed(3)+" s \u00b7 "+(stats.end-stats.start).toFixed(3)+" s duration");
      if(velocity&&document.activeElement!==velocity)velocity.value=String(Number(stats.mean.toFixed(2)));
    }
  }
  function prepare(){
    if(!editable())return false;
    const ui=window.LocalMidiUI;
    if(ui?.isInteracting?.()&&!ui.cancelPendingGesture)return false;
    // Cancellation can replace both the notes array and the selection. Read them afterward.
    ui?.cancelPendingGesture?.();
    return editable();
  }
  function commit(apply){
    pause();checkpoint();apply();changed();window.LocalMidiUI?.selectionChanged();update();
    return true;
  }
  function selectCreated(notes){
    state.selectedIds=new Set(notes.map(note=>note.id));state.selected=notes[0]?.id??null;
  }
  function copies(notes,offset){
    const occupied=new Set([...state.notes,...clipboard].map(note=>note.id));
    return clone(notes).map(note=>{
      const base=globalThis.crypto?.randomUUID?.()||"local-note-"+Date.now().toString(36)+"-"+(++idSequence);
      let id=base;while(occupied.has(id))id=base+"-"+(++idSequence);occupied.add(id);
      return {...note,id,start:note.start+offset,end:note.end+offset};
    });
  }
  function move(notes,time,pitch){
    if(!notes.length)return false;
    const stats=statistics(notes);
    time=Math.max(-stats.start,time);pitch=clamp(pitch,-stats.low,127-stats.high);
    if(Math.abs(time)<EPSILON&&pitch===0)return false;
    return commit(()=>{for(const note of notes){note.start+=time;note.end+=time;note.pitch+=pitch;}});
  }
  function command(name,delta=0){
    if(!prepare())return false;
    const notes=selectedNotes();
    if(name==="paste"){
      if(!clipboard.length||state.notes.length+clipboard.length>MAX_NOTES)return false;
      // The cancel hook also drops pending ruler seeks before reading the playhead.
      const playhead=Number(playbackTime());if(!Number.isFinite(playhead))return false;
      const step=gridStep(),anchor=step?Math.round(Math.max(0,playhead)/step)*step:Math.max(0,playhead);
      const added=copies(clipboard,anchor-statistics(clipboard).start);
      return commit(()=>{state.notes=state.notes.concat(added);selectCreated(added);});
    }
    if(!notes.length)return false;
    if(name==="clear"){
      state.selectedIds=new Set();state.selected=null;state.exportScope="all";
      window.LocalMidiUI?.selectionChanged();update();return true;
    }
    if(name==="copy"){clipboard=clone(notes);update();return true;}
    if(name==="cut"){
      const copied=clone(notes),ids=new Set(notes.map(note=>note.id));
      return commit(()=>{clipboard=copied;state.notes=state.notes.filter(note=>!ids.has(note.id));selectCreated([]);state.exportScope="all";});
    }
    if(name==="duplicate"){
      if(state.notes.length+notes.length>MAX_NOTES)return false;
      const stats=statistics(notes),step=gridStep(),span=Math.max(.02,stats.end-stats.start);
      const offset=step?Math.max(step,Math.ceil((span-EPSILON)/step)*step):span;
      const added=copies(notes,offset);
      return commit(()=>{state.notes=state.notes.concat(added);selectCreated(added);});
    }
    if(name==="quantize"){
      const step=gridStep();if(!step)return false;
      const patches=notes.map(note=>({note,start:Math.max(0,Math.round(note.start/step)*step)}))
        .filter(patch=>Math.abs(patch.start-patch.note.start)>EPSILON);
      if(!patches.length)return false;
      return commit(()=>{for(const {note,start} of patches){const duration=note.end-note.start;note.start=start;note.end=start+duration;}});
    }
    if(name==="time")return move(notes,delta,0);
    if(name==="pitch")return move(notes,0,delta);
    if(name==="down"||name==="up")return move(notes,0,name==="down"?-1:1);
    return false;
  }
  function editVelocity(){
    if(!prepare())return update();
    const notes=selectedNotes(),value=velocity.value.trim()===""?NaN:Number(velocity.value);
    if(notes.length<=1||!Number.isFinite(value)||value<1||value>127)return update();
    // One integer delta preserves velocity differences until a MIDI boundary clamps them.
    const delta=Math.round(value-statistics(notes).mean);
    const patches=notes.map(note=>({note,value:clamp(note.velocity+delta,1,127)})).filter(patch=>patch.note.velocity!==patch.value);
    if(!patches.length)return update();
    commit(()=>{for(const patch of patches)patch.note.velocity=patch.value;});
  }
  const textControls='input,select,textarea,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="slider"],[role="spinbutton"],[role="separator"]';
  const arrowControls='button,summary,a[href],[role="button"],[role="tab"],[role="menuitem"],[role="radio"],[role="option"],[role="switch"],[role="checkbox"],[role="treeitem"],[role="toolbar"],[role="listbox"],[role="tree"],[role="grid"],[role="menu"],[role="menubar"],[role="tablist"],[role="radiogroup"],[role="scrollbar"]';
  function inside(target,selector){return !!target?.closest?.(selector)||!!target?.isContentEditable;}
  function keydown(event){
    if(event.defaultPrevented||event.isComposing||event.keyCode===229||!editable())return;
    if(inside(event.target,textControls)||inside(document.activeElement,textControls)||document.querySelector("details[open],dialog[open]"))return;
    const key=event.key.toLowerCase(),modifier=event.ctrlKey||event.metaKey;
    let applied=false;
    if(modifier&&!event.altKey){
      if(key==="a"&&event.shiftKey)applied=command("clear");
      else if(!event.shiftKey&&["c","x","v","d"].includes(key)){
        if(event.repeat)return;
        if((key==="c"||key==="x")&&window.getSelection()?.toString())return;
        applied=command({c:"copy",x:"cut",v:"paste",d:"duplicate"}[key]);
      }
    }else if(!modifier){
      if(key.startsWith("arrow")){
        if(inside(event.target,arrowControls)||inside(document.activeElement,arrowControls))return;
        if(key==="arrowleft"||key==="arrowright"){
          const step=(event.altKey ? .001 : (gridStep()||.01))*(event.shiftKey?10:1);
          applied=command("time",(key==="arrowleft"?-1:1)*step);
        }else if(!event.altKey&&(key==="arrowup"||key==="arrowdown"))applied=command("pitch",(key==="arrowup"?1:-1)*(event.shiftKey?12:1));
      }else if(!event.altKey&&key==="q")applied=command("quantize");
    }
    if(applied){event.preventDefault();event.stopPropagation();}
  }
  function positionMenu(){
    if(!menu?.open||!panel||!summary)return;
    const viewport=window.visualViewport,gap=8,left=viewport?.offsetLeft||0,top=viewport?.offsetTop||0;
    const width=viewport?.width||document.documentElement.clientWidth||window.innerWidth;
    const height=viewport?.height||document.documentElement.clientHeight||window.innerHeight;
    Object.assign(panel.style,{position:"fixed",right:"auto",bottom:"auto",margin:"0",minWidth:"0",boxSizing:"border-box",
      maxWidth:Math.max(1,width-gap*2)+"px",maxHeight:Math.max(1,height-gap*2)+"px",overflowY:"auto",overscrollBehavior:"contain"});
    const anchor=summary.getBoundingClientRect(),bounds=panel.getBoundingClientRect();
    const below=anchor.bottom+gap,above=anchor.top-gap-bounds.height;
    panel.style.left=clamp(anchor.right-bounds.width,left+gap,Math.max(left+gap,left+width-gap-bounds.width))+"px";
    panel.style.top=clamp(below+bounds.height<=top+height-gap?below:above>=top+gap?above:below,
      top+gap,Math.max(top+gap,top+height-gap-bounds.height))+"px";
  }
  function scheduleMenu(){
    if(!menu?.open||menuFrame)return;
    menuFrame=requestAnimationFrame(()=>{menuFrame=0;positionMenu();});
  }
  for(const [id,name] of buttons)element(id)?.addEventListener("click",()=>command(name));
  // A group's actual mean can be fractional even though every MIDI velocity is an integer.
  if(velocity)velocity.step="any";
  velocity?.addEventListener("change",editVelocity);velocity?.addEventListener("blur",update);
  element("editor-snap")?.addEventListener("change",update);element("bpm")?.addEventListener("input",update);
  menu?.addEventListener("toggle",()=>{if(menu.open){update();positionMenu();}});
  panel?.addEventListener("click",event=>{
    const button=event.target.closest?.("button");
    if(button&&!button.disabled){const focused=panel.contains(document.activeElement);menu.open=false;if(focused)summary?.focus({preventScroll:true});}
  },true); // Read enabled state before an action can disable its own button (cut/clear/bounds).
  window.addEventListener("resize",scheduleMenu);
  document.addEventListener("scroll",event=>{if(!panel?.contains(event.target))scheduleMenu();},true);
  window.visualViewport?.addEventListener("resize",scheduleMenu);window.visualViewport?.addEventListener("scroll",scheduleMenu);
  document.addEventListener("keydown",keydown,true);
  // Synchronous QA scope: test clipboard handlers without replacing the user's private clipboard.
  function withTemporaryClipboard(run){const saved=clipboard;clipboard=[];try{return run();}finally{clipboard=saved;update();}}
  window.LocalMidiCommands={update,withTemporaryClipboard};
  update();
})();
