"use strict";
// Rounded notes also work in the WebKit shipped with older macOS releases.
(function(root){
  function roundRect(path,x,y,width,height,radius){
    if(typeof path.roundRect==="function"){
      path.roundRect(x,y,width,height,radius);return path;
    }
    const r=Math.max(0,Math.min(radius,width/2,height/2));
    if(!r){path.rect(x,y,width,height);return path;}
    path.moveTo(x+r,y);path.lineTo(x+width-r,y);
    path.arcTo(x+width,y,x+width,y+r,r);path.lineTo(x+width,y+height-r);
    path.arcTo(x+width,y+height,x+width-r,y+height,r);path.lineTo(x+r,y+height);
    path.arcTo(x,y+height,x,y+height-r,r);path.lineTo(x,y+r);
    path.arcTo(x,y,x+r,y,r);path.closePath();return path;
  }
  const api={roundRect};root.MidiCanvasGeometry=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(typeof globalThis!=="undefined"?globalThis:this);
