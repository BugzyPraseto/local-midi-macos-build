"use strict";
// Presentation and gestures for the shared browser/JUCE workspace.
(() => {
  const compareScroll=$("comparison-scroll"), compareKeys=44;
  let takeKey="", sourceId=null, results=new Map(), rows=new Map(), fetchTicket=0;
  let gesture=null, velocityGesture=null, lassoMode=false, prepareTimer=null, fitted=true, tool="select";
  let pointer=null,pendingPointer=null,pendingVelocity=null,lastGestureFrame=0,rulerGesture=false,pendingSeek=null;
  let rendering=false, compareIndexKey="", cachedTakeKey="", compareIndex=new Map();
  function capturePointer(element,event){if(event.isTrusted)element.setPointerCapture(event.pointerId);}
  const colours={transkun:"#7ddff5",aria:"#a6c8ee",basic_pitch:"#8fb8d9",gaps:"#7ddff5",tsumugi:"#a6c8ee",reference:"#8ce1bb"};
  const labelWidth=()=>$("comparison-wave").previousElementSibling.getBoundingClientRect().width;
  const selectedCount=()=>state.selectedIds.size;

  // Cache only committed revisions; a cancelled preview must never reach another take.
  function cacheCurrentTake(){
    if(!state.result)return;
    const key=state.result.id+":"+state.editVersion;
    if(cachedTakeKey===key&&results.has(state.result.id))return;
    cachedTakeKey=key;
    results.set(state.result.id,{...state.result,notes:clone(state.notes)});
    compareIndexKey="";
  }

  function update(){
    cacheCurrentTake();
    $("active-take-name").textContent=state.result?takeName():"Choose a take";
    $("take-popover").querySelector("summary").title=state.result?takeName():"Choose a take or import reference MIDI";
    $("take-popover").querySelector("summary").setAttribute("aria-label",state.result?"Choose take. Selected "+takeName():"Choose take");
    $("note-count").textContent=state.loadingResult?"Loading take…":state.result?state.notes.length+" notes":"No take selected";
    $("restore").textContent=state.result?.backend==="reference"?"Restore imported MIDI":"Restore prediction";
    $("actions-undo").disabled=$("undo").disabled;$("actions-redo").disabled=$("redo").disabled;
    document.body.classList.toggle("has-note",!!state.selected);
    const primary=selectedNote();$("inspector-fields").firstElementChild.textContent=primary?(state.selectedIds.size>1?state.selectedIds.size+" selected · ":"")+pitchName(primary.pitch):"Note";
    const count=selectedCount(),selection=state.exportScope==="selection";
    if(!count&&selection)state.exportScope="all";
    const selected=state.exportScope==="selection";
    const option=$("export-scope").querySelector('[value="selection"]');
    option.disabled=!count;option.textContent="Selected notes ("+count+")";
    $("export-scope").value=state.exportScope;$("export-scope").disabled=!state.result;
    $("selection-origin").classList.toggle("hidden",!selected);
    $("clear-selection").disabled=!count;
    $("export-label").textContent=selected?"Export "+count+" notes":"Export .mid";
    $("drag-label").textContent=selected?"Drag "+count+" notes to host":"Drag MIDI to host";
    const ready=!!state.native&&!!state.result&&state.dragReady&&!state.loadingResult&&!state.dirty&&state.preparedDragRevision===dragRevision();
    $("drag-midi").disabled=!ready;
    $("drag-midi").classList.toggle("preparing",!!state.native&&!!state.result&&!ready);
    $("drag-detail").textContent=!state.native?"Use the standalone app or VST3":!state.result?"Choose a transcription take":!ready?"Preparing current MIDI…":selected?($("selection-origin").value==="start"?"Selection starts at first note":"Selection keeps source position"):takeName()+" · "+state.notes.length+" notes";
    $("drag-midi").title=ready?"Press and drag this MIDI file into a host track: "+midiFilename():$("drag-detail").textContent;
    $("transfer-info").textContent=state.result?takeName()+" · "+state.notes.length+" notes · "+(count?count+" selected":"performance MIDI"):"Your selected take becomes a MIDI file.";
    $("edit-selected").disabled=!state.result||state.loadingResult;
    const stage=state.result?"send":state.audio?"transcribe":"capture";
    const stages=["capture","transcribe","send"];
    document.querySelectorAll("[data-step]").forEach(el=>{el.classList.toggle("current",el.dataset.step===stage);el.classList.toggle("done",stages.indexOf(el.dataset.step)<stages.indexOf(stage));});
    const gpu=state.hardware?.cuda&&$("device").value!=="cpu";
    $("compute-label").textContent=state.hardware?(gpu?"GPU ready":"CPU mode"):"Local engine";
    $("compute-indicator").classList.toggle("cpu",!gpu);
    $("compute-indicator").title=state.hardware?(gpu?state.hardware.gpu_name+" · specialist models use CUDA; Basic Pitch uses CPU":"Processing on this computer"):"Connecting to the local engine";
    document.querySelectorAll("#takes .take-item").forEach(el=>{el.classList.toggle("active",el.dataset.jobId===state.result?.id);el.setAttribute("aria-pressed",String(el.dataset.jobId===state.result?.id));});
    for(const [id,row] of rows){const active=id===state.result?.id;row.classList.toggle("selected",active);row.querySelector(".take-selected").textContent=active?"Selected take":"";const playing=active&&state.playing&&state.listen!=="original";row.querySelector(".audition-button").textContent=playing?"Ⅱ Pause":"▶ Audition";row.querySelector(".audition-button").setAttribute("aria-pressed",String(playing));}
    $("comparison-selection").textContent=state.result?"Selected: "+takeName():"No take selected";
    updateViewReadouts();window.LocalMidiLayout?.update?.();window.LocalMidiOverlay?.update?.();window.LocalMidiCommands?.update();window.LocalMidiNavigation?.update();
  }

  async function refreshTakes(items){
    if(sourceId!==state.audio?.id){sourceId=state.audio?.id;takeKey="";cachedTakeKey="";results.clear();rows.clear();fetchTicket++;$("comparison-takes").replaceChildren();}
    const key=JSON.stringify(items.map(x=>[x.id,x.state,x.label,x.backend]));
    if(key!==takeKey){
      takeKey=key;const tabs=$("takes");tabs.replaceChildren();
      if(!items.length){const text=document.createElement("span");text.className="small muted";text.textContent="Your model results appear here.";tabs.append(text);}
      for(const item of items){
        const button=document.createElement("button");button.className="take-item";button.dataset.jobId=item.id;button.disabled=item.state!=="complete";
        const name=document.createElement("strong");name.textContent=item.label||modelName(item.backend);const detail=document.createElement("small");detail.textContent=item.state==="complete"?(item.device_used||"MIDI"):item.state;
        button.title=item.message||name.textContent;button.append(name,detail);button.onclick=async()=>{try{await loadResult(item.id);$("take-popover").open=false;}catch(e){notify(e.message);}};tabs.append(button);
      }
      const completed=items.filter(x=>x.state==="complete");$("compare-count").textContent=completed.length;
      $("comparison-empty").classList.toggle("hidden",completed.length>0);
      if(state.view==="compare")await fetchResults(completed);
    } else if(state.view==="compare"&&items.some(x=>x.state==="complete"&&!results.has(x.id)))await fetchResults(items.filter(x=>x.state==="complete"));
    update();
  }

  async function fetchResults(items){
    const ticket=++fetchTicket,source=state.audio?.id;
    const values=await Promise.all(items.map(async item=>[item,results.get(item.id)||await api('/api/jobs/'+item.id+'/result')]));
    if(ticket!==fetchTicket||source!==state.audio?.id)return;
    const order={transkun:0,aria:1,gaps:0,tsumugi:1,basic_pitch:2,reference:3};
    values.sort((a,b)=>(order[a[0].backend]??4)-(order[b[0].backend]??4));
    const ids=new Set(values.map(([item])=>item.id));for(const [id,row] of rows)if(!ids.has(id)){row.remove();rows.delete(id);results.delete(id);}
    for(const [item,loaded] of values){
      const result=results.get(item.id)||loaded;
      results.set(item.id,result);
      if(!rows.has(item.id)){
        const row=document.createElement("div");row.className="comparison-row";row.dataset.jobId=item.id;row.style.setProperty("--take-color",colours[item.backend]||"#7ddff5");
        const label=document.createElement("div");label.className="compare-label";
        const name=document.createElement("strong");name.textContent=item.label||modelName(item.backend);
        const meta=document.createElement("small");meta.className="take-meta";meta.textContent=result.notes.length+" notes · "+(item.device_used||"reference MIDI");
        const marker=document.createElement("span");marker.className="take-selected";
        const audition=document.createElement("button");audition.className="audition-button";audition.textContent="▶ Audition";audition.setAttribute("aria-label","Audition "+name.textContent);
        audition.onclick=e=>{e.stopPropagation();auditionTake(item.id).catch(error=>notify(error.message));};
        label.append(name,meta,audition,marker);label.onclick=()=>loadResult(item.id).catch(e=>notify(e.message));
        const canvas=document.createElement("canvas");canvas.className="comparison-roll";canvas.setAttribute("aria-label",name.textContent+" notes; click to seek");
        canvas.onclick=async e=>{try{const x=e.clientX-canvas.getBoundingClientRect().left;if(x<compareKeys)return;const t=(x-compareKeys+compareScroll.scrollLeft)/state.px;if(state.result?.id!==item.id)await loadResult(item.id);seek(t);}catch(error){notify(error.message);}};
        row.append(label,canvas);rows.set(item.id,row);
      }
      $("comparison-takes").append(rows.get(item.id));
    }
    $("comparison-source-name").textContent=state.audio?.name||"";update();drawComparison();
  }

  function notesFor(id){if(id===state.result?.id)return state.notes;if(state.native&&state.nativeEdits.has(id))return state.nativeEdits.get(id).notes;return results.get(id)?.notes||[];}
  function selectedIndex(){
    const key=state.result?.id+":"+state.editVersion;
    if(key!==compareIndexKey){compareIndexKey=key;compareIndex=new Map();for(const note of state.notes){if(!compareIndex.has(note.pitch))compareIndex.set(note.pitch,[]);compareIndex.get(note.pitch).push(note);}for(const notes of compareIndex.values())notes.sort((a,b)=>a.start-b.start);}
    return compareIndex;
  }
  function matches(note,index){
    const list=index.get(note.pitch)||[];let lo=0,hi=list.length;
    while(lo<hi){const mid=(lo+hi)>>1;if(list[mid].start<note.start-.05)lo=mid+1;else hi=mid;}
    for(let i=lo;i<list.length&&list[i].start<=note.start+.05;i++)if(Math.abs(list[i].end-note.end)<=.1)return true;
    return false;
  }

  function drawComparison(){requestVisual("compare");}
  function paintComparison(){
    if(state.view!=="compare"||!state.audio||rendering||compareScroll.clientWidth<1)return;
    rendering=true;
    try{
      const width=compareScroll.clientWidth,label=labelWidth(),canvasWidth=width-label;
      let duration=timelineDuration(),low=127,high=0;
      for(const id of rows.keys())for(const note of notesFor(id)){duration=Math.max(duration,note.end);low=Math.min(low,note.pitch);high=Math.max(high,note.pitch);}
      $("comparison-content").style.width=width+"px";
      $("comparison-spacer").style.width=Math.max(width,label+compareKeys+duration*state.px+20)+"px";
      const waveHeight=document.querySelector(".compare-wave-row").clientHeight;
      const scroll=compareScroll.scrollLeft,rowHeight=Math.max(110,(compareScroll.clientHeight-waveHeight)/Math.max(1,Math.min(3,rows.size)));
      if(low>high){low=48;high=84;}low=Math.max(0,low-2);high=Math.min(127,high+2);
      const waveCanvas=$("comparison-wave"),ctx=sizeCanvas(waveCanvas,canvasWidth,waveHeight);
      ctx.fillStyle="#15171a";ctx.fillRect(0,0,canvasWidth,waveHeight);ctx.save();ctx.beginPath();ctx.rect(compareKeys,0,canvasWidth-compareKeys,waveHeight);ctx.clip();
      const peaks=state.audio.peaks||[],max=Math.max(.001,...peaks);
      ctx.strokeStyle="#78d7f0";ctx.lineWidth=1;
      for(let x=compareKeys;x<canvasWidth;x+=2){const t=(x-compareKeys+scroll)/state.px;if(t<0||t>state.audio.duration)continue;const a=Math.floor(t/state.audio.duration*peaks.length),b=Math.max(a+1,Math.ceil((t+2/state.px)/state.audio.duration*peaks.length));let peak=0;for(let i=a;i<Math.min(b,peaks.length);i++)peak=Math.max(peak,peaks[i]);const amp=peak/max*17;ctx.beginPath();ctx.moveTo(x,21-amp);ctx.lineTo(x,21+amp);ctx.stroke();}
      ctx.restore();
      ctx.save();ctx.translate(0,waveHeight-RULER);drawRuler(ctx,canvasWidth,scroll,compareKeys,RULER);ctx.restore();
      const differences=$("show-differences").checked,index=differences?selectedIndex():null;
      for(const [id,row] of rows){
        row.style.height=rowHeight+"px";row.querySelector(".compare-label").style.width=(label-2)+"px";
        const canvas=row.querySelector("canvas"),height=Math.floor(rowHeight-1),c=sizeCanvas(canvas,canvasWidth,height),pitchHeight=height/(high-low+1);
        c.fillStyle="#15171a";c.fillRect(0,0,canvasWidth,height);
        for(let pitch=low;pitch<=high;pitch++){const y=(high-pitch)*pitchHeight;c.fillStyle=isBlack(pitch)?"#101214":"#15171a";c.fillRect(compareKeys,y,canvasWidth-compareKeys,pitchHeight);c.fillStyle=isBlack(pitch)?"#25292f":"#d8dce2";c.fillRect(1,y+1,isBlack(pitch)?28:compareKeys-3,Math.max(1,pitchHeight-1));if(pitch%12===0&&pitchHeight>=13){c.fillStyle="#39424e";c.font="11px 'Inter',sans-serif";c.fillText(pitchName(pitch),3,y+pitchHeight-2);}}
        c.save();c.beginPath();c.rect(compareKeys,0,canvasWidth-compareKeys,height);c.clip();
        for(const tick of timelineGrid(canvasWidth,scroll,compareKeys).ticks){c.strokeStyle=tick.major?"#434953":"#2a2e34";c.beginPath();c.moveTo(tick.x,0);c.lineTo(tick.x,height);c.stroke();}
        const paths=[new Path2D(),new Path2D()];for(const note of notesFor(id)){const x=compareKeys+note.start*state.px-scroll,w=Math.max(2,(note.end-note.start)*state.px);if(x+w<compareKeys||x>canvasWidth)continue;const matched=differences&&id!==state.result?.id&&matches(note,index);paths[matched?1:0].rect(x,(high-note.pitch)*pitchHeight+1,w,Math.max(2,pitchHeight-1));}c.fillStyle=colours[results.get(id)?.backend]||"#7ddff5";c.globalAlpha=.85;c.fill(paths[0]);c.globalAlpha=.2;c.fill(paths[1]);
        c.globalAlpha=1;c.restore();
        const take=results.get(id),compute=take?.backend==="reference"?"reference MIDI":take?.metadata?.device||"take";
        row.querySelector(".take-meta").textContent=notesFor(id).length+" notes · "+compute;
      }
    } finally {rendering=false;}
  }

  async function auditionTake(id){
    if(state.result?.id===id&&state.playing&&state.listen==="midi"){pause();update();return;}
    const at=playbackTime();if(state.result?.id!==id)await loadResult(id);
    if(state.result?.id!==id)return;
    seek(at);await document.querySelector('[data-listen="midi"]').onclick();if(!state.playing)await play();update();
  }
  function fitTimeline(){
    fitted=true;const width=state.view==="compare"?compareScroll.clientWidth-labelWidth()-compareKeys-20:$("roll-scroll").clientWidth-KEYS-20;
    if(width>0&&state.audio){state.px=Math.max(.1,Math.min(160,width/timelineDuration()));$("zoom").value=state.px;$("roll-scroll").scrollLeft=0;compareScroll.scrollLeft=0;resizeRoll();drawComparison();}
  }
  function setRowHeight(value){
    cancelPendingGesture();
    const scroller=$("roll-scroll"),center=(scroller.scrollTop+scroller.clientHeight/2)/ROW;
    ROW=clamp(Math.round(Number(value)||18),10,28);
    if($("row-height"))$("row-height").value=ROW;
    resizeRoll();scroller.scrollTop=Math.max(0,center*ROW-scroller.clientHeight/2);drawRoll();
  }
  function fitNotes(){
    if(!state.result||state.view!=="edit")return;
    cancelPendingGesture();
    const selected=state.notes.filter(note=>state.selectedIds.has(note.id)),notes=selected.length?selected:state.notes;
    if(!notes.length)return;
    const scroller=$("roll-scroll"),width=scroller.clientWidth-KEYS,height=scroller.clientHeight;
    if(width<=0||height<=0)return;
    let start=Infinity,end=0,low=127,high=0;
    for(const note of notes){start=Math.min(start,note.start);end=Math.max(end,note.end);low=Math.min(low,note.pitch);high=Math.max(high,note.pitch);}
    const margin=Math.max(.08,(end-start)*.08),left=Math.max(0,start-margin),right=end+margin;
    fitted=false;state.px=clamp(Math.max(1,width-24)/Math.max(.02,right-left),.1,160);
    ROW=clamp(Math.floor(height/(high-low+5)),10,28);
    $("zoom").value=state.px;if($("row-height"))$("row-height").value=ROW;
    resizeRoll();
    scroller.scrollLeft=Math.max(0,left*state.px-12);
    scroller.scrollTop=Math.max(0,(HIGH-(low+high)/2+.5)*ROW-height/2);
    drawRoll();drawComparison();requestFrame();publishNativeUi();
  }
  function setView(view){
    cancelPendingGesture();
    const scroll=state.view==="compare"?compareScroll.scrollLeft:$("roll-scroll").scrollLeft;
    state.view=view==="compare"?"compare":"edit";const compare=state.view==="compare";
    document.body.classList.toggle("is-comparing",compare);$("editor-view").classList.toggle("hidden",compare);$("comparison").classList.toggle("hidden",!compare);
    $("difference-control").classList.toggle("hidden",!compare);$("edit-selected").classList.toggle("hidden",!compare);
    for(const value of ["edit","compare"]){$("view-"+value).classList.toggle("active",state.view===value);$("view-"+value).setAttribute("aria-pressed",String(state.view===value));}
    if(compare)fetchResults(state.jobs.filter(x=>x.state==="complete")).catch(e=>notify(e.message));
    resizeRoll();if(fitted)fitTimeline();else{compareScroll.scrollLeft=scroll;$("roll-scroll").scrollLeft=scroll;drawComparison();}
    drawWave();update();publishNativeUi();
  }

  function prepareSoon(){
    clearTimeout(prepareTimer);
    if(gesture||velocityGesture){state.dragReady=false;update();return;}
    if(state.native&&state.result&&!state.dirty&&!state.loadingResult&&state.preparedDragRevision===dragRevision()){
      state.dragReady=true;update();return;
    }
    state.dragReady=false;update();
    if(state.native&&state.result&&!state.loadingResult)prepareTimer=setTimeout(async()=>{
      if(gesture||velocityGesture)return;
      try{await persistNotes();if(gesture||velocityGesture)return;if(state.preparedDragRevision!==dragRevision())await syncNativeTake();else{state.dragReady=true;update();}}catch(error){notify(error.message);}
    },100);
  }
  function selectionChanged(prepare=true){
    cacheCurrentTake();
    const ids=new Set(state.notes.map(note=>note.id));state.selectedIds=new Set([...state.selectedIds].filter(id=>ids.has(id)));
    if(!state.selectedIds.has(state.selected))state.selected=[...state.selectedIds][0]||null;
    if(!state.selectedIds.size)state.exportScope="all";
    updateInspector();update();drawRoll();if(prepare){prepareSoon();publishNativeUi();}
  }
  function setSelection(ids,exportSelection=false,prepare=true){
    const next=new Set(ids),same=next.size===state.selectedIds.size&&[...next].every(id=>state.selectedIds.has(id));
    const scope=exportSelection&&next.size?"selection":next.size?state.exportScope:"all";
    if(same&&scope===state.exportScope)return;
    state.selectedIds=next;state.selected=next.has(state.selected)?state.selected:[...next][0]||null;state.exportScope=scope;
    updateInspector();update();drawRoll();if(prepare){prepareSoon();publishNativeUi();}
  }
  function polygonFor(g){
    if(g.freehand)return g.points;
    const a=g.points[0],b=g.points[g.points.length-1];return [a,{x:b.x,y:a.y},b,{x:a.x,y:b.y}];
  }
  function drawLasso(context,scroll,top=0){
    if(gesture?.kind!=="lasso"||!gesture.moved)return;
    const points=polygonFor(gesture);if(points.length<2)return;
    context.beginPath();context.moveTo(points[0].x-scroll,points[0].y-top);for(let i=1;i<points.length;i++)context.lineTo(points[i].x-scroll,points[i].y-top);context.closePath();
    context.fillStyle="#7ddff522";context.fill();context.strokeStyle="#b1eafa";context.lineWidth=1;context.setLineDash([4,3]);context.stroke();context.setLineDash([]);
  }
  const point=e=>{const p=position(e);return {x:p.x+$("roll-scroll").scrollLeft,y:p.y};};
  const pointerState=e=>({clientX:e.clientX,clientY:e.clientY,altKey:!!e.altKey});
  const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
  function gridStep(){
    const division=Number($("editor-snap")?.value);
    return [8,16,32].includes(division)?240/clamp(Number($("bpm").value)||120,20,400)/division:0;
  }
  function snapTime(time,event){
    const step=event.altKey?0:gridStep();
    return Math.max(0,step?Math.round(time/step)*step:time);
  }
  function updateHint(){
    const hint=$("editor-hint");if(!hint)return;
    const description=tool==="draw"?"Click or drag to draw a note":tool==="erase"?"Click a note to erase":lassoMode?"Drag a freehand selection":"Drag to select · double-click to add · drag either edge to resize";
    hint.textContent=description+(gridStep()?" · Alt bypasses grid":"")+" · Esc cancels · H fits notes";
  }
  function setTool(value){
    cancelPendingGesture();tool=value;lassoMode=false;
    for(const name of ["select","draw","erase"]){const button=$("tool-"+name);if(button){button.classList.toggle("active",tool===name);button.setAttribute("aria-pressed",String(tool===name));}}
    $("lasso-mode").classList.remove("active");$("lasso-mode").setAttribute("aria-pressed","false");
    roll.style.cursor=tool==="erase"?"not-allowed":tool==="draw"?"crosshair":"default";updateHint();
  }
  function beginGesture(kind,event){
    clearTimeout(prepareTimer);clearTimeout(state.saveTimer);
    return {kind,pointerId:event.pointerId,resultId:state.result.id,before:null,
      selection:{ids:new Set(state.selectedIds),primary:state.selected,scope:state.exportScope},dragReady:state.dragReady};
  }
  function beforeGestureEdit(g){
    if(!g.before){g.before=clone(state.notes);state.dragReady=false;update();}
  }
  function resumePendingSave(){
    if(state.dirty){clearTimeout(state.saveTimer);state.saveTimer=setTimeout(()=>persistNotes().catch(error=>notify(error.message)),500);}
  }
  function gestureEdited(g){
    if(!g.before)return false;
    if(g.kind==="draw")return true;
    return g.nodes.some((note,i)=>g.kind==="velocity"?note.velocity!==g.original[i].velocity:
      note.start!==g.original[i].start||note.end!==g.original[i].end||note.pitch!==g.original[i].pitch);
  }
  function commitGesture(g){
    if(g.resultId!==state.result?.id)return;
    if(gestureEdited(g)){
      // checkpoint owns the shared history policy, but must see the pre-gesture notes.
      const edited=state.notes;state.notes=g.before;checkpoint();state.notes=edited;changed();
    }else{state.dragReady=g.dragReady;resumePendingSave();}
    selectionChanged();drawRoll();
  }
  function cancelPendingGesture(){
    const g=gesture||velocityGesture;if(!g)return false;
    gesture=null;velocityGesture=null;pointer=null;pendingPointer=null;pendingVelocity=null;lastGestureFrame=0;
    if(g.resultId===state.result?.id){
      if(g.before)state.notes=g.before;
      state.selectedIds=new Set(g.selection.ids);state.selected=g.selection.primary;state.exportScope=g.selection.scope;
      compareIndexKey="";state.dragReady=g.dragReady;selectionChanged(false);setEnabled();resumePendingSave();
      if(state.native&&!state.dragReady)prepareSoon();
    }
    drawRoll();return true;
  }
  function resizeEdge(rect,x){
    const threshold=Math.min(6,rect.w/3);
    if(rect.w>=18&&x<=rect.x+threshold)return "left";
    return rect.w>=8&&x>=rect.x+rect.w-threshold?"right":null;
  }
  function moveGesture(event){
    if(!gesture)return;
    if(gesture.resultId!==state.result?.id){cancelPendingGesture();return;}
    const p=point(event);
    if(gesture.kind==="lasso"){
      const last=gesture.points[gesture.points.length-1];if(Math.hypot(p.x-last.x,p.y-last.y)<2)return;
      if(gesture.freehand)gesture.points.push(p);else gesture.points[1]=p;
      gesture.moved=true;
      const chosen=MidiSelection.select(state.notes,polygonFor(gesture),{px:state.px,row:ROW,high:HIGH,keys:KEYS,ruler:0});
      setSelection([...gesture.base,...chosen],true,false);state.dragReady=false;drawRoll();
    }else if(gesture.kind==="draw"){
      if(!gesture.moved&&Math.abs(p.x-gesture.x)<2)return;
      gesture.moved=true;
      const at=snapTime((p.x-KEYS)/state.px,event),note=gesture.note;
      note.start=Math.min(gesture.anchor,at);note.end=Math.max(note.start+.02,gesture.anchor,at);
      updateInspector();drawRoll();
    }else{
      if(!gesture.moved){if(Math.abs(p.x-gesture.x)+Math.abs(p.y-gesture.y)<2)return;gesture.moved=true;}
      const rawDelta=(p.x-gesture.x)/state.px,anchor=gesture.anchor;
      let delta=Math.abs(p.x-gesture.x)<2?0:snapTime((gesture.resize==="right"?anchor.end:anchor.start)+rawDelta,event)-(gesture.resize==="right"?anchor.end:anchor.start);
      const pitchDelta=Math.max(-gesture.low,Math.min(127-gesture.high,-Math.round((p.y-gesture.y)/ROW)));
      if(gesture.resize==="right")delta=Math.max(delta,gesture.minimumResize);
      else if(gesture.resize==="left")delta=clamp(delta,-gesture.start,gesture.maximumResize);
      else delta=Math.max(delta,-gesture.start);
      const differs=gesture.nodes.some((note,i)=>{
        const original=gesture.original[i];
        return gesture.resize==="right"?note.end!==original.end+delta:gesture.resize==="left"?note.start!==original.start+delta:
          note.start!==original.start+delta||note.end!==original.end+delta||note.pitch!==original.pitch+pitchDelta;
      });
      if(!differs)return;
      beforeGestureEdit(gesture);
      for(let i=0;i<gesture.nodes.length;i++){
        const note=gesture.nodes[i],original=gesture.original[i];
        if(gesture.resize==="right")note.end=original.end+delta;
        else if(gesture.resize==="left")note.start=original.start+delta;
        else{note.start=original.start+delta;note.end=original.end+delta;note.pitch=original.pitch+pitchDelta;}
      }
      updateInspector();drawRoll();
    }
  }
  function edgeSpeed(value,min,max){const margin=28;if(value<min+margin)return -Math.min(1,(min+margin-value)/margin)*850;if(value>max-margin)return Math.min(1,(value-max+margin)/margin)*850;return 0;}
  function advanceGesture(timestamp){
    if(pendingSeek!==null){const time=pendingSeek;pendingSeek=null;seek(time);}
    if(pendingVelocity){const event=pendingVelocity;pendingVelocity=null;moveVelocity(event);}
    if(!gesture){lastGestureFrame=0;return rulerGesture||!!velocityGesture;}
    const dt=lastGestureFrame?Math.min(.05,(timestamp-lastGestureFrame)/1000):1/60;lastGestureFrame=timestamp;
    let scrolled=false;
    if(pointer&&gesture.moved){
      const scroller=$("roll-scroll"),bounds=scroller.getBoundingClientRect(),left=scroller.scrollLeft,top=scroller.scrollTop;
      scroller.scrollLeft+=edgeSpeed(pointer.clientX,bounds.left+KEYS,bounds.right-10)*dt;
      scroller.scrollTop+=edgeSpeed(pointer.clientY,bounds.top,bounds.bottom-10)*dt;
      scrolled=scroller.scrollLeft!==left||scroller.scrollTop!==top;
    }
    if(pendingPointer||scrolled){moveGesture(pendingPointer||pointer);pendingPointer=null;}
    return true;
  }
  function finishGesture(event){
    if(!gesture||event&&event.pointerId!==gesture.pointerId)return;
    if(pendingPointer){moveGesture(pendingPointer);pendingPointer=null;}
    if(!gesture)return;
    const g=gesture;gesture=null;pointer=null;lastGestureFrame=0;
    if(g.kind==="lasso"){if(!g.moved&&!g.add)setSelection([]);else selectionChanged();resumePendingSave();}else commitGesture(g);
    drawRoll();
  }
  roll.addEventListener("pointerdown",event=>{
    if(event.button!==0||!state.result||state.loadingResult)return;
    const p=position(event);if(p.x<KEYS)return;
    event.preventDefault();roll.focus({preventScroll:true});cancelPendingGesture();
    const note=lassoMode?null:hitTest(p.x,p.y),add=event.shiftKey||event.ctrlKey||event.metaKey;
    if(tool==="erase"){
      if(note){pause();checkpoint();state.notes=state.notes.filter(n=>n.id!==note.id);state.selectedIds.delete(note.id);changed();selectionChanged();}
      return;
    }
    if(tool==="draw"){
      pause();const at=point(event),start=snapTime((at.x-KEYS)/state.px,event);
      gesture={...beginGesture("draw",event),x:at.x,anchor:start,moved:false};
      beforeGestureEdit(gesture);
      const created={id:crypto.randomUUID(),start,end:start+(gridStep()&&!event.altKey?gridStep():.35),pitch:clamp(HIGH-Math.floor(p.y/ROW),0,127),velocity:80,track:0,program:previewInstrument()==="guitar"?24:0,is_drum:false};
      gesture.note=created;state.notes.push(created);setSelection([created.id],false,false);
    }
    else if(!note){gesture={...beginGesture("lasso",event),points:[point(event)],base:new Set(add?state.selectedIds:[]),freehand:lassoMode,add,moved:false};if(!add)setSelection([],false,false);}
    else{
      pause();
      if(add){const ids=new Set(state.selectedIds);ids.has(note.id)?ids.delete(note.id):ids.add(note.id);setSelection(ids,true);return;}
      const transaction=beginGesture("notes",event);
      if(!state.selectedIds.has(note.id))setSelection([note.id],false,false);state.selected=note.id;updateInspector();
      const r=noteRect(note),nodes=state.notes.filter(n=>state.selectedIds.has(n.id)),at=point(event);
      gesture={...transaction,x:at.x,y:at.y,resize:resizeEdge(r,p.x),anchor:{...note},nodes,original:nodes.map(n=>({...n})),low:Math.min(...nodes.map(n=>n.pitch)),high:Math.max(...nodes.map(n=>n.pitch)),start:Math.min(...nodes.map(n=>n.start)),minimumResize:Math.max(...nodes.map(n=>n.start+.02-n.end)),maximumResize:Math.min(...nodes.map(n=>n.end-.02-n.start)),moved:false};
    }
    pointer=pointerState(event);capturePointer(roll,event);drawRoll();requestFrame();
  });
  roll.addEventListener("pointermove",event=>{
    if(!gesture){const p=position(event),note=hitTest(p.x,p.y),r=note?noteRect(note):null;const cursor=tool==="erase"?"not-allowed":tool==="draw"||lassoMode?"crosshair":note?(resizeEdge(r,p.x)?"ew-resize":"grab"):"crosshair";if(roll.style.cursor!==cursor)roll.style.cursor=cursor;return;}
    if(event.pointerId!==gesture.pointerId)return;
    pointer=pendingPointer=pointerState(event);requestFrame();
  });
  roll.addEventListener("pointerup",finishGesture);
  for(const type of ["pointercancel","lostpointercapture"])roll.addEventListener(type,event=>{if(gesture&&event.pointerId===gesture.pointerId)cancelPendingGesture();});
  roll.addEventListener("dblclick",event=>{
    if(!state.result||state.loadingResult||lassoMode||tool!=="select")return;const p=position(event);if(p.x<KEYS)return;
    pause();checkpoint();const start=snapTime((p.x+$("roll-scroll").scrollLeft-KEYS)/state.px,event),pitch=clamp(HIGH-Math.floor(p.y/ROW),0,127);
    const note={id:crypto.randomUUID(),start,end:start+(gridStep()&&!event.altKey?gridStep():.35),pitch,velocity:80,track:0,program:previewInstrument()==="guitar"?24:0,is_drum:false};state.notes.push(note);setSelection([note.id],false,false);changed();selectionChanged();
  });

  function setVelocityHeight(){
    if(window.LocalMidiLayout?.apply){window.LocalMidiLayout.apply();return;}
    const height=document.body.classList.contains("comfortable-density")&&!state.fullView?80:64;
    $("velocity-lane").style.height=height+"px";
  }
  function updateViewReadouts(){
    if($("view-zoom-value"))$("view-zoom-value").textContent=Number(state.px.toFixed(1))+" px/s";
    if($("view-row-value"))$("view-row-value").textContent=ROW+" px";
  }
  function drawVelocity(){
    if(state.view!=="edit"||!$("velocity-lane").clientWidth)return;
    const canvas=$("velocity-lane"),w=canvas.parentElement.clientWidth,h=Math.round(canvas.getBoundingClientRect().height)||64,c=sizeCanvas(canvas,w,h),scroll=$("roll-scroll").scrollLeft;
    c.globalAlpha=1;c.lineWidth=1;c.fillStyle="#15171a";c.fillRect(0,0,w,h);c.fillStyle="#9ba1ac";c.font="11px 'Inter',sans-serif";
    const primary=selectedNote();c.fillText(h<48&&primary?"Vel "+primary.velocity:"Vel",6,16);
    if(primary&&h>=48){c.fillStyle="#fff0c2";c.fillText(String(primary.velocity),6,34);}
    c.fillStyle="#9ba1ac";c.textAlign="right";c.fillText("127",KEYS-6,13);if(h>=48)c.fillText("64",KEYS-6,h-5-64/127*(h-18)+3);c.fillText("1",KEYS-6,h-4);c.textAlign="left";
    c.save();c.beginPath();c.rect(KEYS,0,w-KEYS,h);c.clip();
    c.strokeStyle="#30353d";c.setLineDash([2,4]);
    for(const value of [32,64,96,127]){const y=h-5-value/127*(h-18);c.beginPath();c.moveTo(KEYS,y+.5);c.lineTo(w,y+.5);c.stroke();}
    c.setLineDash([]);
    const paths=[new Path2D(),new Path2D()],caps=[new Path2D(),new Path2D()];
    for(const note of state.notes){const x=KEYS+note.start*state.px-scroll;if(x<KEYS||x>w)continue;const y=h-5-note.velocity/127*(h-18),selected=state.selectedIds.has(note.id)?1:0;paths[selected].moveTo(x,h-5);paths[selected].lineTo(x,y);caps[selected].rect(x-2,y-1,4,3);}
    for(let i=0;i<2;i++){c.strokeStyle=c.fillStyle=i?"#fff0c2":"#7ddff5";c.globalAlpha=i?1:.75;c.stroke(paths[i]);c.fill(caps[i]);}
    c.restore();
  }
  const velocity=$("velocity-lane");
  velocity.addEventListener("pointerdown",event=>{
    if(event.button!==0||!state.result||state.loadingResult||velocity.hidden||velocity.clientHeight<=18)return;const rect=velocity.getBoundingClientRect(),x=event.clientX-rect.left,y=event.clientY-rect.top;let closest=null,distance=Infinity;
    if(x<KEYS)return;
    const h=velocity.logicalHeight||velocity.clientHeight;for(const note of state.notes){const nx=KEYS+note.start*state.px-$("roll-scroll").scrollLeft,ny=h-5-note.velocity/127*(h-18);if(nx>=KEYS&&nx<=rect.width&&Math.abs(nx-x)<=5){const d=Math.abs(ny-y)+(state.selectedIds.has(note.id)?0:.5);if(d<distance){closest=note;distance=d;}}}
    if(!closest)return;event.preventDefault();roll.focus({preventScroll:true});cancelPendingGesture();pause();const transaction=beginGesture("velocity",event);
    if(!state.selectedIds.has(closest.id))setSelection([closest.id],false,false);state.selected=closest.id;
    const nodes=state.notes.filter(n=>state.selectedIds.has(n.id));
    velocityGesture={...transaction,note:closest,nodes,original:nodes.map(n=>({...n})),base:closest.velocity};capturePointer(velocity,event);updateInspector();drawRoll();
  });
  function moveVelocity(event){
    if(!velocityGesture)return;
    if(velocityGesture.resultId!==state.result?.id||velocity.hidden||velocity.clientHeight<=18){cancelPendingGesture();return;}
    const h=velocity.logicalHeight||velocity.clientHeight,y=event.clientY-velocity.getBoundingClientRect().top,v=clamp(Math.round((h-5-y)/Math.max(1,h-18)*127),1,127);
    if(v===velocityGesture.note.velocity)return;
    beforeGestureEdit(velocityGesture);
    velocityGesture.nodes.forEach((note,i)=>{note.velocity=clamp(velocityGesture.original[i].velocity+v-velocityGesture.base,1,127);});updateInspector();drawRoll();
  }
  velocity.addEventListener("pointermove",event=>{if(velocityGesture&&event.pointerId===velocityGesture.pointerId){pendingVelocity=pointerState(event);requestFrame();}});
  function endVelocity(event){
    if(!velocityGesture||event.pointerId!==velocityGesture.pointerId)return;
    if(pendingVelocity){moveVelocity(pendingVelocity);pendingVelocity=null;}
    if(!velocityGesture)return;
    const g=velocityGesture;velocityGesture=null;commitGesture(g);
  }
  velocity.addEventListener("pointerup",endVelocity);
  for(const type of ["pointercancel","lostpointercapture"])velocity.addEventListener(type,event=>{if(velocityGesture&&event.pointerId===velocityGesture.pointerId)cancelPendingGesture();});

  let dragPress=null;
  $("drag-midi").addEventListener("pointerdown",event=>{if(event.button!==0||$("drag-midi").disabled)return;event.preventDefault();dragPress={x:event.clientX,y:event.clientY,revision:state.preparedDragRevision};capturePointer($("drag-midi"),event);});
  $("drag-midi").addEventListener("pointermove",async event=>{
    if(!dragPress||Math.hypot(event.clientX-dragPress.x,event.clientY-dragPress.y)<5)return;
    const press=dragPress;dragPress=null;
    try{if(!state.dragReady||dragRevision()!==press.revision)throw Error("MIDI changed. Wait for preparation, then drag again.");await state.native("drag",{revision:press.revision});}catch(error){notify(error.message);}
  });
  for(const name of ["pointerup","pointercancel"])$("drag-midi").addEventListener(name,()=>{dragPress=null;});
  $("drag-midi").onclick=()=>{if(!$("drag-midi").disabled)notify("Press, hold, and drag into a MIDI or instrument track in your host.");};
  $("drag-midi").ondragstart=event=>event.preventDefault();
  function updateFollow(){
    const button=$("follow-playhead");button.classList.toggle("active",state.follow&&!state.followSuspended);button.classList.toggle("suspended",state.follow&&state.followSuspended);button.setAttribute("aria-pressed",String(state.follow&&!state.followSuspended));
    button.textContent=state.followSuspended&&state.follow?"Resume":"Follow";
    button.title=state.followSuspended?"Resume following playback (A)":"Follow playback (A). Manual horizontal scrolling suspends following.";
  }
  $("follow-playhead").onclick=()=>{state.follow=state.followSuspended?true:!state.follow;state.followSuspended=false;updateFollow();if(state.follow)followPlayback(playbackTime(),true);requestFrame();publishNativeUi();};
  $("follow-mode").onchange=()=>{state.followMode=$("follow-mode").value;state.followSuspended=false;updateFollow();requestFrame();publishNativeUi();};
  $("ruler-mode").onchange=()=>{state.rulerMode=$("ruler-mode").value;drawRoll();drawComparison();publishNativeUi();};
  $("bpm").addEventListener("input",()=>{drawRoll();drawComparison();});
  for(const name of ["select","draw","erase"])if($("tool-"+name))$("tool-"+name).onclick=()=>setTool(name);
  if($("editor-snap"))$("editor-snap").onchange=()=>{updateHint();publishNativeUi();};
  if($("row-height"))$("row-height").oninput=()=>{setRowHeight($("row-height").value);publishNativeUi();};
  if($("fit-notes"))$("fit-notes").onclick=fitNotes;
  function horizontalWheel(event){
    const zoom=event.ctrlKey||event.metaKey;
    if(!zoom&&!event.shiftKey)return;
    const scroller=$("roll-scroll");if(state.view!=="edit")return;
    event.preventDefault();
    if(gesture||velocityGesture)return;
    if(zoom){
      const rect=roll.getBoundingClientRect(),x=clamp(event.clientX-rect.left,KEYS,rect.width);
      const anchor=(scroller.scrollLeft+x-KEYS)/state.px;
      const delta=event.deltaY||event.deltaX,units=event.deltaMode===1?16:event.deltaMode===2?scroller.clientWidth:1;
      fitted=false;state.px=clamp(state.px*Math.exp(clamp(-delta*units*.002,-1,1)),.1,160);
      $("zoom").value=state.px;resizeRoll();
      scroller.scrollLeft=Math.max(0,anchor*state.px-x+KEYS);
      publishNativeUi();
    }else{
      const delta=Math.abs(event.deltaX)>Math.abs(event.deltaY)?event.deltaX:event.deltaY;
      scroller.scrollLeft+=delta*(event.deltaMode===1?16:event.deltaMode===2?scroller.clientWidth:1);
    }
    drawRoll();requestFrame();
  }
  $("roll-scroll").addEventListener("wheel",horizontalWheel,{passive:false});
  $("roll-ruler").addEventListener("wheel",horizontalWheel,{passive:false});
  for(const element of [$("roll-scroll"),compareScroll]){
    let previous=element.scrollLeft;
    element.addEventListener("scroll",()=>{
      const left=element.scrollLeft;
      if(state.playing&&Math.abs(left-previous)>.5&&Math.abs(left-(element.followTarget??-1e9))>2){state.followSuspended=true;updateFollow();}
      element.followTarget=null;previous=left;
    });
  }
  const ruler=$("roll-ruler");
  function rulerSeek(event){const x=event.clientX-ruler.getBoundingClientRect().left;if(x>=KEYS)pendingSeek=(x+$("roll-scroll").scrollLeft-KEYS)/state.px;requestFrame();}
  ruler.addEventListener("pointerdown",event=>{if(event.button!==0||!state.audio)return;event.preventDefault();rulerGesture=true;capturePointer(ruler,event);rulerSeek(event);});
  ruler.addEventListener("pointermove",event=>{if(rulerGesture)rulerSeek(event);});
  for(const name of ["pointerup","pointercancel"])ruler.addEventListener(name,()=>{if(pendingSeek!==null){seek(pendingSeek);pendingSeek=null;}rulerGesture=false;});
  $("view-edit").onclick=()=>setView("edit");$("view-compare").onclick=()=>setView("compare");$("edit-selected").onclick=()=>setView("edit");
  function fullView(enabled){
    cancelPendingGesture();
    state.fullView=!!enabled;document.body.classList.toggle("focus-roll",state.fullView);
    setVelocityHeight();
    $("focus-roll").textContent=state.fullView?"⤡ Exit full view":"⤢ Full view";$("focus-roll").classList.toggle("active",state.fullView);$("focus-roll").setAttribute("aria-pressed",String(state.fullView));
    for(const popover of document.querySelectorAll("details[open]"))popover.open=false;
    if(fitted)fitTimeline();else{resizeRoll();drawComparison();}publishNativeUi();
  }
  $("focus-roll").onclick=()=>fullView(!state.fullView);
  $("ui-density").onchange=()=>{document.body.classList.toggle("comfortable-density",$("ui-density").value==="comfortable");setVelocityHeight();resizeRoll();drawComparison();drawWave();publishNativeUi();};
  $("fit-timeline").onclick=()=>{fitTimeline();publishNativeUi();};$("zoom").addEventListener("input",()=>{fitted=false;});
  compareScroll.onscroll=()=>{drawComparison();requestFrame();};
  $("comparison-wave").onclick=event=>{if(!state.audio)return;const x=event.clientX-$("comparison-wave").getBoundingClientRect().left;if(x>=compareKeys)seek((x-compareKeys+compareScroll.scrollLeft)/state.px);};
  $("show-differences").onchange=()=>{$("difference-caption").textContent=$("show-differences").checked?"Unmatched notes highlighted · ±50 ms onset / ±100 ms release":"Same timeline · one take at a time · click a lane to seek";drawComparison();publishNativeUi();};
  $("export-scope").onchange=()=>{state.exportScope=$("export-scope").value;prepareSoon();publishNativeUi();};
  $("clear-selection").onclick=()=>setSelection([]);
  $("lasso-mode").onclick=()=>{const enabled=tool!=="select"||!lassoMode;setTool("select");lassoMode=enabled;$("lasso-mode").classList.toggle("active",lassoMode);$("lasso-mode").setAttribute("aria-pressed",String(lassoMode));updateHint();};
  if($("toggle-source"))$("toggle-source").onclick=()=>{
    const collapsed=document.body.classList.toggle("source-collapsed"),button=$("toggle-source");
    button.setAttribute("aria-expanded",String(!collapsed));button.title=collapsed?"Show source controls":"Hide source controls";
    requestAnimationFrame(()=>{resizeRoll();drawWave();drawComparison();});publishNativeUi();
  };
  $("device").onchange=()=>{update();publishNativeUi();};
  function positionTakeMenu(){
    const menu=$("take-popover");if(!menu.open)return;const panel=menu.querySelector(".take-panel"),anchor=menu.querySelector("summary").getBoundingClientRect();
    panel.style.position="fixed";panel.style.maxHeight=Math.max(100,Math.min(380,innerHeight-24))+"px";
    const bounds=panel.getBoundingClientRect();panel.style.left=Math.max(12,Math.min(anchor.left,innerWidth-bounds.width-12))+"px";
    panel.style.top=Math.max(12,Math.min(anchor.bottom+6,innerHeight-bounds.height-12))+"px";
  }
  $("take-popover").addEventListener("toggle",()=>{if($("take-popover").open)requestAnimationFrame(positionTakeMenu);});
  new ResizeObserver(positionTakeMenu).observe($("take-popover").querySelector(".take-panel"));
  $("import-reference").addEventListener("click",()=>{$("take-popover").open=false;});
  $("actions-undo").onclick=()=>{undo();$("note-actions").open=false;};$("actions-redo").onclick=()=>{redo();$("note-actions").open=false;};
  window.addEventListener("resize",positionTakeMenu);
  document.addEventListener("click",event=>{for(const popover of document.querySelectorAll("details[open]"))if(!popover.contains(event.target))popover.open=false;});
  document.addEventListener("keydown",event=>{
    if(event.key==="Escape"){
      if(window.LocalMidiLayout?.cancelGesture?.()){event.preventDefault();event.stopImmediatePropagation();return;}
      if(window.LocalMidiNavigation?.cancelGesture?.()){event.preventDefault();event.stopImmediatePropagation();return;}
      if(cancelPendingGesture()){event.preventDefault();event.stopImmediatePropagation();return;}
      if(rulerGesture){rulerGesture=false;pendingSeek=null;}
      const popovers=[...document.querySelectorAll("details[open]")];
      if(popovers.length){
        const active=event.target.closest?.("details")||popovers[0];
        for(const popover of popovers)popover.open=false;
        active.querySelector("summary")?.focus({preventScroll:true});event.preventDefault();event.stopImmediatePropagation();return;
      }
      if(state.fullView){event.preventDefault();fullView(false);return;}
      if(!["INPUT","SELECT","TEXTAREA"].includes(event.target.tagName))setSelection([]);
      return;
    }
    if(event.isComposing||["INPUT","SELECT","TEXTAREA"].includes(event.target.tagName)||event.target.isContentEditable||event.target.closest?.('[role="slider"],[role="separator"]'))return;
    const key=event.key.toLowerCase(),plain=!event.ctrlKey&&!event.metaKey&&!event.altKey;
    // Finish the transaction before shared history/delete shortcuts run in app.js.
    if((gesture||velocityGesture)&&((event.ctrlKey||event.metaKey)&&["z","y"].includes(key)||["Delete","Backspace"].includes(event.key)))cancelPendingGesture();
    if(event.key.toLowerCase()==="a"&&!event.ctrlKey&&!event.metaKey&&!event.altKey){event.preventDefault();$("follow-playhead").click();return;}
    if(event.key.toLowerCase()==="f"&&!event.ctrlKey&&!event.metaKey&&!event.altKey){event.preventDefault();fullView(!state.fullView);return;}
    if(state.view!=="edit")return;
    if(plain&&["v","b","e"].includes(key)){event.preventDefault();setTool({v:"select",b:"draw",e:"erase"}[key]);return;}
    if(plain&&key==="h"){event.preventDefault();fitNotes();return;}
    if(event.key.toLowerCase()==="l"&&!event.ctrlKey&&!event.metaKey&&!event.altKey)$("lasso-mode").click();
    if((event.ctrlKey||event.metaKey)&&!event.shiftKey&&event.key.toLowerCase()==="a"&&state.result){event.preventDefault();setSelection(state.notes.map(n=>n.id),true);}
  },true);
  const observer=new ResizeObserver(()=>{if(fitted&&state.audio)fitTimeline();else{resizeRoll();drawComparison();}drawWave();});observer.observe($("main-area")||document.querySelector(".main-area"));
  window.LocalMidiUI={update,refreshTakes,drawComparison,paintComparison,drawVelocity,drawLasso,selectionChanged,setSelection,setView,fitTimeline,fitNotes,fullView,advanceGesture,updateFollow,
    cancelPendingGesture(){const layout=window.LocalMidiLayout?.cancelGesture?.()||false;const active=cancelPendingGesture()||rulerGesture;rulerGesture=false;pendingSeek=null;return layout||active;},
    updateViewReadouts,
    getReferenceTake(id){if(sourceId!==state.audio?.id)return null;const cached=results.get(id),edits=state.native&&state.nativeEdits.get(id);return edits?{...cached,...edits,id}:cached||null;},
    isInteracting(){return !!gesture||!!velocityGesture||rulerGesture;},setManualViewport(){fitted=false;},
    timelineViewport(){return state.view==="compare"?{element:compareScroll,keys:labelWidth()+compareKeys}:{element:$("roll-scroll"),keys:KEYS};},
    renderPlayhead(time){if(state.view!=="compare")return;const keys=labelWidth()+compareKeys,width=compareScroll.clientWidth;placePlayhead("compare-playhead",keys+time*state.px-compareScroll.scrollLeft,width,keys);},
    sourceChanged(){if(!state.restoringNative)fitTimeline();update();},
    restore(saved){
      if(Number.isFinite(saved.row_height))ROW=clamp(Math.round(saved.row_height),10,28);
      $("row-height").value=ROW;$("editor-snap").value=["off","8","16","32"].includes(saved.editor_snap)?saved.editor_snap:"off";updateHint();
      document.body.classList.toggle("source-collapsed",!!saved.source_collapsed);$("toggle-source").setAttribute("aria-expanded",String(!saved.source_collapsed));$("toggle-source").title=saved.source_collapsed?"Show source controls":"Hide source controls";
      $("ui-density").value=saved.density==="comfortable"?"comfortable":"compact";document.body.classList.toggle("comfortable-density",$("ui-density").value==="comfortable");
      window.LocalMidiLayout?.restore?.(saved);window.LocalMidiOverlay?.restore?.(saved);
      setVelocityHeight();
      if(Number.isFinite(saved.zoom)){state.px=Math.max(.1,Math.min(160,saved.zoom));$("zoom").value=state.px;fitted=false;}
      if(saved.export_options){const o=saved.export_options;if(Number.isFinite(o.bpm)&&o.bpm>=20&&o.bpm<=400)$("bpm").value=o.bpm;if([8,12,16,24,32].includes(o.subdivision))$("subdivision").value=o.subdivision;$("quantize").checked=!!o.quantize;}
      state.follow=saved.follow!==false;state.followMode=saved.follow_mode==="smooth"?"smooth":"page";state.rulerMode=saved.ruler_mode==="bars"?"bars":"time";
      $("follow-mode").value=state.followMode;$("ruler-mode").value=state.rulerMode;updateFollow();
      $("show-differences").checked=!!saved.show_differences;setView(saved.view);
      $("selection-origin").value=saved.selection_origin==="source"?"source":"start";
      state.selectedIds=new Set(Array.isArray(saved.selected_ids)?saved.selected_ids:[]);state.exportScope=saved.export_scope==="selection"?"selection":"all";selectionChanged();
      fullView(!!saved.full_view);
    }
  };
  setVelocityHeight();updateHint();update();
})();
