"use strict";
// Workspace preferences are independent of note transactions and transport state.
(() => {
  let elements=null,requestedHeight=null,velocityVisible=true,overviewVisible=true;
  let gesture=null,pendingHeight=null,layoutFrame=0,menuFrame=0,applying=false;
  const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
  const prefs=()=>({velocity_height:gesture?gesture.original:requestedHeight,velocity_visible:velocityVisible,overview_visible:overviewVisible});
  const visible=element=>element.getBoundingClientRect().height>0&&getComputedStyle(element).display!=="none";
  const context=()=>[state.audio?.id,state.result?.id,state.resultTicket,state.view,!!state.loadingResult];
  const sameContext=value=>context().every((item,index)=>item===value[index]);
  function syncControls(){
    if(!elements)return;
    elements.showVelocity.checked=velocityVisible;elements.showOverview.checked=overviewVisible;
    if(elements.density)elements.density.value=$("ui-density").value;
  }
  function defaultHeight(){
    if(innerWidth>560&&innerHeight<=520)return 26;
    if(innerWidth>560&&innerHeight<=650)return 32;
    return document.body.classList.contains("comfortable-density")&&!state.fullView?80:64;
  }
  function setClass(name,enabled){
    const before=document.body.classList.contains(name);
    if(before!==enabled)document.body.classList.toggle(name,enabled);
    return before!==enabled;
  }
  function apply(){
    if(!bind()||applying)return false;
    applying=true;
    try{
      let changed=setClass("overview-hidden",!overviewVisible);
      if(changed)window.LocalMidiNavigation?.update?.();
      const {editor,lane,divider,scroller}=elements;
      let room=160;
      if(state.view==="edit"&&editor.clientHeight>0){
        let fixed=0;
        for(const child of editor.children){
          if(child===lane||child===divider||child===scroller)continue;
          if(visible(child))fixed+=child.getBoundingClientRect().height;
        }
        const dividerHeight=innerWidth>560&&innerHeight<=520?5:7;
        const scrollbars=Math.max(0,scroller.offsetHeight-scroller.clientHeight);
        room=Math.max(0,Math.floor(editor.clientHeight-fixed-60-scrollbars-dividerHeight));
      }
      const maximum=Math.min(160,room);
      const height=Math.max(0,Math.min(requestedHeight??defaultHeight(),maximum));
      const show=velocityVisible&&height>=26;
      const minimum=show?Math.min(32,maximum,height):0;
      changed=setClass("velocity-hidden",!show)||changed;
      const cssHeight=(show?height:0)+"px";
      if(lane.style.height!==cssHeight){lane.style.height=cssHeight;changed=true;}
      if(lane.hidden===show){lane.hidden=!show;changed=true;}
      if(divider.hidden===show){divider.hidden=!show;changed=true;}
      divider.setAttribute("aria-valuemin",String(minimum));divider.setAttribute("aria-valuemax",String(maximum));
      divider.setAttribute("aria-valuenow",String(show?height:0));
      divider.setAttribute("aria-valuetext",show?height+" pixels; drag or use arrow keys":"Velocity lane hidden");
      divider.setAttribute("aria-disabled",String(!show||!state.result||state.loadingResult||state.view!=="edit"));
      const status=$("view-layout-status");
      if(status){
        const text=velocityVisible&&!show?"The lane will return when the window has more room.":
          requestedHeight!==null&&height<requestedHeight?"Lane height adapts to the available space.":
          overviewVisible&&innerWidth>560&&innerHeight<=520?"Short windows favor the note grid.":"Drag the divider above the velocity lane to resize it.";
        if(status.textContent!==text)status.textContent=text;
      }
      syncControls();return changed;
    }finally{applying=false;}
  }
  function resize(){
    if(layoutFrame)cancelAnimationFrame(layoutFrame);layoutFrame=0;
    if(pendingHeight!==null){requestedHeight=pendingHeight;pendingHeight=null;}
    apply();resizeRoll();window.LocalMidiNavigation?.update?.();
    if(elements?.menu.open)positionMenu();
  }
  function queueResize(){if(!layoutFrame)layoutFrame=requestAnimationFrame(resize);}
  function release(previous){
    if(!previous||!elements)return;
    elements.divider.classList.remove("dragging");
    if(elements.divider.hasPointerCapture?.(previous.pointerId))elements.divider.releasePointerCapture(previous.pointerId);
  }
  function cancelGesture(){
    if(!gesture)return false;
    const previous=gesture;gesture=null;pendingHeight=null;requestedHeight=previous.original;
    release(previous);resize();return true;
  }
  function cancelOther(){
    window.LocalMidiUI?.cancelPendingGesture?.();window.LocalMidiNavigation?.cancelGesture?.();
  }
  function begin(event){
    if(event.button!==0||event.isPrimary===false||!state.result||state.loadingResult||state.view!=="edit"||!velocityVisible)return;
    cancelOther();apply();
    if(elements.lane.hidden)return;
    event.preventDefault();elements.divider.focus({preventScroll:true});
    gesture={pointerId:event.pointerId,startY:event.clientY,height:elements.lane.getBoundingClientRect().height,original:requestedHeight,context:context(),moved:false};
    elements.divider.classList.add("dragging");
    if(event.isTrusted)elements.divider.setPointerCapture?.(event.pointerId);
    requestFrame();
  }
  function move(event){
    if(!gesture||event.pointerId!==gesture.pointerId)return;
    if(!sameContext(gesture.context)){cancelGesture();return;}
    const delta=gesture.startY-event.clientY;
    if(gesture.height<32&&delta<=0){
      pendingHeight=null;requestedHeight=gesture.original;queueResize();return;
    }
    if(!gesture.moved&&Math.abs(delta)<1)return;
    gesture.moved=true;pendingHeight=clamp(Math.round(gesture.height+delta),32,160);queueResize();
  }
  function end(event){
    if(!gesture||event.pointerId!==gesture.pointerId)return;
    if(event.type!=="pointerup"||!sameContext(gesture.context)){cancelGesture();return;}
    move(event);const previous=gesture;gesture=null;
    if(previous.moved&&Math.abs(event.clientY-previous.startY)<1){requestedHeight=previous.original;pendingHeight=null;}
    release(previous);resize();
    if(previous.moved&&requestedHeight!==previous.original)publishNativeUi();
  }
  function key(event){
    if(event.isComposing||event.ctrlKey||event.metaKey||event.altKey||!state.result||state.loadingResult||state.view!=="edit"||elements.lane.hidden)return;
    if(!["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Home","End"].includes(event.key))return;
    event.preventDefault();event.stopPropagation();cancelOther();apply();
    const current=Math.round(elements.lane.getBoundingClientRect().height),step=event.shiftKey?16:4;
    if(current<32&&["ArrowDown","ArrowLeft","Home"].includes(event.key))return;
    const maximum=Number(elements.divider.getAttribute("aria-valuemax"));
    const next=event.key==="Home"?32:event.key==="End"?maximum:current+(["ArrowUp","ArrowRight"].includes(event.key)?step:-step);
    const height=clamp(Math.round(next),32,160);
    if(Math.min(height,maximum)===current)return;
    requestedHeight=height;resize();publishNativeUi();
  }
  function positionMenu(){
    if(!elements?.menu.open)return;
    const {panel,summary}=elements,viewport=window.visualViewport;
    const left=viewport?.offsetLeft||0,top=viewport?.offsetTop||0,width=viewport?.width||innerWidth,height=viewport?.height||innerHeight;
    Object.assign(panel.style,{position:"fixed",right:"auto",bottom:"auto",margin:"0",minWidth:"0",boxSizing:"border-box",
      maxWidth:Math.max(1,width-24)+"px",maxHeight:Math.max(1,height-24)+"px",overflowY:"auto"});
    const anchor=summary.getBoundingClientRect(),box=panel.getBoundingClientRect();
    panel.style.left=clamp(anchor.right-box.width,left+12,Math.max(left+12,left+width-box.width-12))+"px";
    const below=anchor.bottom+6,above=anchor.top-box.height-6;
    panel.style.top=clamp(below+box.height<=top+height-12?below:above>=top+12?above:below,
      top+12,Math.max(top+12,top+height-box.height-12))+"px";
  }
  function queueMenu(){if(elements?.menu.open&&!menuFrame)menuFrame=requestAnimationFrame(()=>{menuFrame=0;positionMenu();});}
  function reset(){
    cancelOther();requestedHeight=null;velocityVisible=true;overviewVisible=true;
    syncControls();resize();publishNativeUi();
  }
  function bind(){
    if(elements)return true;
    const ids=["editor-view","velocity-lane","velocity-divider","roll-scroll","show-velocity","show-overview","view-popover"];
    const found=ids.map(id=>$(id));if(found.some(item=>!item))return false;
    const [editor,lane,divider,scroller,showVelocity,showOverview,menu]=found;
    const panel=menu.querySelector(".view-panel"),summary=menu.querySelector("summary");
    if(!panel||!summary)return false;
    elements={editor,lane,divider,scroller,showVelocity,showOverview,menu,panel,summary,density:$("view-density")};
    divider.addEventListener("pointerdown",begin);
    window.addEventListener("pointermove",move,{passive:true});window.addEventListener("pointerup",end,{passive:true});
    window.addEventListener("pointercancel",end,{passive:true});
    divider.addEventListener("lostpointercapture",event=>{if(gesture?.pointerId===event.pointerId)cancelGesture();});
    divider.addEventListener("keydown",key);divider.addEventListener("dblclick",event=>{event.preventDefault();cancelOther();requestedHeight=null;resize();publishNativeUi();});
    showVelocity.addEventListener("change",()=>{const value=showVelocity.checked;cancelOther();velocityVisible=value;resize();publishNativeUi();});
    showOverview.addEventListener("change",()=>{const value=showOverview.checked;cancelOther();overviewVisible=value;resize();publishNativeUi();});
    elements.density?.addEventListener("change",()=>{const value=elements.density.value;cancelOther();$("ui-density").value=value;$("ui-density").dispatchEvent(new Event("change"));syncControls();queueMenu();});
    $("reset-view-layout")?.addEventListener("click",reset);
    menu.addEventListener("toggle",()=>{if(menu.open){syncControls();positionMenu();queueMenu();}});
    window.addEventListener("blur",cancelGesture);
    document.addEventListener("visibilitychange",()=>{if(document.hidden)cancelGesture();});
    window.addEventListener("resize",()=>{queueResize();queueMenu();});
    document.addEventListener("scroll",event=>{if(!panel.contains(event.target))queueMenu();},true);
    window.visualViewport?.addEventListener("resize",queueMenu);window.visualViewport?.addEventListener("scroll",queueMenu);
    if(typeof ResizeObserver==="function"){
      const observer=new ResizeObserver(queueResize);observer.observe(editor);
      for(const item of [$("note-overview"),document.querySelector(".note-inspector")])if(item)observer.observe(item);
      new ResizeObserver(queueMenu).observe(panel);
    }
    return true;
  }
  function update(){
    if(!bind())return;
    if(gesture&&!sameContext(gesture.context))cancelGesture();
    syncControls();if(apply())queueResize();
  }
  function restore(saved={}){
    cancelGesture();
    requestedHeight=typeof saved.velocity_height==="number"&&Number.isFinite(saved.velocity_height)?clamp(Math.round(saved.velocity_height),32,160):null;
    velocityVisible=saved.velocity_visible!==false;overviewVisible=saved.overview_visible!==false;
    syncControls();apply();queueResize();
  }
  window.LocalMidiLayout={apply,update,cancelGesture,isInteracting:()=>!!gesture,getPreferences:prefs,restore};
  update();
})();
