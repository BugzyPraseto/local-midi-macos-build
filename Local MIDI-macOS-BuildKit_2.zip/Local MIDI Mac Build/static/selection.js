"use strict";
// Geometry shared by rectangular and freehand note selection; no DOM dependencies.
(function(root){
  const epsilon=1e-7;
  function onSegment(p,a,b){
    return Math.abs((b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x))<epsilon &&
      p.x>=Math.min(a.x,b.x)-epsilon&&p.x<=Math.max(a.x,b.x)+epsilon&&
      p.y>=Math.min(a.y,b.y)-epsilon&&p.y<=Math.max(a.y,b.y)+epsilon;
  }
  function inside(point,polygon){
    let result=false;
    for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){
      const a=polygon[j],b=polygon[i];if(onSegment(point,a,b))return true;
      if((a.y>point.y)!==(b.y>point.y)&&point.x<(b.x-a.x)*(point.y-a.y)/(b.y-a.y)+a.x)result=!result;
    }
    return result;
  }
  function crosses(a,b,c,d){
    const cross=(p,q,r)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);
    const x=cross(a,b,c),y=cross(a,b,d),u=cross(c,d,a),v=cross(c,d,b);
    return (x*y<0&&u*v<0)||onSegment(c,a,b)||onSegment(d,a,b)||onSegment(a,c,d)||onSegment(b,c,d);
  }
  function intersects(polygon,rect){
    if(polygon.length<3)return false;
    const corners=[{x:rect.x,y:rect.y},{x:rect.x+rect.w,y:rect.y},{x:rect.x+rect.w,y:rect.y+rect.h},{x:rect.x,y:rect.y+rect.h}];
    if(corners.some(p=>inside(p,polygon)))return true;
    if(polygon.some(p=>p.x>=rect.x&&p.x<=rect.x+rect.w&&p.y>=rect.y&&p.y<=rect.y+rect.h))return true;
    for(let i=0;i<polygon.length;i++)for(let j=0;j<4;j++)if(crosses(polygon[i],polygon[(i+1)%polygon.length],corners[j],corners[(j+1)%4]))return true;
    return false;
  }
  function select(notes,polygon,{px,row,high,keys,ruler}){
    if(polygon.length<3)return [];
    const xs=polygon.map(p=>p.x),ys=polygon.map(p=>p.y),left=Math.min(...xs),right=Math.max(...xs),top=Math.min(...ys),bottom=Math.max(...ys);
    return notes.filter(note=>{
      const rect={x:keys+note.start*px,y:ruler+(high-note.pitch)*row+2,w:Math.max(3,(note.end-note.start)*px),h:row-3};
      return rect.x<=right&&rect.x+rect.w>=left&&rect.y<=bottom&&rect.y+rect.h>=top&&intersects(polygon,rect);
    }).map(note=>note.id);
  }
  const api={inside,intersects,select};root.MidiSelection=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
