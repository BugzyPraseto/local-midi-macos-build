// Optional JUCE integration. The ordinary browser app keeps its existing path.
export async function createNativeBridge() {
  if (!window.__JUCE__?.backend) return null;
  const { getNativeFunction } = await import("/juce/index.js");
  const invoke = getNativeFunction("localMidi");
  return async (command, payload = null) => {
    const result = await invoke(command, payload);
    if (!result?.ok) throw new Error(result?.error || "The native operation failed.");
    return result;
  };
}

export function base64(bytes) {
  let binary = "";
  for (let index = 0; index < bytes.length; index += 0x4000)
    binary += String.fromCharCode(...bytes.subarray(index, index + 0x4000));
  return btoa(binary);
}
