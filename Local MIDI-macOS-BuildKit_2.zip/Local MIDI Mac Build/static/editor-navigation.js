"use strict";
// Overview and hover feedback. Committed note geometry stays off the playback path.
(() => {
  let elements = null, snapshot = null, painted = null, wanted = null;
  let overviewFrame = 0, hoverFrame = 0, pendingHover = null, hoverKey = "";
  let gesture = null, environment = null, width = 0, height = 0, lastTime = 0;
  const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
  const attr = (element, name, value) => {
    value = String(value);
    if (element.getAttribute(name) !== value) element.setAttribute(name, value);
  };
  const style = (element, name, value) => {
    if (element.style[name] !== value) element.style[name] = value;
  };
  function hidden(element, value) {
    if (!element) return;
    if (element.hidden !== value) element.hidden = value;
    if (element.classList.contains("hidden") !== value) element.classList.toggle("hidden", value);
  }
  const editing = () => !!window.LocalMidiUI?.isInteracting?.() || !!window.LocalMidiLayout?.isInteracting?.();
  const available = () => !!state.audio && !!state.result && state.view === "edit";
  const sameSource = () => snapshot && snapshot.source === state.audio?.id && snapshot.result === state.result?.id;

  function hideTooltip() {
    if (!elements) return;
    hidden(elements.tooltip, true);
    elements.tooltip.textContent = "";
    hoverKey = "";
  }
  function clearHover() {
    if (hoverFrame) cancelAnimationFrame(hoverFrame);
    hoverFrame = 0;
    pendingHover = null;
    hideTooltip();
    if (elements) hidden(elements.band, true);
  }
  function cancelGesture() {
    const previous = gesture;
    gesture = null;
    if (previous && elements) {
      elements.track.classList.remove("dragging");
      if (elements.track.hasPointerCapture?.(previous.pointerId)) {
        elements.track.releasePointerCapture(previous.pointerId);
      }
    }
    clearHover();
    return !!previous;
  }
  function validGesture() {
    return gesture && available() && !state.loadingResult &&
      gesture.source === state.audio.id && gesture.result === state.result.id;
  }

  // Only inspect notes at a committed revision (or a replacement notes array).
  // A gesture mutates live notes before it commits; keep its preview out of this cache.
  function committedNotes() {
    const source = state.audio.id, result = state.result.id, audioDuration = state.audio.duration;
    const referenceDuration = window.LocalMidiOverlay?.duration?.() || 0;
    if (snapshot && snapshot.source === source && snapshot.result === result &&
        snapshot.version === state.editVersion && snapshot.identity === state.notes &&
        snapshot.audioDuration === audioDuration && snapshot.referenceDuration === referenceDuration) return snapshot;
    if (editing()) return sameSource() ? snapshot : null;
    const notes = [];
    let low = 127, high = 0;
    for (const note of state.notes) {
      if (!Number.isFinite(note.start) || !Number.isFinite(note.end) || !Number.isFinite(note.pitch)) continue;
      const pitch = clamp(note.pitch, 0, 127);
      notes.push({id: note.id, start: note.start, end: note.end, pitch});
      low = Math.min(low, pitch); high = Math.max(high, pitch);
    }
    snapshot = {source, result, version: state.editVersion, identity: state.notes, audioDuration, referenceDuration,
      duration: Math.max(.001, Number(timelineDuration()) || .001), notes,
      low: notes.length ? Math.max(0, low - 2) : 48,
      high: notes.length ? Math.min(127, high + 2) : 72};
    return snapshot;
  }
  const samePaint = (a, b) => a && b && a.snapshot === b.snapshot && a.width === b.width &&
    a.height === b.height && a.dpr === b.dpr && a.selection === b.selection;
  function queueOverview() {
    if (!overviewFrame) overviewFrame = requestAnimationFrame(paintOverview);
  }
  function paintOverview() {
    overviewFrame = 0;
    const next = wanted;
    if (!next || !available() || !sameSource() || samePaint(next, painted)) return;
    const {canvas} = elements, data = next.snapshot;
    const context = sizeCanvas(canvas, next.width, next.height);
    context.globalAlpha = 1;
    context.fillStyle = "#15171a";
    context.fillRect(0, 0, next.width, next.height);
    const margin = Math.min(4, next.height / 4);
    const pitchHeight = (next.height - margin * 2) / (data.high - data.low + 1);
    const noteHeight = Math.min(5, Math.max(1, pitchHeight * .8));
    // Two paths keep large takes inexpensive, including dense selected passages.
    for (const selected of [false, true]) {
      context.beginPath();
      for (const note of data.notes) {
        if (next.ids.has(note.id) !== selected) continue;
        const x = clamp(note.start / data.duration * next.width, 0, next.width);
        const end = clamp(note.end / data.duration * next.width, 0, next.width);
        const noteWidth = Math.min(next.width - x, Math.max(1, end - x));
        if (noteWidth <= 0) continue;
        const y = margin + (data.high - note.pitch + .5) * pitchHeight - noteHeight / 2;
        context.rect(x, y, noteWidth, noteHeight);
      }
      context.fillStyle = selected ? "#fff0c2" : "#7ddff5";
      context.fill();
    }
    painted = next;
  }

  function metrics() {
    if (!elements || !snapshot || !available() || !sameSource()) return null;
    const scroller = elements.scroller, px = Number(state.px);
    if (!(px > 0) || !width) return null;
    const duration = snapshot.duration;
    const visible = Math.max(0, scroller.clientWidth - KEYS) / px;
    // The roll includes 35px after the last timestamp. Preserve its real scroll
    // range, and clip just the overview rectangle to the timeline itself.
    const maxScroll = Math.max(0, scroller.scrollWidth - scroller.clientWidth);
    const start = clamp(scroller.scrollLeft / px, 0, duration);
    const end = clamp(start + visible, start, duration);
    return {duration, visible, px, maxScroll, start, end,
      left: start / duration * width, windowWidth: (end - start) / duration * width};
  }
  function syncViewport() {
    const view = metrics();
    if (!view) return;
    const slider = elements.slider;
    style(slider, "transform", `translate3d(${view.left}px,0,0)`);
    style(slider, "width", `${view.windowWidth}px`);
    attr(slider, "aria-valuemin", 0);
    attr(slider, "aria-valuemax", view.duration);
    attr(slider, "aria-valuenow", view.start);
    attr(slider, "aria-valuetext", `${view.start.toFixed(3)} s to ${view.end.toFixed(3)} s of ${view.duration.toFixed(3)} s`);
    attr(slider, "aria-disabled", !!state.loadingResult || view.maxScroll < .5 || !view.visible);
  }
  function manualPan(seconds) {
    const view = metrics();
    if (!view || state.loadingResult) return;
    const next = clamp(seconds * view.px, 0, view.maxScroll);
    if (Math.abs(elements.scroller.scrollLeft - next) > .01) {
      window.LocalMidiUI?.setManualViewport?.();
      // Do this before assigning scrollLeft: follow may run before a scroll event.
      if (state.playing) {
        state.followSuspended = true;
        window.LocalMidiUI?.updateFollow?.();
      }
      elements.scroller.scrollLeft = next;
    }
    clearHover();
    syncViewport();
  }
  function pointerSeconds(event) {
    const rect = elements.track.getBoundingClientRect();
    return rect.width > 0 ? (event.clientX - rect.left) / rect.width * snapshot.duration : 0;
  }
  function beginPan(event) {
    if (event.button !== 0 || event.isPrimary === false || !available() || state.loadingResult) return;
    cancelGesture();
    window.LocalMidiUI?.cancelPendingGesture?.();
    update();
    const view = metrics();
    if (!view || view.maxScroll < .5 || !view.visible) return;
    const seconds = pointerSeconds(event);
    const inside = event.target === elements.slider || elements.slider.contains(event.target) ||
      seconds >= view.start && seconds <= view.end;
    gesture = {pointerId: event.pointerId, source: state.audio.id, result: state.result.id,
      offset: inside ? seconds - elements.scroller.scrollLeft / view.px : view.visible / 2};
    elements.track.classList.add("dragging");
    elements.slider.focus({preventScroll: true});
    // Synthetic events in browser QA do not own a native pointer to capture.
    if (event.isTrusted && elements.track.setPointerCapture) elements.track.setPointerCapture(event.pointerId);
    if (!inside) manualPan(seconds - gesture.offset);
  }
  function movePan(event) {
    if (!gesture || event.pointerId !== gesture.pointerId) return;
    if (!validGesture()) { cancelGesture(); return; }
    manualPan(pointerSeconds(event) - gesture.offset);
  }
  function endPan(event) {
    if (!gesture || event.pointerId !== gesture.pointerId) return;
    if (event.type === "pointerup" && validGesture()) movePan(event);
    cancelGesture();
  }
  function panKey(event) {
    if (!available() || state.loadingResult || event.ctrlKey || event.metaKey || event.altKey) return;
    const view = metrics();
    if (!view) return;
    let next;
    const step = Math.max(.05, view.visible * (event.shiftKey ? 1 : .1));
    if (event.key === "Home") next = 0;
    else if (event.key === "End") next = view.maxScroll / view.px;
    else if (["ArrowLeft", "ArrowUp"].includes(event.key)) next = elements.scroller.scrollLeft / view.px - step;
    else if (["ArrowRight", "ArrowDown"].includes(event.key)) next = elements.scroller.scrollLeft / view.px + step;
    else return;
    event.preventDefault();
    cancelGesture();
    window.LocalMidiUI?.cancelPendingGesture?.();
    manualPan(next);
  }

  function viewportBounds() {
    const viewport = window.visualViewport;
    const left = viewport?.offsetLeft || 0, top = viewport?.offsetTop || 0;
    return {left, top, width: viewport?.width || document.documentElement.clientWidth || window.innerWidth,
      height: viewport?.height || window.innerHeight};
  }
  function placeTooltip(target, pointerX) {
    const tooltip = elements.tooltip, viewport = viewportBounds(), margin = 8, gap = 8;
    const maxWidth = Math.min(340, viewport.width - margin * 2);
    if (maxWidth < 64 || viewport.height < 48) { hideTooltip(); return; }
    style(tooltip, "maxWidth", `${maxWidth}px`);
    style(tooltip, "maxHeight", `${Math.max(1, viewport.height - margin * 2)}px`);
    style(tooltip, "visibility", "hidden");
    hidden(tooltip, false);
    const box = tooltip.getBoundingClientRect();
    const left = viewport.left + margin, right = viewport.left + viewport.width - margin;
    const top = viewport.top + margin, bottom = viewport.top + viewport.height - margin;
    const x = clamp(pointerX + 14, left, Math.max(left, right - box.width));
    let at = null;
    if (target.top - gap - box.height >= top) at = {x, y: target.top - gap - box.height};
    else if (target.bottom + gap + box.height <= bottom) at = {x, y: target.bottom + gap};
    else if (target.right + gap + box.width <= right) at = {x: target.right + gap, y: clamp(target.top, top, bottom - box.height)};
    else if (target.left - gap - box.width >= left) at = {x: target.left - gap - box.width, y: clamp(target.top, top, bottom - box.height)};
    if (!at || box.width > right - left || box.height > bottom - top) { hideTooltip(); return; }
    style(tooltip, "left", `${at.x}px`);
    style(tooltip, "top", `${at.y}px`);
    style(tooltip, "visibility", "visible");
  }
  function paintHover() {
    hoverFrame = 0;
    const event = pendingHover;
    pendingHover = null;
    if (!event || !state.audio || state.view !== "edit" || state.loadingResult || gesture || editing()) { clearHover(); return; }
    const p = position(event), scroller = elements.scroller;
    const y = p.y - scroller.scrollTop, rollWidth = roll.logicalWidth || roll.clientWidth;
    if (p.x < 0 || p.x >= rollWidth || y < 0 || y >= (roll.logicalHeight || roll.clientHeight)) { clearHover(); return; }
    const pitch = HIGH - Math.floor(p.y / ROW);
    if (pitch < 0 || pitch > 127) { clearHover(); return; }
    const keyboard = p.x < KEYS, note = keyboard ? null : hitTest(p.x, p.y);
    if (!keyboard && !note) { clearHover(); return; }
    const key = keyboard ? `key:${pitch}` : JSON.stringify([note.id, note.pitch, note.start, note.end, note.velocity]);
    if (hoverKey === key) return;
    hoverKey = key;
    const band = elements.band, rowY = (HIGH - pitch) * ROW - scroller.scrollTop;
    style(band, "transform", `translate3d(0,${rowY}px,0)`);
    style(band, "height", `${ROW}px`);
    style(band, "left", keyboard ? "0px" : `${KEYS}px`);
    style(band, "right", keyboard ? "auto" : "0px");
    style(band, "width", keyboard ? `${isBlack(pitch) ? KEYS * .6 : KEYS}px` : "auto");
    hidden(band, false);
    const bounds = roll.getBoundingClientRect();
    let target;
    if (keyboard) {
      elements.tooltip.textContent = `${pitchName(pitch)} · MIDI ${pitch}`;
      target = {left: bounds.left, right: bounds.left + (isBlack(pitch) ? KEYS * .6 : KEYS),
        top: bounds.top + rowY, bottom: bounds.top + rowY + ROW};
    } else {
      const seconds = value => `${Number(value).toFixed(3)} s`;
      elements.tooltip.textContent = `${pitchName(note.pitch)} · MIDI ${note.pitch}\nOnset ${seconds(note.start)} · End ${seconds(note.end)}\nDuration ${seconds(note.end - note.start)} · Velocity ${note.velocity}`;
      const rect = noteRect(note);
      target = {left: bounds.left + Math.max(KEYS, rect.x), right: bounds.left + Math.min(rollWidth, rect.x + rect.w),
        top: bounds.top + rect.y - scroller.scrollTop, bottom: bounds.top + rect.y + rect.h - scroller.scrollTop};
    }
    placeTooltip(target, event.clientX);
  }
  function hoverMove(event) {
    if (event.buttons || event.pointerType === "touch" || !state.audio || state.view !== "edit" ||
        state.loadingResult || gesture || editing()) { clearHover(); return; }
    pendingHover = {clientX: event.clientX, clientY: event.clientY};
    if (!hoverFrame) hoverFrame = requestAnimationFrame(paintHover);
  }

  function bind() {
    if (elements) return true;
    const ids = ["note-overview", "overview-track", "overview-canvas", "overview-window", "overview-playhead",
      "note-tooltip", "pitch-hover", "roll-scroll"];
    const found = ids.map(id => document.getElementById(id));
    if (found.some(element => !element)) return false;
    const [row, track, canvas, slider, playhead, tooltip, band, scroller] = found;
    elements = {row, track, canvas, slider, playhead, tooltip, band, scroller};
    attr(slider, "role", "slider"); attr(slider, "tabindex", 0);
    attr(slider, "aria-label", "Visible timeline"); attr(slider, "aria-orientation", "horizontal");
    attr(tooltip, "role", "tooltip");
    hidden(tooltip, true); hidden(band, true);
    track.addEventListener("pointerdown", beginPan, {passive: true});
    slider.addEventListener("keydown", panKey);
    track.addEventListener("lostpointercapture", event => {
      if (gesture?.pointerId === event.pointerId) cancelGesture();
    });
    window.addEventListener("pointermove", movePan, {passive: true});
    window.addEventListener("pointerup", endPan, {passive: true});
    window.addEventListener("pointercancel", endPan, {passive: true});
    roll.addEventListener("pointermove", hoverMove, {passive: true});
    roll.addEventListener("pointerleave", clearHover, {passive: true});
    roll.addEventListener("pointercancel", clearHover, {passive: true});
    document.addEventListener("pointerdown", event => {
      clearHover();
      if (gesture && !track.contains(event.target)) cancelGesture();
    }, {capture: true, passive: true});
    document.addEventListener("scroll", clearHover, {capture: true, passive: true});
    scroller.addEventListener("scroll", () => { clearHover(); syncViewport(); }, {passive: true});
    window.addEventListener("blur", cancelGesture);
    window.addEventListener("resize", () => { clearHover(); update(); });
    document.addEventListener("visibilitychange", () => { if (document.hidden) cancelGesture(); });
    window.visualViewport?.addEventListener("resize", clearHover, {passive: true});
    window.visualViewport?.addEventListener("scroll", clearHover, {passive: true});
    if (typeof ResizeObserver === "function") new ResizeObserver(update).observe(track);
    return true;
  }
  function update() {
    if (!bind()) return;
    const nextEnvironment = [state.audio?.id, state.result?.id, state.notes, state.editVersion,
      state.view, !!state.loadingResult, state.px, ROW, elements.scroller.scrollLeft, elements.scroller.scrollTop,
      elements.scroller.clientWidth, elements.scroller.clientHeight];
    if (!environment || nextEnvironment.some((value, index) => value !== environment[index]) || editing()) clearHover();
    environment = nextEnvironment;
    if (gesture && !validGesture()) cancelGesture();
    const show = available() && !document.body.classList.contains("overview-hidden");
    hidden(elements.row, !show);
    attr(elements.row, "aria-hidden", !show);
    if (!show) {
      cancelGesture(); hidden(elements.playhead, true);
      attr(elements.slider, "aria-disabled", true);
      wanted = null;
      if (overviewFrame) cancelAnimationFrame(overviewFrame);
      overviewFrame = 0;
      return;
    }
    if (state.loadingResult) clearHover();
    const data = committedNotes();
    width = Math.max(0, Math.floor(elements.track.clientWidth));
    height = Math.max(0, Math.floor(elements.track.clientHeight));
    if (data && width && height) {
      const ids = new Set(state.selectedIds || []);
      if (state.selected != null) ids.add(state.selected);
      const selection = JSON.stringify([...ids].sort());
      wanted = {snapshot: data, width, height, dpr: Math.min(3, window.devicePixelRatio || 1), selection, ids};
      if (!samePaint(wanted, painted)) queueOverview();
      syncViewport();
    } else {
      wanted = null;
      if (overviewFrame) cancelAnimationFrame(overviewFrame);
      overviewFrame = 0;
      attr(elements.slider, "aria-disabled", true);
    }
    paintPlayhead(lastTime);
  }
  function paintPlayhead(time) {
    lastTime = Number(time);
    if (!elements) return;
    if (gesture && !validGesture()) cancelGesture();
    if (hoverKey && (!state.audio || state.view !== "edit" || state.loadingResult || editing() || !sameSource())) clearHover();
    const show = available() && !document.body.classList.contains("overview-hidden") && !state.loadingResult && sameSource() && width > 0 && height > 0 &&
      Number.isFinite(lastTime) && lastTime >= 0 && lastTime <= snapshot.duration;
    hidden(elements.playhead, !show);
    if (show) {
      const x = Math.min(width - 1, Math.round(lastTime / snapshot.duration * width));
      style(elements.playhead, "transform", `translate3d(${x}px,0,0)`);
    }
  }
  window.LocalMidiNavigation = {update, paintPlayhead, cancelGesture, isInteracting: () => !!gesture};
  update();
})();
