"use strict";
const $ = id => document.getElementById(id);
const state = { models: [], audio: null, result: null, notes: [], instrument: "piano", selected: null,
  undo: [], redo: [], px: 48, jobs: [], activeJobs: new Set(), loadedResults: new Set(), playing: false,
  listen: "original", audioContext: null, voices: [], scheduled: new Set(), saveTimer: null, editVersion: 0,
  modelSelections: {piano: new Set(), guitar: new Set()}, sampleBanks: {}, sampleBuffers: {}, playTicket: 0,
  noteEnds: new Map(), pedalTracks: new Map(), dirty: false, saveChain: Promise.resolve(),
  native: null, nativeTime: 0, nativeSync: Promise.resolve(), restoringNative: false, nativePollBusy: false,
  nativeEdits: new Map(), selectedIds: new Set(), exportScope: "all", dragReady: false, view: "edit", loadingResult: false, resultTicket: 0,
  follow: true, followSuspended: false, followMode: "page", rulerMode: "time", nativeClockAt: 0 };
const audio = $("source-audio");
const roll = $("piano-roll");
const wave = $("waveform");
const LOW = 0, HIGH = 127, RULER = 30, KEYS = 68;
let ROW = 18;
let drag = null;
let toastTimeout;
let framePending=0,rollDirty=true,waveDirty=true,comparisonDirty=true,lastClockPaint=0,lastTimeText="";
function requestFrame(){if(!framePending)framePending=requestAnimationFrame(animate);}
function requestVisual(kind="roll"){
  if(kind==="wave")waveDirty=true;
  else if(kind==="compare")comparisonDirty=true;
  else {rollDirty=true;comparisonDirty=true;}
  requestFrame();
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  if (!response.ok) {
    let message;
    try { const error = await response.json(); message = typeof error.detail === "string" ? error.detail : JSON.stringify(error.detail); }
    catch { message = response.statusText; }
    throw new Error(message);
  }
  return response.json();
}
function notify(message) {
  $("toast").textContent = message; $("toast").classList.remove("hidden");
  clearTimeout(toastTimeout); toastTimeout = setTimeout(() => $("toast").classList.add("hidden"), 7000);
}
function status(message, kind = "", elapsed = "") {
  $("status-text").textContent = message; $("status-bar").className = `status-bar ${kind}`;
  $("elapsed").textContent = elapsed;
}
function formatTime(value, precise = false) {
  const seconds = Math.max(0, Number(value) || 0);
  return `${Math.floor(seconds / 60)}:${(seconds % 60).toFixed(precise ? 2 : 0).padStart(precise ? 5 : 2, "0")}`;
}
function pitchName(pitch) { return ["C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"][pitch % 12] + (Math.floor(pitch / 12) - 1); } // taste-skill-ignore: sharp signs are musical pitch notation.
function isBlack(pitch) { return [1,3,6,8,10].includes(pitch % 12); }
function playbackTime(){return state.native ? MidiTimelineView.interpolate({position:state.nativeTime,received:state.nativeClockAt,playing:state.playing,now:performance.now(),duration:state.audio?.duration||0}) : audio.currentTime;}
function clone(value) { return JSON.parse(JSON.stringify(value)); }
function setEnabled() {
  const selection = state.modelSelections[state.instrument];
  $("transcribe").disabled = !state.audio || !selection.size || state.activeJobs.size > 0;
  $("export-midi").disabled = !state.result || !!state.exporting;
  $("import-reference").disabled = !state.audio;
  $("restore").disabled = !state.result;
  $("undo").disabled = !state.undo.length;
  $("redo").disabled = !state.redo.length;
  $("cancel-job").classList.toggle("hidden", !state.activeJobs.size);
  $("play").disabled = $("stop").disabled = !state.audio;
  window.LocalMidiUI?.update();
  $("quantize").disabled = !state.result;
}
function updateModelOptions() {
  const list = $("model-options"); list.replaceChildren();
  const models = state.models.filter(model => model.instruments.includes(state.instrument));
  const selection = state.modelSelections[state.instrument];
  if (!selection.initialized) {for(const model of models)if(model.ready&&model.id!=="basic_pitch")selection.add(model.id);selection.initialized=true;}
  for (const model of models) {
    const label=document.createElement("label");label.className="model-option"+(selection.has(model.id)?" selected":"");
    const checkbox=document.createElement("input");checkbox.type="checkbox";checkbox.id=`model-${model.id}`;checkbox.checked=selection.has(model.id);checkbox.disabled=!model.ready;
    const content=document.createElement("span");const title=document.createElement("strong");title.textContent=model.name;
    const detail=document.createElement("small");detail.textContent=model.ready?(model.id==="basic_pitch"?"Baseline comparison":"Specialist model"):"Not installed";
    content.append(title,detail);label.append(checkbox,content);list.append(label);
    checkbox.onchange=()=>{checkbox.checked?selection.add(model.id):selection.delete(model.id);label.classList.toggle("selected",checkbox.checked);modelDescription();setEnabled();publishNativeUi();};
  }
  modelDescription(); setEnabled();
}
function modelDescription() {
  const selection=state.modelSelections[state.instrument];
  $("model-description").textContent = selection.size>1?`${selection.size} models · queued one at a time`:
    selection.size?state.models.find(model=>selection.has(model.id))?.description:"Select at least one model.";
  const available=state.models.filter(model=>model.ready&&model.instruments.includes(state.instrument));
  $("select-all-models").textContent=selection.size===available.length?"Clear":"Select all";
}
async function refreshSources() {
  const items = await api("/api/audio"); const list = $("source-list"); list.replaceChildren();
  if (!items.length) { const p = document.createElement("p"); p.className = "small muted"; p.textContent = "Your recordings stay here."; list.append(p); }
  for (const item of items) {
    const button = document.createElement("button"); button.className = "source-item" + (item.id === state.audio?.id ? " active" : "");
    const title = document.createElement("strong"); title.textContent = item.name;
    const sub = document.createElement("small"); sub.textContent = `${formatTime(item.duration)} · ${(item.sample_rate / 1000).toFixed(1)} kHz`;
    button.append(title, sub); button.addEventListener("click", () => { $("library-popover").open=false; selectAudio(item.id).catch(error => notify(error.message)); }); list.append(button);
  }
}
async function upload(file) {
  if (!file) return;
  pause(); status("Importing and decoding audio…", "running");
  const body = new FormData(); body.append("file", file);
  try { const item = await api("/api/audio", {method:"POST", body}); await selectAudio(item.id); }
  catch (error) { status(error.message, "error"); notify(error.message); }
  $("audio-file").value = "";
}
async function selectAudio(id) {
  window.LocalMidiUI?.cancelPendingGesture?.();window.LocalMidiNavigation?.cancelGesture?.();window.LocalMidiLayout?.cancelGesture?.();
  if (state.result) await persistNotes();
  const sourceTicket=(state.sourceTicket||0)+1;state.sourceTicket=sourceTicket;
  pause();clearTimeout(state.saveTimer);state.resultTicket++;state.dragReady=false;state.loadingResult=false;
  const loadedAudio=await api(`/api/audio/${id}`);if(sourceTicket!==state.sourceTicket)return;state.audio=loadedAudio;
  state.result = null; state.notes = []; state.selected = null; state.selectedIds.clear(); state.exportScope="all"; state.undo = []; state.redo = [];
  state.loadedResults.clear(); state.activeJobs.clear();
  if(!state.native){audio.src=`/api/audio/${id}/source.wav`;audio.currentTime=0;}
  else audio.removeAttribute("src"); // JUCE owns playback; do not decode a second copy in WebView.
  state.nativeTime=0;state.nativeClockAt=performance.now();state.followSuspended=false;
  if(state.native){await state.native("source",{id,restore:state.restoringNative});if(!state.restoringNative)await state.native("placement",state.audio.host_start_seconds||0);}
  $("project-title").textContent = state.audio.name;
  $("project-title").title = state.audio.name;
  $("project-meta").textContent = `${formatTime(state.audio.duration)} · ${(state.audio.sample_rate / 1000).toFixed(1)} kHz · ${state.audio.channels === 1 ? "Mono" : "Stereo"}`;
  $("audio-format").textContent = `${state.audio.sample_rate.toLocaleString()} Hz · ${state.audio.channels} channel${state.audio.channels === 1 ? "" : "s"}`;
  $("empty-state").classList.add("hidden"); $("workspace").classList.remove("hidden");
  resizeRoll();drawWave();updateTime();
  $("note-count").textContent = "No transcription selected";
  $("save-state").textContent = "Performance timing";
  status("Ready. Choose a model and transcribe.");
  await refreshSources(); await refreshJobs(); resizeRoll(); drawWave(); updateInspector(); updateTime(); setEnabled();
  $("roll-scroll").scrollTop = (HIGH - 76) * ROW;
  window.LocalMidiUI?.sourceChanged();publishNativeUi();
}
function modelName(id) { return state.models.find(model => model.id === id)?.name || "Reference MIDI"; }
function takeName(id=state.result?.id) {const job=state.jobs.find(item=>item.id===id);return job?.label||modelName(job?.backend||(id===state.result?.id?state.result?.backend:null));}
async function refreshJobs() {
  if (!state.audio) return;
  const audioId = state.audio.id;
  const items = await api(`/api/jobs?audio_id=${audioId}`);
  if (state.audio?.id !== audioId) return;
  state.jobs = items; state.activeJobs = new Set(items.filter(item => ["queued","running"].includes(item.state)).map(item => item.id));
  await window.LocalMidiUI?.refreshTakes(items);
  const active = items.find(item => item.state === "running") || items.find(item => item.state === "queued");
  $("progress-track").classList.toggle("hidden", !active);
  if (active) {
    $("progress-fill").style.width = `${Math.max(2, active.progress * 100)}%`;
    status(`${modelName(active.backend)} · ${active.message}`, "running", active.elapsed ? `${Math.round(active.elapsed)} s` : "");
  }
  const finished = items.filter(item => item.state === "complete" && !state.loadedResults.has(item.id));
  if (finished.length && !state.result) {const restored=finished.find(item=>item.id===state.restoreJobId);state.restoreJobId=null;await loadResult((restored||finished[0]).id);}
  for (const item of finished) state.loadedResults.add(item.id);
  const error = items.find(item => item.state === "error" && !state.loadedResults.has(item.id));
  if (error) { state.loadedResults.add(error.id); status(error.message, "error"); notify(`${modelName(error.backend)}: ${error.message}`); }
  if (!active && state.result && !error) status(`${modelName(state.result.backend)} · ${state.notes.length} notes · ready to edit`, "complete");
  setEnabled();
}
async function startTranscription() {
  if (!state.audio) return;
  const models = [...state.modelSelections[state.instrument]];
  $("transcribe").disabled = true;
  try {
    for (const backend of models) {
      await api("/api/jobs", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({audio_id:state.audio.id,instrument:state.instrument,backend,device:$("device").value})});
    }
    await refreshJobs();
  } catch (error) { status(error.message,"error"); notify(error.message); setEnabled(); }
}
async function loadResult(id) {
  if (state.result?.id === id && !state.loadingResult) return;
  window.LocalMidiUI?.cancelPendingGesture?.();window.LocalMidiNavigation?.cancelGesture?.();window.LocalMidiLayout?.cancelGesture?.();
  const ticket=++state.resultTicket;
  state.loadingResult=true;state.dragReady=false;window.LocalMidiUI?.update();
  try {
    if (state.result) await persistNotes();
    if(ticket!==state.resultTicket)return;
    const wasPlaying=state.playing;pause();clearTimeout(state.saveTimer);
    let result=await api('/api/jobs/'+id+'/result');
    if(ticket!==state.resultTicket||result.audio_id!==state.audio?.id)return;
    if(state.native&&state.nativeEdits.has(id))result={...result,...clone(state.nativeEdits.get(id))};
    state.result=result;state.notes=clone(result.notes);state.selected=null;state.selectedIds.clear();state.exportScope="all";
    state.undo=[];state.redo=[];state.editVersion++;state.dirty=false;
    if(state.native)rememberNativeTake(result.edited);
    state.noteEnds.clear();state.pedalTracks.clear();
    for(const control of result.controls||[]){if(control.number!==64)continue;if(!state.pedalTracks.has(control.track))state.pedalTracks.set(control.track,[]);state.pedalTracks.get(control.track).push(control);}
    for(const events of state.pedalTracks.values())events.sort((a,b)=>a.time-b.time);
    state.loadedResults.add(id);
    $("note-count").textContent=state.notes.length+" notes";
    $("roll-placeholder").classList.toggle("hidden",state.notes.length>0);
    $("roll-placeholder").textContent="This take has no notes. Double-click the roll to add one.";
    $("save-state").textContent=result.edited?(state.native?"Edits kept in this instance":"Edits saved locally"):result.backend==="reference"?"Imported MIDI":"Original prediction";
    window.LocalMidiUI?.selectionChanged(false);
    resizeRoll();updateInspector();setEnabled();
    if(state.notes.length){const pitches=state.notes.map(n=>n.pitch).sort((a,b)=>a-b);const center=pitches[Math.floor(pitches.length/2)];$("roll-scroll").scrollTop=Math.max(0,(HIGH-center)*ROW-$("roll-scroll").clientHeight/2);}
    status(modelName(result.backend)+" · "+state.notes.length+" notes · "+(result.metadata?.device||"imported"),"complete");
    if(state.native)await syncNativeTake();
    if(ticket!==state.resultTicket)return;
    publishNativeUi();
    if(wasPlaying)await play();
  } finally {if(ticket===state.resultTicket){state.loadingResult=false;window.LocalMidiUI?.update();}}
}
function checkpoint() { state.undo.push(clone(state.notes)); if (state.undo.length > 60) state.undo.shift(); state.redo = []; setEnabled(); }
function changed() {
  silenceVoices();state.noteEnds.clear();state.dragReady=false;
  state.dirty=true;
  state.editVersion++; $("note-count").textContent = `${state.notes.length} notes`;
  $("roll-placeholder").classList.toggle("hidden", state.notes.length > 0);
  $("save-state").textContent = "Saving edits…"; resizeRoll(); updateInspector(); setEnabled();
  if(state.native){rememberNativeTake(true);publishNativeUi();}
  clearTimeout(state.saveTimer); state.saveTimer = setTimeout(() => persistNotes().catch(error=>notify(error.message)),500);
}
async function persistNotes() {
  if (!state.result || !state.dirty) return;
  clearTimeout(state.saveTimer);
  const id = state.result.id, version = state.editVersion, notes = clone(state.notes);
  if(state.native){rememberNativeTake(true);state.dirty=false;$("save-state").textContent="Edits kept in this instance";publishNativeUi();await syncNativeTake();return;}
  state.saveChain=state.saveChain.catch(()=>{}).then(()=>api(`/api/jobs/${id}/notes`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({notes})}));
  await state.saveChain;
  if (state.result?.id === id && state.editVersion === version) {state.dirty=false;$("save-state").textContent = "Edits saved locally";}
  if(state.native && state.result?.id===id && state.editVersion===version)await syncNativeTake();
}
function undo() { if (state.loadingResult||!state.undo.length) return; state.redo.push(clone(state.notes)); state.notes = state.undo.pop(); state.selected = null; state.selectedIds.clear(); state.exportScope="all"; changed(); }
function redo() { if (state.loadingResult||!state.redo.length) return; state.undo.push(clone(state.notes)); state.notes = state.redo.pop(); state.selected = null; state.selectedIds.clear(); state.exportScope="all"; changed(); }
function selectedNote() { return state.notes.find(note => note.id === state.selected); }
function updateInspector() {
  const note = selectedNote(); $("inspector-empty").classList.toggle("hidden",!!note); $("inspector-fields").classList.toggle("hidden",!note);
  if (!note) {window.LocalMidiCommands?.update();return;}
  $("note-pitch").value = note.pitch; $("note-pitch").title = pitchName(note.pitch);
  $("note-start").value = note.start.toFixed(3); $("note-end").value = note.end.toFixed(3); $("note-velocity").value = note.velocity;
  $("note-duration").textContent="Duration "+(note.end-note.start).toFixed(3)+" s";
  window.LocalMidiCommands?.update();
}
function deleteSelected() {
  if(state.view==="compare"||state.loadingResult||!state.result)return;
  const ids=new Set(state.selectedIds);if(state.selected)ids.add(state.selected);if(!ids.size)return;
  checkpoint();state.notes=state.notes.filter(note=>!ids.has(note.id));state.selected=null;state.selectedIds.clear();state.exportScope="all";changed();
}
function position(event) {
  const rect=roll.getBoundingClientRect();
  return {x:event.clientX-rect.left,y:event.clientY-rect.top+$("roll-scroll").scrollTop};
}
function noteRect(note,scroll=$("roll-scroll").scrollLeft) { return {x:KEYS+note.start*state.px-scroll,y:(HIGH-note.pitch)*ROW+2,w:Math.max(3,(note.end-note.start)*state.px),h:ROW-3}; }
function hitTest(x,y) {
  if(x<KEYS)return null;
  const scroll=$("roll-scroll").scrollLeft,pitch=HIGH-Math.floor(y/ROW),time=(x+scroll-KEYS)/state.px;
  for(let i=state.notes.length-1;i>=0;i--){const note=state.notes[i];if(note.pitch!==pitch||note.start>time||note.end+3/state.px<time)continue;const r=noteRect(note,scroll);if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h)return note;}
  return null;
}
function sizeCanvas(canvas,width,height) {
  const dpr=Math.min(3,window.devicePixelRatio||1);width=Math.max(1,Math.floor(width));height=Math.max(1,Math.floor(height));
  const w=Math.round(width*dpr),h=Math.round(height*dpr);
  if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}
  const cssWidth=width+"px",cssHeight=height+"px";
  if(canvas.style.width!==cssWidth)canvas.style.width=cssWidth;
  if(canvas.style.height!==cssHeight)canvas.style.height=cssHeight;
  canvas.logicalWidth=width;canvas.logicalHeight=height;
  const context=canvas.getContext("2d");context.setTransform(dpr,0,0,dpr,0,0);return context;
}
function timelineDuration(){let end=state.audio?.duration||15;for(const note of state.notes)end=Math.max(end,note.end);return Math.max(end,window.LocalMidiOverlay?.duration?.()||0);}
function timelineGrid(width,scroll,keys=KEYS){return MidiTimelineView.ruler({px:state.px,scroll,width,keys,duration:timelineDuration(),bpm:$("bpm").value,mode:state.rulerMode});}
function timelineStep(){return timelineGrid(100,0).major;}
function drawRuler(context,width,scroll,keys=KEYS,height=RULER) {
  context.save();context.lineWidth=1;context.textAlign="left";context.textBaseline="alphabetic";
  context.fillStyle="#202328";context.fillRect(0,0,width,height);context.font="500 11px 'Inter',sans-serif";
  const caption=state.rulerMode==="bars"?Math.round(Number($("bpm").value)||120)+" BPM":"TIME";
  context.fillStyle="#9ba1ac";if(context.measureText(caption).width<=keys-12)context.fillText(caption,6,height-9);
  context.save();context.beginPath();context.rect(keys,0,width-keys,height);context.clip();
  const grid=timelineGrid(width,scroll,keys),precise=grid.major<1;
  for(const tick of grid.ticks){
    const x=Math.round(tick.x)+.5;context.strokeStyle=tick.major?"#747c89":"#3b414a";
    context.beginPath();context.moveTo(x,height-(tick.major?8:4));context.lineTo(x,height);context.stroke();
    if(tick.major){
      const label=state.rulerMode==="bars"?tick.label:formatTime(tick.time,precise);
      context.fillStyle="#e9ecf1";if(x+5>=keys+3&&x+5+context.measureText(label).width<=width-4)context.fillText(label,x+5,height-13);
    }
  }
  context.restore();
  context.fillStyle="#2a2e34";context.fillRect(0,height-1,width,1);context.fillRect(keys-1,0,1,height);
  context.restore();
}
function resizeRoll() {
  window.LocalMidiLayout?.apply?.();window.LocalMidiUI?.updateViewReadouts?.();
  const scroller=$("roll-scroll"),width=scroller.clientWidth,height=scroller.clientHeight;
  if(width<1||height<1){requestVisual("compare");return;}
  const previousHeight=roll.logicalHeight,previousTop=scroller.scrollTop;
  const spacer=$("roll-spacer"),viewport=$("roll-viewport");
  const totalWidth=Math.max(width,KEYS+timelineDuration()*state.px+35)+"px";
  if(spacer.style.width!==totalWidth)spacer.style.width=totalWidth;
  spacer.style.height=((HIGH-LOW+1)*ROW)+"px";
  viewport.style.width=width+"px";viewport.style.height=height+"px";
  sizeCanvas(roll,width,height);sizeCanvas($("roll-ruler"),width,RULER);
  if(previousHeight&&previousHeight!==height)scroller.scrollTop=Math.max(0,previousTop+(previousHeight-height)/2);
  drawRoll();
  window.LocalMidiNavigation?.update();
}
function drawRoll(){requestVisual();}
function paintRoll() {
  if($("editor-view").classList.contains("hidden")||!roll.logicalWidth)return;
  const context=roll.getContext("2d"),width=roll.logicalWidth,height=roll.logicalHeight;
  const scroller=$("roll-scroll"),scroll=scroller.scrollLeft,top=scroller.scrollTop;
  const high=Math.min(HIGH,HIGH-Math.floor(top/ROW)),low=Math.max(LOW,HIGH-Math.ceil((top+height)/ROW));
  context.save();context.lineWidth=1;context.globalAlpha=1;
  context.fillStyle="#0c0d0f";context.fillRect(0,0,width,height);
  for(let pitch=low;pitch<=high;pitch++){
    const y=(HIGH-pitch)*ROW-top;context.fillStyle=isBlack(pitch)?"#101214":"#15171a";context.fillRect(KEYS,y,width-KEYS,ROW);
    context.strokeStyle=pitch%12===0?"#353c45":"#202429";context.beginPath();context.moveTo(KEYS,Math.round(y+ROW)-.5);context.lineTo(width,Math.round(y+ROW)-.5);context.stroke();
  }
  const grid=timelineGrid(width,scroll);
  for(const tick of grid.ticks){if(!tick.major&&grid.minor*state.px<12)continue;context.strokeStyle=tick.major?"#373e47":"#23282e";context.beginPath();context.moveTo(Math.round(tick.x)+.5,0);context.lineTo(Math.round(tick.x)+.5,height);context.stroke();}
  context.save();context.beginPath();context.rect(KEYS,0,width-KEYS,height);context.clip();
  window.LocalMidiOverlay?.paint?.(context,width,height,scroll,top);
  const start=(scroll-KEYS)/state.px,end=(scroll+width-KEYS)/state.px;
  const paths=Array.from({length:8},()=>new Path2D()),borders=new Path2D(),caps=new Path2D(),handles=new Path2D(),labels=[],labelWidths=new Map();
  context.font="500 11px 'Inter',sans-serif";context.textAlign="left";context.textBaseline="middle";
  for(const note of state.notes){
    if(note.pitch<low||note.pitch>high||note.end+3/state.px<start||note.start>end)continue;
    const r=noteRect(note,scroll),y=r.y-top,selected=state.selectedIds.has(note.id)||note.id===state.selected;
    MidiCanvasGeometry.roundRect(paths[Math.max(0,Math.min(7,Math.floor(note.velocity/16)))],r.x,y,r.w,r.h,Math.min(3,r.w/2,r.h/2));
    if(r.w>=6&&r.h>=6)MidiCanvasGeometry.roundRect(caps,r.x+1,y+2,2,r.h-4,1);
    if(selected)MidiCanvasGeometry.roundRect(borders,r.x+.5,y+.5,r.w-1,r.h-1,Math.min(3,(r.w-1)/2,(r.h-1)/2));
    if(selected&&r.w>=32&&r.h>=11){handles.rect(r.x+2,y+r.h/2-3,2,6);handles.rect(r.x+r.w-4,y+r.h/2-3,2,6);}
    if(r.h>=13){
      const label=pitchName(note.pitch),x=Math.max(r.x+7,KEYS+6);
      if(!labelWidths.has(label))labelWidths.set(label,context.measureText(label).width);
      if(x+labelWidths.get(label)<=Math.min(r.x+r.w-4,width-4))labels.push([label,x,y+r.h/2]);
    }
  }
  // Opaque velocity shades keep dark labels readable at every velocity.
  for(let i=0;i<paths.length;i++){const brightness=.74+i/7*.26;context.fillStyle=`rgb(${Math.round(125*brightness)},${Math.round(223*brightness)},${Math.round(245*brightness)})`;context.fill(paths[i]);}
  context.fillStyle="#205260";context.fill(caps);context.strokeStyle="#fff0c2";context.lineWidth=1.5;context.stroke(borders);context.fillStyle="#fff0c2";context.fill(handles);context.lineWidth=1;
  context.fillStyle="#0c262d";for(const [text,x,y] of labels)context.fillText(text,x,y);
  window.LocalMidiUI?.drawLasso(context,scroll,top);context.restore();
  // One continuous white base, with black keys overlaid at 60% of its width.
  context.fillStyle="#e9ecf1";context.fillRect(0,0,KEYS,height);
  context.font="600 11px 'Inter',sans-serif";context.textAlign="right";context.textBaseline="middle";
  const blackWidth=KEYS*.6;
  for(let pitch=low;pitch<=high;pitch++){
    const y=(HIGH-pitch)*ROW-top;
    if(isBlack(pitch)){
      context.fillStyle="#202328";context.fillRect(0,y+1,blackWidth,ROW-2);
      context.fillStyle="#3b414a";context.fillRect(1,y+1,blackWidth-2,1);
      context.fillStyle="#b8bec7";context.fillRect(blackWidth,Math.round(y+ROW/2),KEYS-blackWidth,1);
    }else{
      if(pitch%12===0||pitch%12===5){context.fillStyle="#b8bec7";context.fillRect(0,Math.round(y+ROW)-1,KEYS,1);}
      if(pitch%12===0&&ROW>=13){context.fillStyle="#343b45";context.fillText(pitchName(pitch),KEYS-9,y+ROW/2);}
    }
  }
  context.fillStyle="#2a2e34";context.fillRect(KEYS-1,0,1,height);context.restore();
  drawRuler($("roll-ruler").getContext("2d"),width,scroll);
  window.LocalMidiUI?.drawVelocity();
  window.LocalMidiNavigation?.update();
}
function drawWave(){requestVisual("wave");}
function paintWave() {
  const width=wave.parentElement.clientWidth,height=wave.parentElement.clientHeight;if(!width||!height)return;
  const ctx=sizeCanvas(wave,width,height);wave.style.width="100%";wave.style.height="100%";ctx.lineWidth=1;
  ctx.fillStyle="#0c0d0f";ctx.fillRect(0,0,width,height);
  const center=Math.floor(height/2)+.5;
  ctx.strokeStyle="#2a2e34";ctx.beginPath();ctx.moveTo(0,center);ctx.lineTo(width,center);ctx.stroke();
  const peaks=state.audio?.peaks||[],peakMax=Math.max(.001,...peaks);ctx.strokeStyle="#7ddff5";ctx.beginPath();
  for(let x=0;x<width;x+=2){const a=Math.floor(x/width*peaks.length),b=Math.max(a+1,Math.floor((x+2)/width*peaks.length));let p=0;for(let i=a;i<b;i++)p=Math.max(p,peaks[i]||0);const amplitude=Math.min(1,p/peakMax)*Math.max(0,height/2-5);ctx.moveTo(x+.5,center-amplitude);ctx.lineTo(x+.5,center+amplitude);}
  ctx.stroke();
}
function placePlayhead(id,x,width,keys=0,triangle=false){
  const element=$(id);if(!element)return;
  const hidden=!state.audio||x<keys||x>width;
  if(element.hidden!==hidden)element.hidden=hidden;
  if(!hidden){const transform=`translate3d(${Math.round(x)-(triangle?5:0)}px,0,0)`;if(element.style.transform!==transform)element.style.transform=transform;}
}
function renderPlayheads(time){
  const x=KEYS+time*state.px-$("roll-scroll").scrollLeft,width=roll.logicalWidth||0;
  placePlayhead("roll-playhead",x,width,KEYS);placePlayhead("ruler-playhead",x,width,KEYS,true);
  const waveWidth=wave.logicalWidth||0;placePlayhead("wave-playhead",time/(state.audio?.duration||1)*waveWidth,waveWidth);
  window.LocalMidiUI?.renderPlayhead(time);
  window.LocalMidiNavigation?.paintPlayhead(time);
}
function followPlayback(time,force=false){
  if(!state.follow||state.followSuspended&&!force||!state.audio)return;
  const viewport=window.LocalMidiUI?.timelineViewport();if(!viewport)return;
  const {element,keys}=viewport,width=element.clientWidth-keys-16;
  const target=MidiTimelineView.followScroll({position:time,px:state.px,scroll:element.scrollLeft,width,mode:state.followMode});
  const next=Math.min(Math.max(0,element.scrollWidth-element.clientWidth),target);
  if(Math.abs(element.scrollLeft-next)>.5){element.followTarget=next;element.scrollLeft=next;if(state.view==="compare")requestVisual("compare");else drawRoll();}
}
function updateTime(){
  const text=formatTime(playbackTime(),true),total=formatTime(state.audio?.duration||0),key=text+"/"+total;
  if(key===lastTimeText)return;lastTimeText=key;
  const element=$("time-display");if(element.childNodes.length!==2){element.replaceChildren(document.createTextNode(""),document.createElement("small"));}
  element.firstChild.nodeValue=text+" ";element.lastChild.textContent="/ "+total;
}
async function ensureAudio() {
  if(state.audioContext)return;
  const AudioContext=window.AudioContext||window.webkitAudioContext;const ctx=new AudioContext();state.audioContext=ctx;
  state.originalGain=ctx.createGain();state.midiGain=ctx.createGain();state.masterGain=ctx.createGain();
  const source=ctx.createMediaElementSource(audio);source.connect(state.originalGain);state.originalGain.connect(state.masterGain);state.midiGain.connect(state.masterGain);state.masterGain.connect(ctx.destination);applyMix();
}
function applyMix(){if(state.native){state.native("mix",{mode:state.listen,blend:Number($("blend").value)/100,volume:Number($("volume").value)/100}).catch(error=>notify(error.message));publishNativeUi();return;} if(!state.audioContext)return;const blend=state.listen==="original"?0:state.listen==="midi"?1:Number($("blend").value)/100;state.originalGain.gain.value=1-blend;state.midiGain.gain.value=blend;state.masterGain.gain.value=Number($("volume").value)/100*.75; }
function silenceVoices(){for(const voice of state.voices){try{voice.stop();}catch{}}state.voices=[];state.scheduled.clear();}
function previewInstrument(){return state.result?.instrument === "guitar" ? "guitar" : "piano";}
async function prepareSamples(){
  if(state.native)return;
  if(!state.result)return;
  const instrument=previewInstrument();
  if(!state.sampleBanks[instrument])state.sampleBanks[instrument]=api(`/samples/${instrument}.json`);
  const bank=await state.sampleBanks[instrument];
  const buffers=state.sampleBuffers[instrument] ||= new Map();
  const keys=Object.keys(bank).map(Number);
  const wanted=new Set(state.notes.map(note=>keys.reduce((a,b)=>Math.abs(b-note.pitch)<Math.abs(a-note.pitch)?b:a)));
  await Promise.all([...wanted].map(async pitch=>{
    if(!buffers.has(pitch)){
      const bytes=Uint8Array.from(atob(bank[pitch].split(",")[1]),character=>character.charCodeAt(0));
      buffers.set(pitch,await state.audioContext.decodeAudioData(bytes.buffer));
    }
  }));
}
function effectiveEnd(note){if(state.noteEnds.has(note.id))return state.noteEnds.get(note.id);let end=note.end;const controls=state.pedalTracks.get(note.track)||[];let pedal=false;for(const c of controls){if(c.time<=end)pedal=c.value>=64;else if(pedal&&c.value<64){end=c.time;pedal=false;break;}else if(!pedal)break;}end=pedal?Math.max(end,state.audio.duration):end;state.noteEnds.set(note.id,end);return end;}
function synthesize(note,startAt,duration,offset=0){
  if(duration<=.005)return;
  const ctx=state.audioContext;const buffers=state.sampleBuffers[previewInstrument()];
  if(!buffers?.size)return;
  const pitch=[...buffers.keys()].reduce((a,b)=>Math.abs(b-note.pitch)<Math.abs(a-note.pitch)?b:a);
  const buffer=buffers.get(pitch);const rate=Math.pow(2,(note.pitch-pitch)/12);
  const sampleOffset=offset*rate;if(sampleOffset>=buffer.duration)return;
  const source=ctx.createBufferSource();source.buffer=buffer;source.playbackRate.value=rate;
  const gain=ctx.createGain();const peak=.8*Math.pow(note.velocity/127,1.5);
  gain.gain.setValueAtTime(peak,startAt);gain.gain.setValueAtTime(peak,startAt+duration);
  gain.gain.exponentialRampToValueAtTime(.0001,startAt+duration+.12);
  source.connect(gain);gain.connect(state.midiGain);
  source.start(startAt,sampleOffset);source.stop(startAt+duration+.13);state.voices.push(source);
  source.onended=()=>{source.disconnect();gain.disconnect();const index=state.voices.indexOf(source);if(index>=0)state.voices.splice(index,1);};
}
function scheduleMidi(){if(!state.playing||!state.result||!state.audioContext||state.listen==="original")return;const t=audio.currentTime;const now=state.audioContext.currentTime;for(const note of state.notes){const end=effectiveEnd(note);if(note.start>t+.18||end<t||state.scheduled.has(note.id))continue;state.scheduled.add(note.id);const start=Math.max(t,note.start);synthesize(note,now+Math.max(0,start-t),end-start,Math.max(0,t-note.start));}}
async function play(){
  if(!state.audio)return;if(playbackTime()>=state.audio.duration-.02)seek(0);const ticket=++state.playTicket;
  try{
    if(state.native){await state.nativeSync;if(ticket!==state.playTicket)return;applyMix();state.nativeSeekAt=performance.now();await state.native("play",{seconds:state.nativeTime,playing:true});state.nativeClockAt=performance.now();}
    else{await ensureAudio();await state.audioContext.resume();if(state.listen!=="original")await prepareSamples();if(ticket!==state.playTicket)return;silenceVoices();await audio.play();}
    if(ticket!==state.playTicket)return;state.playing=true;state.followSuspended=false;window.LocalMidiUI?.updateFollow();
    $("play").textContent="\u2161";$("play").setAttribute("aria-label","Pause");followPlayback(playbackTime(),true);scheduleMidi();requestFrame();
  }catch(error){notify("Playback could not start: "+error.message);}
}
function pause(){
  const at=playbackTime();state.playTicket++;audio.pause();state.playing=false;
  if(state.native){state.nativeTime=at;state.nativeClockAt=state.nativeSeekAt=performance.now();state.native("pause").catch(error=>notify(error.message));}
  silenceVoices();$("play").textContent="\u25b6";$("play").setAttribute("aria-label","Play");requestFrame();
}
function seek(time){
  silenceVoices();const seconds=Math.max(0,Math.min(state.audio?.duration||0,time));
  if(state.native){state.nativeTime=seconds;state.nativeClockAt=state.nativeSeekAt=performance.now();state.native("seek",{seconds,playing:state.playing}).catch(error=>notify(error.message));}
  else audio.currentTime=seconds;
  if(state.follow&&!state.followSuspended)followPlayback(seconds,true);
  requestFrame();updateTime();if(state.playing)scheduleMidi();
}
function animate(timestamp=performance.now()){
  framePending=0;
  if(document.hidden)return;
  const editing=window.LocalMidiUI?.advanceGesture(timestamp)||false;
  const navigating=window.LocalMidiNavigation?.advanceFrame?.(timestamp)||window.LocalMidiNavigation?.isInteracting?.()||false;
  const sizing=window.LocalMidiLayout?.isInteracting?.()||false;
  const interacting=editing||navigating||sizing,time=playbackTime();
  if(state.playing&&!interacting)followPlayback(time);
  if(waveDirty){waveDirty=false;paintWave();}
  if(state.view==="compare"){if(comparisonDirty){comparisonDirty=false;window.LocalMidiUI?.paintComparison();}}
  else if(rollDirty){rollDirty=false;paintRoll();}
  renderPlayheads(time);
  if(timestamp-lastClockPaint>=45||!state.playing){lastClockPaint=timestamp;updateTime();}
  if(state.playing||interacting)requestFrame();
}
setInterval(scheduleMidi,35);
function exportSettings(){return {bpm:Number($("bpm").value),quantize:$("quantize").checked,subdivision:Number($("subdivision").value),selection_only:state.exportScope==="selection",start_at_first_note:$("selection-origin").value==="start"};}
function exportNotes(){return state.exportScope==="selection"?state.notes.filter(note=>state.selectedIds.has(note.id)):state.notes;}
function dragRevision(){return JSON.stringify([state.result?.id,state.editVersion,state.exportScope,state.exportScope==="selection"?[...state.selectedIds].sort():[],exportSettings()]);}
function midiFilename(){return state.audio.name.replace(/\.[^.]+$/,"")+"-"+state.result.backend+(state.exportScope==="selection"?"-"+exportNotes().length+"-notes":"")+($("quantize").checked?"-grid":"-performance")+".mid";}

async function midiBlob(id=state.result.id,notes=exportNotes(),settings=exportSettings()){
  const response=await fetch(`/api/jobs/${id}/export`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({notes,...settings})});
  if(!response.ok){const error=await response.json();throw new Error(typeof error.detail==="string"?error.detail:JSON.stringify(error.detail));}
  return response.blob();
}
async function exportMidi(){
  if(!state.result||state.exporting)return;
  const id=state.result.id,notes=clone(exportNotes()),settings=exportSettings(),name=midiFilename();
  state.exporting=true;setEnabled();
  try{
    await persistNotes();const blob=await midiBlob(id,notes,settings);
    if(state.native){const {base64}=await import("/native-bridge.js");const result=await state.native("saveMidi",{bytes:base64(new Uint8Array(await blob.arrayBuffer())),name});if(result.cancelled)return;}
    else{const url=URL.createObjectURL(blob),link=document.createElement("a");link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);}
    status("MIDI exported · "+notes.length+" notes.","complete");
  }catch(error){notify(error.message);}finally{state.exporting=false;setEnabled();}
}

function publishNativeUi(){if(!state.native||state.restoringNative)return;state.native("ui",{
  audio_id:state.audio?.id||null,job_id:state.result?.id||null,instrument:state.instrument,
  model_selections:{piano:[...state.modelSelections.piano],guitar:[...state.modelSelections.guitar]},
  model_initialized:{piano:!!state.modelSelections.piano.initialized,guitar:!!state.modelSelections.guitar.initialized},
  listen:state.listen,volume:Number($("volume").value),blend:Number($("blend").value),device:$("device").value,
  view:state.view,zoom:state.px,show_differences:$("show-differences").checked,
  full_view:!!state.fullView,density:$("ui-density").value,follow:state.follow,follow_mode:state.followMode,ruler_mode:state.rulerMode,
  row_height:ROW,editor_snap:$("editor-snap").value,source_collapsed:document.body.classList.contains("source-collapsed"),
  ...(window.LocalMidiLayout?.getPreferences?.()||{}),...(window.LocalMidiOverlay?.getPreferences?.()||{}),
  selected_ids:[...state.selectedIds],export_scope:state.exportScope,selection_origin:$("selection-origin").value,export_options:exportSettings(),
  take_edits:Object.fromEntries(state.nativeEdits)
}).catch(error=>notify(error.message));}
function rememberNativeTake(edited=true){if(!state.native||!state.result)return;state.nativeEdits.set(state.result.id,{notes:clone(state.notes),controls:state.result.controls||[],pitch_bends:state.result.pitch_bends||[],instrument:previewInstrument(),edited:!!edited});}
async function syncNativeTake(){
  if(!state.native||!state.result)return;
  const id=state.result.id,revision=dragRevision(),notes=clone(exportNotes()),name=midiFilename();
  const payload={notes:clone(state.notes),controls:state.result.controls||[],pitch_bends:state.result.pitch_bends||[],instrument:previewInstrument()};
  const settings=exportSettings();state.dragReady=false;window.LocalMidiUI?.update();
  state.nativeSync=state.nativeSync.catch(()=>{}).then(async()=>{
    if(state.result?.id!==id||dragRevision()!==revision)return;
    await state.native("take",payload);
    if(state.result?.id!==id||dragRevision()!==revision)return;
    const {base64}=await import("/native-bridge.js");
    const bytes=base64(new Uint8Array(await (await midiBlob(id,notes,settings)).arrayBuffer()));
    if(state.result?.id!==id||dragRevision()!==revision)return;
    await state.native("prepareDrag",{bytes,name,revision});
    if(state.result?.id!==id||dragRevision()!==revision)return;
    state.preparedDragRevision=revision;state.dragReady=true;window.LocalMidiUI?.update();
  });
  await state.nativeSync;
}
async function pollNative(){
  if(!state.native||state.nativePollBusy)return;state.nativePollBusy=true;
  try{
    const requested=performance.now(),wasPlaying=state.playing;
    const current=await state.native("state");state.nativeStatus=current;
    if(requested>=(state.nativeSeekAt||0)){state.nativeTime=current.position;state.nativeClockAt=performance.now();state.playing=current.playing;}
    if(state.playing&&!wasPlaying){state.followSuspended=false;window.LocalMidiUI?.updateFollow();}
    $("play").textContent=current.playing?"Ⅱ":"▶";$("play").setAttribute("aria-label",current.playing?"Pause":"Play");
    $("host-midi").checked=current.host_midi;
    if(document.activeElement!==$("host-offset"))$("host-offset").value=current.offset.toFixed(3);
    $("host-position").textContent=current.host_position_known?`Host ${formatTime(current.host_position,true)} · ${Math.round(current.bpm)} BPM`:"Start the DAW audio engine to play";
    const capture=current.capture;const recording=capture.phase==="recording";
    $("capture-start").classList.toggle("hidden",recording);$("capture-stop").classList.toggle("hidden",!recording);
    $("capture-status").textContent=recording?(capture.seconds?`Recording ${formatTime(capture.seconds,true)}`:current.standalone?"Recording input…":"Armed · start DAW playback"):capture.phase==="ready"?"Importing capture…":"Ready to capture";
    if(capture.phase==="error"&&state.handledCapture!==capture.id){state.handledCapture=capture.id;notify(capture.error);}
    if(capture.phase==="ready"&&state.handledCapture!==capture.id){
      state.handledCapture=capture.id;pause();
      const item=await api(`/api/native/captures/${capture.id}/import`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:`Capture ${new Date().toLocaleString().replaceAll("/","-")}.wav`,host_start_seconds:capture.origin})});
      await selectAudio(item.id);await state.native("captureConsumed");status("Capture imported. Choose models and transcribe.","complete");
    }
    if(current.error&&current.error!==state.lastNativeError){state.lastNativeError=current.error;notify(current.error);}
    requestFrame();if(wasPlaying!==state.playing)window.LocalMidiUI?.update();
  }catch(error){notify(error.message);}finally{state.nativePollBusy=false;}
}

$("capture-start").onclick=async()=>{try{pause();await state.native("captureStart");await pollNative();}catch(error){notify(error.message);}};
$("capture-stop").onclick=async()=>{try{await state.native("captureStop");await pollNative();}catch(error){notify(error.message);}};
$("native-audio-settings").onclick=()=>state.native("audioSettings").catch(error=>notify(error.message));
$("host-midi").onchange=()=>state.native("hostMidi",$("host-midi").checked).catch(error=>notify(error.message));
$("host-offset").onchange=()=>state.native("placement",Number($("host-offset").value)).catch(error=>notify(error.message));
$("place-playhead").onclick=()=>state.native("placeAtPlayhead").catch(error=>notify(error.message));
// The workspace owns the native file drag gesture and selection export controls.

for(const id of ["quantize","bpm","subdivision","selection-origin"])$(id).addEventListener("change",()=>{state.dragReady=false;window.LocalMidiUI?.update();if(state.native)syncNativeTake().catch(error=>notify(error.message));publishNativeUi();});

$("import-audio").onclick=$("empty-import").onclick=()=>$("audio-file").click();
$("audio-file").onchange=()=>upload($("audio-file").files[0]);
$("transcribe").onclick=startTranscription;
$("select-all-models").onclick=()=>{const selection=state.modelSelections[state.instrument];const available=state.models.filter(model=>model.ready&&model.instruments.includes(state.instrument));if(selection.size===available.length)selection.clear();else for(const model of available)selection.add(model.id);updateModelOptions();publishNativeUi();};
document.querySelectorAll("[data-instrument]").forEach(button=>button.onclick=()=>{state.instrument=button.dataset.instrument;document.querySelectorAll("[data-instrument]").forEach(b=>b.classList.toggle("active",b===button));updateModelOptions();publishNativeUi();});
$("cancel-job").onclick=async()=>{for(const id of state.activeJobs)await api(`/api/jobs/${id}/cancel`,{method:"POST"});await refreshJobs();status("Transcription cancelled.");};
$("play").onclick=()=>state.playing?pause():play();$("stop").onclick=()=>{pause();seek(0);};
audio.onended=()=>{pause();drawWave();drawRoll();updateTime();};
document.querySelectorAll("[data-listen]").forEach(button=>button.onclick=async()=>{state.listen=button.dataset.listen;document.querySelectorAll("[data-listen]").forEach(b=>b.classList.toggle("active",b===button));$("blend-control").classList.toggle("hidden",state.listen!=="blend");silenceVoices();applyMix();if(state.playing&&state.listen!=="original"){try{await prepareSamples();scheduleMidi();}catch(error){notify("MIDI preview could not load: "+error.message);}}});
$("blend").oninput=$("volume").oninput=applyMix;
$("zoom").oninput=()=>{state.px=Number($("zoom").value);resizeRoll();window.LocalMidiUI?.drawComparison();publishNativeUi();};
$("roll-scroll").onscroll=()=>{drawRoll();requestFrame();};
wave.onclick=event=>{if(state.audio)seek((event.clientX-wave.getBoundingClientRect().left)/wave.clientWidth*state.audio.duration);};
// Note movement, multi-selection and lasso gestures are handled in workspace.js.

for(const [id,key]of [["note-pitch","pitch"],["note-start","start"],["note-end","end"],["note-velocity","velocity"]])$(id).onchange=()=>{const note=selectedNote();if(!note||state.loadingResult||state.view==="compare"){updateInspector();return;}const value=Number($(id).value);const next={...note,[key]:value};if(!Number.isFinite(value)||next.start<0||next.end<=next.start||next.pitch<0||next.pitch>127||next.velocity<1||next.velocity>127){notify("Use valid pitch, velocity and a positive note duration.");updateInspector();return;}checkpoint();note[key]=["pitch","velocity"].includes(key)?Math.round(value):value;changed();};
$("delete-note").onclick=deleteSelected;$("undo").onclick=undo;$("redo").onclick=redo;
$("restore").onclick=async()=>{
  if(!state.result||state.loadingResult)return;
  const id=state.result.id,ticket=state.resultTicket;
  pause();
  try{
    await state.saveChain;
    if(state.result?.id!==id||state.resultTicket!==ticket)return;
    checkpoint();clearTimeout(state.saveTimer);
    const original=await api(`/api/jobs/${id}/${state.native?"prediction":"restore"}`,{method:state.native?"GET":"POST"});
    if(state.result?.id!==id||state.resultTicket!==ticket)return;
    state.notes=clone(original.notes);state.selected=null;state.selectedIds.clear();state.exportScope="all";changed();
    clearTimeout(state.saveTimer);state.dirty=false;$("save-state").textContent=state.result.backend==="reference"?"Imported MIDI":"Original prediction";
    if(state.native){rememberNativeTake(false);publishNativeUi();await syncNativeTake();}
  }catch(error){if(state.result?.id===id&&state.resultTicket===ticket)notify(error.message);}
};
$("export-midi").onclick=exportMidi;
$("import-reference").onclick=()=>$("reference-file").click();
async function importReference(file){
  if(!file||!state.audio){if(file)notify("Import source audio before a reference MIDI.");return;}
  const body=new FormData();body.append("file",file);body.append("instrument",state.instrument);
  try{const job=await api('/api/audio/'+state.audio.id+'/reference',{method:"POST",body});await loadResult(job.id);await refreshJobs();}catch(error){notify(error.message);}
}
$("reference-file").onchange=async()=>{await importReference($("reference-file").files[0]);$("reference-file").value="";};

document.addEventListener("keydown",event=>{
  if(event.defaultPrevented||event.isComposing||event.target.isContentEditable||event.target.closest?.('[role="slider"],[role="separator"]')||["INPUT","SELECT","TEXTAREA"].includes(event.target.tagName))return;
  if(event.code==="Space"){
    if(event.target.closest?.('button,summary,a[href],[role="button"],[role="slider"],[role="tab"],[role="menuitem"]'))return;
    event.preventDefault();state.playing?pause():play();
  }
  if(["Delete","Backspace"].includes(event.key)){event.preventDefault();deleteSelected();}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="z"){event.preventDefault();event.shiftKey?redo():undo();}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="y"){event.preventDefault();redo();}
});
let dragDepth=0;document.addEventListener("dragenter",event=>{event.preventDefault();if(event.dataTransfer.types.includes("Files")){dragDepth++;document.body.classList.add("dragging");}});document.addEventListener("dragover",event=>event.preventDefault());document.addEventListener("dragleave",()=>{if(--dragDepth<=0){dragDepth=0;document.body.classList.remove("dragging");}});document.addEventListener("drop",event=>{event.preventDefault();dragDepth=0;document.body.classList.remove("dragging");const file=event.dataTransfer.files[0];if(file&&/\.midi?$/i.test(file.name))importReference(file);else upload(file);});
window.addEventListener("resize",()=>{resizeRoll();drawWave();});
document.addEventListener("visibilitychange",()=>{if(!document.hidden){resizeRoll();drawWave();requestFrame();}});
document.fonts?.ready.then(()=>drawRoll());
setInterval(()=>{if(state.audio)refreshJobs().catch(error=>{if(!document.hidden)status("Connection interrupted. Keep the local server running.","error");});},1500);
async function initialize(){try{
  state.native=await (await import("/native-bridge.js")).createNativeBridge();
  let saved={};
  if(state.native){
    state.restoringNative=true;const native=await state.native("state",{include_ui:true});saved=native.ui||{};
    document.body.classList.add("is-native");document.body.classList.toggle("is-plugin",!native.standalone);$("capture-status").classList.remove("hidden");
    if(saved.take_edits&&typeof saved.take_edits==="object")for(const [id,take] of Object.entries(saved.take_edits))if(Array.isArray(take.notes))state.nativeEdits.set(id,take);
    $("native-panel").classList.remove("hidden");$("host-controls").classList.toggle("hidden",native.standalone);
    $("native-audio-settings").classList.toggle("hidden",!native.standalone);
    $("native-edition").textContent=native.standalone?"JUCE STANDALONE":"VST3 · DAW";
    $("capture-start").innerHTML='<span class="record-dot"></span>Capture new';$("capture-start").title=native.standalone?"Capture the selected audio input":"Capture the audio passing through this plug-in";
    document.querySelector(".edition").textContent=native.standalone?"STANDALONE":"VST3 WORKSPACE";
    state.instrument=saved.instrument==="guitar"?"guitar":"piano";state.restoreJobId=saved.job_id;
    for(const type of ["piano","guitar"]){if(Array.isArray(saved.model_selections?.[type])&&(saved.model_initialized?.[type]??saved.model_selections[type].length>0)){state.modelSelections[type]=new Set(saved.model_selections[type]);state.modelSelections[type].initialized=true;}}
    document.querySelectorAll("[data-instrument]").forEach(button=>button.classList.toggle("active",button.dataset.instrument===state.instrument));
    if(saved.volume!=null)$("volume").value=saved.volume;if(saved.blend!=null)$("blend").value=saved.blend;if(saved.device)$("device").value=saved.device;
  }
  const info=await api("/api/status");state.models=info.models;const gpu=info.hardware;
  $("gpu-status").textContent=gpu?.cuda?`${gpu.gpu_name} · ${gpu.vram_gib} GB · Auto uses GPU`:"CPU mode · no compatible CUDA GPU detected";
  if(!gpu?.cuda)$("device").querySelector('[value="cuda"]').disabled=true;
  state.hardware=gpu;window.LocalMidiUI?.update();updateModelOptions();await refreshSources();const sources=await api("/api/audio");
  const source=state.native?sources.find(item=>item.id===saved.audio_id):sources[0];if(source)await selectAudio(source.id);
  if(state.native){
    state.restoringNative=false;window.LocalMidiUI?.restore(saved);
    if(["midi","blend"].includes(saved.listen))await document.querySelector(`[data-listen="${saved.listen}"]`).onclick();else applyMix();
    publishNativeUi();setInterval(pollNative,200);await pollNative();
  }
}catch(error){status(error.message,"error");notify(error.message);}requestFrame();}
// Deferred editor modules must be ready before native workspace preferences restore.
if(document.readyState==="complete")initialize();
else document.addEventListener("DOMContentLoaded",initialize,{once:true});


