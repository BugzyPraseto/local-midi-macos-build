"use strict";
// Timeline math shared by the renderer, playback follower and regression tests.
(function(root){
  function timeStep(px){return [.1,.25,.5,1,2,5,10,15,30,60,120,300,600].find(step=>step*px>=65)||600;}
  function ruler({px,scroll,width,keys=48,duration=Infinity,bpm=120,mode="time"}){
    bpm=Math.max(20,Math.min(400,Number(bpm)||120));
    const beat=60/bpm,bar=beat*4;
    let major=mode==="bars"?bar:timeStep(px);
    if(mode==="bars")while(major*px<65)major*=2;
    let minor=major/4;while(minor*px<9)minor*=2;
    const start=Math.max(0,Math.floor(scroll/px/minor)),end=Math.floor(Math.min(duration,(scroll+width-keys)/px)/minor),ticks=[];
    for(let i=start;i<=end;i++){
      const time=i*minor,isMajor=Math.abs(time/major-Math.round(time/major))<1e-6;
      const beats=time/beat,barNumber=Math.floor(beats/4+1e-6)+1,beatNumber=Math.floor(beats%4+1e-6)+1;
      ticks.push({time,x:keys+time*px-scroll,major:isMajor,label:mode==="bars"?barNumber+"."+beatNumber:null});
    }
    return {ticks,major,minor,bpm};
  }
  function followScroll({position,px,scroll,width,mode="page"}){
    if(width<=0)return Math.max(0,scroll);
    const at=Math.max(0,position)*px;
    if(mode==="smooth")return Math.max(0,at-width*.3);
    const margin=Math.min(40,width*.12);
    return at<scroll||at>scroll+width-margin?Math.max(0,at-width*.15):scroll;
  }
  function interpolate({position,received,playing,now,duration=Infinity}){
    const elapsed=playing?Math.max(0,Math.min(.35,(now-received)/1000)):0;
    return Math.max(0,Math.min(duration,(Number(position)||0)+elapsed));
  }
  const api={timeStep,ruler,followScroll,interpolate};root.MidiTimelineView=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
