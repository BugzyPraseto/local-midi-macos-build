"""Portable binary-header checks, including universal payloads with different slice targets."""
import importlib.util
from pathlib import Path
import struct

import pytest

SPEC = importlib.util.spec_from_file_location("macho_audit", Path(__file__).resolve().parents[1] / "scripts/audit_macos_payload.py")
audit = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(audit)


def thin(cpu, minimum=(12, 0, 0), platform=1, endian="<", legacy=False):
    number = (minimum[0] << 16) | (minimum[1] << 8) | minimum[2]
    command = struct.pack(endian + "IIII", 0x24, 16, number, number) if legacy else struct.pack(endian + "IIIIII", 0x32, 24, platform, number, number, 0)
    return struct.pack(endian + "IIIIIIII", 0xFEEDFACF, cpu, 0, 6, 1, len(command), 0, 0) + command


def universal(parts, large=False):
    stride = 32 if large else 20
    offset = 8 + len(parts) * stride
    header = struct.pack(">II", 0xCAFEBABF if large else 0xCAFEBABE, len(parts))
    payload = b""
    for cpu, data in parts:
        header += struct.pack(">IIQQII", cpu, 0, offset, len(data), 0, 0) if large else struct.pack(">IIIII", cpu, 0, offset, len(data), 0)
        offset += len(data)
        payload += data
    return header + payload


@pytest.mark.parametrize("cpu,name", [(0x01000007, "x86_64"), (0x0100000C, "arm64")])
@pytest.mark.parametrize("endian,legacy", [("<", False), (">", False), ("<", True)])
def test_thin_cpu_and_real_os_minimum(cpu, name, endian, legacy):
    result = audit.audit_binary(thin(cpu, (11, 3, 1), endian=endian, legacy=legacy), name, (12, 0))
    assert result == {"architecture": name, "minimum_macos": [11, 3, 1]}


@pytest.mark.parametrize("large", [False, True])
def test_only_the_selected_universal_slice_controls_runtime_compatibility(large):
    data = universal([(0x01000007, thin(0x01000007, (11, 0, 0))),
                      (0x0100000C, thin(0x0100000C, (14, 0, 0)))], large)
    assert audit.audit_binary(data, "x86_64", (12, 0))["minimum_macos"] == [11, 0, 0]
    with pytest.raises(ValueError, match="requires macOS 14"):
        audit.audit_binary(data, "arm64", (12, 0))


def test_wrong_cpu_ios_and_missing_deployment_are_rejected():
    with pytest.raises(ValueError, match="x86_64 slice"):
        audit.audit_binary(thin(0x0100000C), "x86_64", (12, 0))
    with pytest.raises(ValueError, match="macOS deployment"):
        audit.audit_binary(thin(0x01000007, platform=2), "x86_64", (12, 0))
    data = struct.pack("<IIIIIIII", 0xFEEDFACF, 0x01000007, 0, 6, 0, 0, 0, 0)
    with pytest.raises(ValueError, match="macOS deployment"):
        audit.audit_binary(data, "x86_64", (12, 0))


def test_malformed_commands_and_fat_boundaries_are_rejected():
    with pytest.raises(ValueError, match="Truncated"):
        audit.macho_slices(b"\xcf\xfa\xed\xfe")
    broken = bytearray(thin(0x01000007))
    struct.pack_into("<I", broken, 36, 4)
    with pytest.raises(ValueError, match="size"):
        audit.macho_slices(broken)
    data = bytearray(universal([(0x01000007, thin(0x01000007))]))
    struct.pack_into(">I", data, 16, len(data) + 1)
    with pytest.raises(ValueError, match="escaped"):
        audit.macho_slices(data)


def test_non_code_is_ignored():
    assert audit.audit_binary(b"ordinary Python or JSON", "arm64", (12, 0)) is None
