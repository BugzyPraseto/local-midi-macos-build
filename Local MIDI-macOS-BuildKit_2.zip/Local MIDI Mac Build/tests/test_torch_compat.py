"""The old runtime bridge restores only its own API names and kernel flags."""
from contextlib import contextmanager
from enum import Enum
import sys
from types import ModuleType, SimpleNamespace

import pytest

from localmidi.torch_compat import model_api


class Backend(Enum):
    MATH = 1
    FLASH_ATTENTION = 2
    EFFICIENT_ATTENTION = 3
    ERROR = 4


def legacy_torch():
    flags = {"enable_flash": False, "enable_math": True, "enable_mem_efficient": False}
    @contextmanager
    def kernel(**selected):
        before = flags.copy()
        flags.update(selected)
        try:
            yield
        finally:
            flags.update(before)
    value = SimpleNamespace(__version__="2.2.2+cpu", nn=SimpleNamespace(),
                            backends=SimpleNamespace(cuda=SimpleNamespace(SDPBackend=Backend, sdp_kernel=kernel)),
                            is_autocast_enabled=lambda: False,
                            is_autocast_cpu_enabled=lambda: True,
                            get_autocast_cpu_dtype=lambda: "bfloat16", get_autocast_gpu_dtype=lambda: "float16")
    return value, flags


def test_current_runtime_is_untouched():
    attention = object()
    dtype = lambda device: device
    torch = SimpleNamespace(__version__="2.5.1", nn=SimpleNamespace(attention=attention), get_autocast_dtype=dtype)
    before = dict(vars(torch))
    with model_api(torch) as report:
        assert report == {"torch": "2.5.1", "legacy_bridge": False}
        assert vars(torch) == before
    assert vars(torch) == before and torch.nn.attention is attention


def test_old_namespace_and_autocast_map_to_existing_runtime_operations():
    torch, flags = legacy_torch()
    original_enabled = torch.is_autocast_enabled
    with model_api(torch) as report:
        assert report["legacy_bridge"]
        attention = torch.nn.attention
        assert sys.modules["torch.nn.attention"] is attention
        assert attention.SDPBackend is Backend
        assert torch.is_autocast_enabled() is False
        assert torch.is_autocast_enabled("cuda") is False
        assert torch.is_autocast_enabled("cpu") is True
        assert torch.get_autocast_dtype("cpu") == "bfloat16"
        assert torch.get_autocast_dtype("cuda") == "float16"
        with attention.sdpa_kernel(Backend.FLASH_ATTENTION):
            assert flags == {"enable_flash": True, "enable_math": False, "enable_mem_efficient": False}
        assert flags == {"enable_flash": False, "enable_math": True, "enable_mem_efficient": False}
        with attention.sdpa_kernel([Backend.MATH, Backend.EFFICIENT_ATTENTION]):
            assert flags == {"enable_flash": False, "enable_math": True, "enable_mem_efficient": True}
        with attention.sdpa_kernel([]):
            assert not any(flags.values())
    assert torch.is_autocast_enabled is original_enabled
    assert not hasattr(torch, "get_autocast_dtype") and not hasattr(torch.nn, "attention")
    assert not hasattr(torch, "_localmidi_model_api_active")


def test_nested_context_and_failure_restore_existing_names_without_unloading_imports(monkeypatch):
    torch, flags = legacy_torch()
    previous_attention = object()
    previous_module = ModuleType("prior_attention")
    torch.nn.attention = previous_attention
    monkeypatch.setitem(sys.modules, "torch.nn.attention", previous_module)
    new_module = ModuleType("unrelated_import_during_inference")
    with pytest.raises(RuntimeError, match="fixture"):
        with model_api(torch):
            outer = torch.nn.attention
            with model_api(torch):
                assert torch.nn.attention is outer
            assert torch.nn.attention is outer
            monkeypatch.setitem(sys.modules, new_module.__name__, new_module)
            with outer.sdpa_kernel(Backend.FLASH_ATTENTION):
                raise RuntimeError("fixture")
    assert torch.nn.attention is previous_attention
    assert sys.modules["torch.nn.attention"] is previous_module
    assert sys.modules[new_module.__name__] is new_module
    assert flags == {"enable_flash": False, "enable_math": True, "enable_mem_efficient": False}


@pytest.mark.parametrize("version", ["2.1.2", "1.13.0", "unknown"])
def test_untested_missing_api_runtime_is_rejected(version):
    torch = SimpleNamespace(__version__=version, nn=SimpleNamespace())
    with pytest.raises(RuntimeError):
        with model_api(torch):
            pytest.fail("Unsupported runtime entered inference")


def test_unsupported_kernel_and_device_requests_are_not_silently_changed():
    torch, flags = legacy_torch()
    with model_api(torch):
        for operation in (lambda: torch.nn.attention.sdpa_kernel(Backend.ERROR).__enter__(),
                          lambda: torch.is_autocast_enabled("mps"),
                          lambda: torch.get_autocast_dtype("invalid")):
            with pytest.raises(ValueError):
                operation()
        assert flags == {"enable_flash": False, "enable_math": True, "enable_mem_efficient": False}
