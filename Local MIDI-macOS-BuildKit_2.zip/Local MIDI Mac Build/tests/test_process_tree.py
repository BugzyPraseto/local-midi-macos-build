"""Regression check: Windows venv launchers must not orphan GPU workers."""
import ctypes
from ctypes import wintypes
import os
import subprocess
import sys
import time

import pytest

from localmidi.jobs import terminate_process_tree


@pytest.mark.skipif(os.name != "nt", reason="Windows venv process-tree regression")
def test_cancellation_terminates_real_python_descendant(tmp_path):
    marker = tmp_path / "leaf.pid"
    leaf = "import os,sys,time;from pathlib import Path;Path(sys.argv[1]).write_text(str(os.getpid()));time.sleep(60)"
    parent = "import subprocess,sys;subprocess.run([sys.executable,'-c',sys.argv[1],sys.argv[2]])"
    process = subprocess.Popen([sys.executable, "-c", parent, leaf, str(marker)],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               creationflags=subprocess.CREATE_NO_WINDOW)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = None
    try:
        deadline = time.monotonic() + 5
        while not marker.exists() and time.monotonic() < deadline:
            time.sleep(.02)
        assert marker.exists(), "Test child never started"
        handle = kernel.OpenProcess(0x00100000, False, int(marker.read_text()))
        assert handle, "Could not observe test descendant"
        terminate_process_tree(process)
        process.wait(timeout=5)
        assert kernel.WaitForSingleObject(handle, 3000) == 0, "Real Python descendant outlived cancellation"
    finally:
        terminate_process_tree(process)
        if handle:
            kernel.CloseHandle(handle)
