"""Portable checks for Mac runtime isolation; no Mac binaries or services run."""
import importlib.util
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

import pytest

import engine
from localmidi import jobs, runtime


def test_mac_environment_keeps_all_writes_outside_shared_engine(tmp_path):
    root, home = tmp_path / "Shared Engine", tmp_path / "User Name"
    env = engine.managed_environment(root, {"PYTHONHOME": "/host/python", "PYTHONPATH": "/daw/modules",
                                          "DYLD_LIBRARY_PATH": "/daw/libs", "VIRTUAL_ENV": "/other/venv"}, "darwin", home)
    assert Path(env["LOCALMIDI_DATA"]) == home / "Library/Application Support/Local MIDI"
    assert Path(env["LOCALMIDI_CACHE"]) == home / "Library/Caches/Local MIDI"
    assert Path(env["LOCALMIDI_LOGS"]) == home / "Library/Logs/Local MIDI"
    assert Path(env["LOCALMIDI_MODELS"]) == root / ".models"
    assert env["PYTHONDONTWRITEBYTECODE"] == "1"
    assert not {"PYTHONHOME", "PYTHONPATH", "VIRTUAL_ENV", "DYLD_LIBRARY_PATH"}.intersection(env)
    assert Path(env["MPLCONFIGDIR"]).is_relative_to(home)
    assert Path(env["NUMBA_CACHE_DIR"]).is_relative_to(home)


def test_explicit_mac_paths_survive_environment_isolation(tmp_path):
    values = {name: str(tmp_path / name) for name in ("LOCALMIDI_DATA", "LOCALMIDI_MODELS", "LOCALMIDI_CACHE", "LOCALMIDI_LOGS")}
    assert values.items() <= engine.managed_environment(tmp_path, values, "darwin", tmp_path).items()


def test_windows_runtime_defaults_are_unchanged(tmp_path):
    env = engine.managed_environment(tmp_path, {}, "win32", tmp_path / "user")
    assert Path(env["LOCALMIDI_DATA"]) == tmp_path / ".local"
    assert Path(env["LOCALMIDI_MODELS"]) == tmp_path / ".models"


def test_mac_subprocesses_use_isolated_absolute_entry(monkeypatch):
    monkeypatch.setattr(runtime.sys, "platform", "darwin")
    command = runtime.module_command("localmidi.worker", "a" * 32)
    assert command[:3] == [runtime.sys.executable, "-I", "-B"]
    assert Path(command[3]).is_absolute() and Path(command[3]).name == "engine.py"
    assert command[4:] == ["worker", "a" * 32]


def test_windows_module_command_is_preserved(monkeypatch):
    monkeypatch.setattr(runtime.sys, "platform", "win32")
    assert runtime.module_command("localmidi.probe") == [runtime.sys.executable, "-m", "localmidi.probe"]


def test_mac_initialize_does_not_create_shared_model_directory(monkeypatch, tmp_path):
    monkeypatch.setattr(engine.sys, "platform", "darwin")
    monkeypatch.setenv("LOCALMIDI_DATA", str(tmp_path / "User Data"))
    monkeypatch.delenv("LOCALMIDI_MODELS", raising=False)
    spec = importlib.util.spec_from_file_location("isolated_mac_paths", Path(engine.ROOT) / "localmidi/paths.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.MODELS = tmp_path / "Read-only Engine" / ".models"
    module.initialize()
    assert (module.DATA / "audio").is_dir() and (module.DATA / "jobs").is_dir()
    assert not module.MODELS.exists()


@pytest.mark.parametrize("value", [None, -1, 0, True, "42", {"pid": 42, "root": "/another", "data": "/another"}])
def test_invalid_or_foreign_pid_record_is_rejected(monkeypatch, tmp_path, value):
    monkeypatch.setenv("LOCALMIDI_DATA", str(tmp_path))
    engine.pid_file().write_text(json.dumps(value if isinstance(value, dict) else {"pid": value}), encoding="utf-8")
    assert engine.read_pid() is None


def test_worker_dispatch_preserves_job_id_without_shell_parsing(monkeypatch):
    calls = []
    monkeypatch.setattr(engine, "configure", lambda: {})
    monkeypatch.setattr(engine.runpy, "run_module", lambda name, run_name: calls.append((name, run_name, list(engine.sys.argv))))
    monkeypatch.setattr(engine.sys, "argv", ["engine.py"])
    engine.main(["worker", "a" * 32])
    assert calls == [("localmidi.worker", "__main__", ["localmidi.worker", "a" * 32])]
    with pytest.raises(SystemExit):
        engine.main(["probe", "unexpected"])


@pytest.mark.parametrize("parent_times_out", [False, True])
def test_posix_cancellation_kills_descendants_even_if_leader_exits(monkeypatch, parent_times_out):
    calls = []
    monkeypatch.setattr(jobs, "os", SimpleNamespace(name="posix", killpg=lambda pid, sig: calls.append((pid, sig))))
    monkeypatch.setattr(jobs, "signal", SimpleNamespace(SIGTERM=15, SIGKILL=9))
    class Process:
        pid = 1234
        def poll(self): return None
        def wait(self, timeout):
            assert timeout == 3
            if parent_times_out:
                raise subprocess.TimeoutExpired("worker", timeout)
    jobs.terminate_process_tree(Process())
    assert calls == [(1234, 15), (1234, 9)]
