const test=require('node:test');
const assert=require('node:assert/strict');
const timeline=require('../static/timeline.js');

test('page follow keeps playback visible and leaves a useful lead-in',()=>{
  assert.equal(timeline.followScroll({position:4,px:100,scroll:0,width:600}),0);
  assert.equal(timeline.followScroll({position:6,px:100,scroll:0,width:600}),510);
  assert.equal(timeline.followScroll({position:0,px:100,scroll:510,width:600}),0);
  assert.equal(timeline.followScroll({position:10,px:100,scroll:0,width:600,mode:'smooth'}),820);
});
test('ruler exposes bar/beat labels, subdivisions and correct scrolled positions',()=>{
  const grid=timeline.ruler({px:100,scroll:0,width:1000,bpm:120,mode:'bars',duration:10});
  assert.deepEqual(grid.ticks.filter(t=>t.major).slice(0,3).map(t=>[t.time,t.label]),[[0,'1.1'],[2,'2.1'],[4,'3.1']]);
  const scrolled=timeline.ruler({px:100,scroll:250,width:700,bpm:120,mode:'bars',duration:10});
  assert.equal(scrolled.ticks.find(t=>t.time===4).x,198);
  assert.ok(grid.ticks.length>grid.ticks.filter(t=>t.major).length);
});
test('native playhead interpolates between reports and freezes when reports stop',()=>{
  const at=now=>timeline.interpolate({position:10,received:1000,playing:true,now,duration:30});
  assert.equal(at(1050),10.05);assert.equal(at(1100),10.1);assert.equal(at(5000),10.35);
  assert.equal(timeline.interpolate({position:29.95,received:1000,playing:true,now:1100,duration:30}),30);
  assert.equal(timeline.interpolate({position:10,received:1000,playing:false,now:1200}),10);
});
