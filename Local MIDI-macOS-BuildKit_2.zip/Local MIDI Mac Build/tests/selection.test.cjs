const {test}=require('node:test');
const assert=require('node:assert/strict');
const {intersects,select}=require('../static/selection.js');
test('lasso selects an intersecting note even when no corners are inside',()=>{
  const strip=[{x:-5,y:4},{x:15,y:4},{x:15,y:6},{x:-5,y:6}];
  assert.equal(intersects(strip,{x:0,y:0,w:10,h:10}),true);
  assert.equal(intersects(strip,{x:0,y:8,w:10,h:2}),false);
});
test('concave freehand lasso keeps its notch unselected',()=>{
  const lasso=[{x:0,y:0},{x:10,y:0},{x:10,y:3},{x:3,y:3},{x:3,y:10},{x:0,y:10}];
  assert.equal(intersects(lasso,{x:5,y:5,w:2,h:2}),false);
  assert.equal(intersects(lasso,{x:1,y:5,w:1,h:2}),true);
  assert.equal(intersects(lasso,{x:2,y:2,w:4,h:4}),true);
});
test('note selection uses the same pitch and time coordinates as the editor',()=>{
  const notes=[{id:'inside',start:1,end:2,pitch:60},{id:'other-pitch',start:1,end:2,pitch:64},{id:'other-time',start:5,end:6,pitch:60}];
  const polygon=[{x:150,y:960},{x:270,y:960},{x:270,y:980},{x:150,y:980}];
  const before=JSON.stringify(notes);
  assert.deepEqual(select(notes,polygon,{px:100,row:14,high:127,keys:60,ruler:25}),['inside']);
  assert.equal(JSON.stringify(notes),before);
});
