"""Portable installer-structure tests; these never run Mac tools or install files."""
import importlib.util
import io
import json
import plistlib
from pathlib import Path
import tarfile
from types import SimpleNamespace
import xml.etree.ElementTree as ET
import zipfile

import pytest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("macos_packaging", ROOT / "native/macos/build_installer.py")
packaging = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(packaging)


def member(name, kind=tarfile.REGTYPE, target=""):
    result = tarfile.TarInfo(name)
    result.type = kind
    result.linkname = target
    return result


def test_payload_locations_do_not_include_user_data(tmp_path):
    paths = packaging.payload_paths(tmp_path)
    assert paths["app"] == tmp_path / "Applications/Local MIDI.app"
    assert paths["vst3"] == tmp_path / "Library/Audio/Plug-Ins/VST3/Local MIDI.vst3"
    assert paths["engine"] == tmp_path / "Library/Application Support/Local MIDI/Engine"
    assert all(packaging.inside(path, tmp_path) for path in paths.values())
    plan = packaging.installation_plan("0.2.0")
    assert plan["user_data"].startswith("~/Library/")
    assert plan["user_cache"].startswith("~/Library/Caches/")
    assert plan["user_logs"].startswith("~/Library/Logs/")
    assert plan["architecture"] == "arm64" and plan["minimum_macos"] == "12.0"
    assert plan["inference"] == "CPU" and not plan["installer_runs_engine_as_root"]


@pytest.mark.parametrize("system,machine,version,translated", [
    ("Windows", "AMD64", "", False), ("Linux", "aarch64", "", False),
    ("Darwin", "ppc", "15.0", False), ("Darwin", "arm64", "11.7", False),
    ("Darwin", "arm64", "15.0", True), ("Darwin", "arm64", "unknown", False),
])
def test_unsupported_build_hosts_fail_before_any_tools(system, machine, version, translated):
    with pytest.raises(ValueError):
        packaging.validate_host(system, machine, version, translated)


def test_supported_native_apple_silicon_host():
    packaging.validate_host("Darwin", "arm64", "12.0")
    packaging.validate_host("Darwin", "arm64", "13.7")
    packaging.validate_host("Darwin", "arm64", "14.0")
    packaging.validate_host("Darwin", "arm64", "26.0.1")


def test_signing_requires_matching_developer_id_pair():
    app = "Developer ID Application: Example (TEAMID)"
    installer = "Developer ID Installer: Example (TEAMID)"
    packaging.validate_signing(None, None, None)
    packaging.validate_signing(app, installer, None)
    packaging.validate_signing(app, installer, "existing-keychain-profile")
    for values in ((app, None, None), (None, installer, None), (None, None, "profile"),
                   ("adhoc", installer, None), (app, "self signed", None)):
        with pytest.raises(ValueError):
            packaging.validate_signing(*values)


@pytest.mark.parametrize("entry", [
    member("/etc/passwd"), member("../outside"), member("python/../../outside"),
    member("python\\outside"), member("other/bin/python3"), member("python/socket", tarfile.FIFOTYPE),
    member("python/device", tarfile.CHRTYPE),
    member("python/bin/python3", tarfile.SYMTYPE, "/usr/bin/python3"),
    member("python/bin/python3", tarfile.SYMTYPE, "../../../outside"),
    member("python/bin/python3", tarfile.LNKTYPE, "../outside"),
])
def test_archive_rejects_paths_links_and_special_files(entry):
    with pytest.raises(ValueError):
        packaging.validate_tar_members([entry])


def test_archive_rejects_indirect_escape_cycles_and_duplicates():
    indirect = [member("python/a", tarfile.SYMTYPE, "b"),
                member("python/b", tarfile.SYMTYPE, "../../outside"), member("python/a/file")]
    cycle = [member("python/a", tarfile.SYMTYPE, "b"), member("python/b", tarfile.SYMTYPE, "a")]
    for records in (indirect, cycle, [member("python/file"), member("python/file")]):
        with pytest.raises(ValueError):
            packaging.validate_tar_members(records)


def test_archive_accepts_relocatable_relative_interpreter_links():
    records = [member("python", tarfile.DIRTYPE), member("python/bin", tarfile.DIRTYPE),
               member("python/bin/python3.12"), member("python/bin/python3", tarfile.SYMTYPE, "python3.12"),
               member("python/lib/libpython3.12.dylib"),
               member("python/lib/libpython3.dylib", tarfile.SYMTYPE, "libpython3.12.dylib"),
               member("python/bin/python", tarfile.LNKTYPE, "python/bin/python3.12")]
    assert packaging.validate_tar_members(records) is records


def test_extraction_preserves_files_and_refuses_runtime_merging(tmp_path):
    archive = tmp_path / "runtime.tar.gz"
    data = b"a fixture, not a runnable interpreter"
    with tarfile.open(archive, "w:gz") as stream:
        item = member("python/bin/python3")
        item.size = len(data)
        item.mode = 0o755
        stream.addfile(item, io.BytesIO(data))
    runtime = tmp_path / "engine/runtime"
    runtime.parent.mkdir()
    packaging.extract_python(archive, runtime)
    assert (runtime / "bin/python3").read_bytes() == data
    with pytest.raises(FileExistsError):
        packaging.extract_python(archive, runtime)


def test_unsafe_archive_is_rejected_before_payload_is_extracted(tmp_path):
    archive = tmp_path / "bad.tar.gz"
    with tarfile.open(archive, "w:gz") as stream:
        item = member("python/../../escaped")
        item.size = 5
        stream.addfile(item, io.BytesIO(b"never"))
    with pytest.raises(ValueError):
        packaging.extract_python(archive, tmp_path / "runtime")
    assert not (tmp_path / "escaped").exists()
    assert not (tmp_path / "runtime").exists()


def test_component_analysis_fixes_app_and_vst3_destinations():
    records = [{"RootRelativeBundlePath": str(packaging.INSTALL_APP).lstrip("/"), "BundleIsRelocatable": True},
               {"RootRelativeBundlePath": str(packaging.INSTALL_VST3).lstrip("/"), "BundleIsRelocatable": True},
               {"RootRelativeBundlePath": "unrelated.bundle", "BundleIsRelocatable": True}]
    result = packaging.fix_component_plist(records)
    for value in result[:2]:
        assert value["BundleIsRelocatable"] is False
        assert value["BundleIsVersionChecked"] is False
        assert value["BundleHasStrictIdentifier"] is True
        assert value["BundleOverwriteAction"] == "upgrade"
    assert result[2]["BundleIsRelocatable"] is True
    with pytest.raises(ValueError):
        packaging.fix_component_plist(records[:1])


def test_distribution_requires_root_volume_arm64_and_macos12():
    root = ET.fromstring(packaging.distribution_xml("0.2.0", "component.pkg"))
    options = root.find("options")
    assert options.attrib["hostArchitectures"] == "arm64"
    assert options.attrib["rootVolumeOnly"] == "true"
    assert options.attrib["require-scripts"] == "false"
    domains = root.find("domains")
    assert domains.attrib == {"enable_anywhere": "false", "enable_currentUserHome": "false", "enable_localSystem": "true"}
    assert root.find("volume-check/allowed-os-versions/os-version").attrib["min"] == "12.0"
    package = root.findall("pkg-ref")[-1]
    assert package.attrib["auth"] == "Root" and package.text == "component.pkg"


def test_build_environment_does_not_use_foreign_python_or_user_library(tmp_path, monkeypatch):
    for name in ("PYTHONHOME", "PYTHONPATH", "PYTHONUSERBASE", "VIRTUAL_ENV", "CONDA_PREFIX",
                 "DYLD_LIBRARY_PATH", "DYLD_FRAMEWORK_PATH", "DYLD_FALLBACK_LIBRARY_PATH"):
        monkeypatch.setenv(name, "foreign-python")
    engine = tmp_path / "payload/Library/Application Support/Local MIDI/Engine"
    environment = packaging.build_environment(tmp_path, engine)
    assert environment["LOCALMIDI_MODELS"] == str(engine / ".models")
    assert Path(environment["LOCALMIDI_DATA"]).is_relative_to(tmp_path / "build-user-state")
    assert environment["PYTHONDONTWRITEBYTECODE"] == "1"
    assert environment["MACOSX_DEPLOYMENT_TARGET"] == "12.0"
    assert not any(name in environment for name in ("PYTHONHOME", "PYTHONPATH", "VIRTUAL_ENV", "DYLD_LIBRARY_PATH"))


def test_preview_samples_require_both_hashes(tmp_path):
    folder = tmp_path / "static/samples"
    folder.mkdir(parents=True)
    records = []
    for name in ("piano.json", "guitar.json"):
        (folder / name).write_text("{}", encoding="utf-8")
        records.append({"file": name, "sha256": packaging.digest(folder / name)})
    (folder / "manifest.json").write_text(json.dumps(records), encoding="utf-8")
    packaging.verify_samples(tmp_path)
    (folder / "piano.json").write_text('{"changed":true}', encoding="utf-8")
    with pytest.raises(ValueError, match="hash mismatch"):
        packaging.verify_samples(tmp_path)


def test_bundle_metadata_cannot_escape_its_macos_directory(tmp_path):
    info = tmp_path / "Local MIDI.app/Contents/Info.plist"
    info.parent.mkdir(parents=True)
    with info.open("wb") as stream:
        plistlib.dump({"CFBundleExecutable": "../elsewhere"}, stream)
    with pytest.raises(ValueError):
        packaging.bundle_executable(info.parents[1])
    with info.open("wb") as stream:
        plistlib.dump({"CFBundleExecutable": "Local MIDI"}, stream)
    assert packaging.bundle_executable(info.parents[1]) == info.parent / "MacOS/Local MIDI"


def test_bundle_verification_rejects_windows_binaries_and_wrong_macos_targets(tmp_path, monkeypatch):
    bundle = tmp_path / "Local MIDI.app"
    (bundle / "Contents/MacOS").mkdir(parents=True)
    with (bundle / "Contents/Info.plist").open("wb") as stream:
        plistlib.dump({"CFBundleExecutable": "Local MIDI"}, stream)
    binary = bundle / "Contents/MacOS/Local MIDI"
    binary.write_bytes(b"MZWindows")
    monkeypatch.setattr(packaging, "run", lambda *_args, **_kwargs: pytest.fail("Invalid binary reached Mac tools"))
    with pytest.raises(ValueError, match="not a Mac Mach-O"):
        packaging.verify_bundle(bundle)
    binary.write_bytes(bytes.fromhex("cffaedfe") + b"fixture")
    monkeypatch.setattr(packaging, "run", lambda *_args, **_kwargs: SimpleNamespace(stdout="x86_64"))
    with pytest.raises(ValueError, match="Expected a universal2"):
        packaging.verify_bundle(bundle)
    monkeypatch.setattr(packaging, "run", lambda arguments, **_kwargs: SimpleNamespace(stdout="arm64 x86_64" if "-archs" in arguments else "cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 2\nminos 14.0"))
    with pytest.raises(ValueError, match="does not target macOS"):
        packaging.verify_bundle(bundle)
    monkeypatch.setattr(packaging, "run", lambda arguments, **_kwargs: SimpleNamespace(stdout="arm64 x86_64" if "-archs" in arguments else "cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 12.0"))
    packaging.verify_bundle(bundle)


def test_runtime_minimum_os_matches_the_installer_promise():
    packaging.validate_macos_load_commands("cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 12.0.0", "fixture")
    packaging.validate_macos_load_commands("cmd LC_VERSION_MIN_MACOSX\ncmdsize 16\nversion 11.0", "fixture")
    with pytest.raises(ValueError, match="newer than the package"):
        packaging.validate_macos_load_commands("cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 14.0", "fixture")


def test_runtime_pin_and_entitlements_are_explicit():
    macos = ROOT / "native/macos"
    manifest = json.loads((macos / "python-runtime.json").read_text(encoding="utf-8"))
    assert manifest["architecture"] == "arm64"
    assert manifest["python"] == "3.12.12" and manifest["release"] == "20251031"
    assert manifest["sha256"] == "5e110cb821d2eb8246065d3b46faa655180c976c4e17250f7883c634a629bc63"
    assert "aarch64-apple-darwin-install_only" in manifest["url"]
    with (macos / "app.entitlements.plist").open("rb") as stream:
        app = plistlib.load(stream)
    with (macos / "engine.entitlements.plist").open("rb") as stream:
        engine = plistlib.load(stream)
    assert app == {"com.apple.security.device.audio-input": True}
    assert engine["com.apple.security.cs.allow-jit"] is True
    assert engine["com.apple.security.cs.disable-library-validation"] is True
    assert "com.apple.security.app-sandbox" not in app and "com.apple.security.app-sandbox" not in engine


def test_plan_does_not_invoke_platform_tools(monkeypatch, capsys):
    monkeypatch.setattr(packaging, "build", lambda _args: pytest.fail("Plan invoked a build"))
    assert packaging.main(["--plan", "--arch", "arm64"]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["engine"] == str(packaging.INSTALL_ENGINE)
    assert result["app"] == str(packaging.INSTALL_APP)


def test_mac_requirement_profile_preserves_shared_windows_pins():
    common_path = ROOT / "requirements.txt"
    original = common_path.read_bytes()
    common = original.decode("utf-8")
    overrides = (ROOT / "native/macos/requirements-macos.txt").read_text(encoding="utf-8")
    effective = packaging.effective_macos_requirements(common, overrides)
    assert "onnxruntime==1.31.0" in common
    assert "onnxruntime==1.31.0" not in effective
    assert "onnxruntime==1.19.2" in effective
    assert "scipy==1.16.1" in effective and "numpy==1.26.4" in effective
    assert common_path.read_bytes() == original
    common_dependencies = [line for line in common.splitlines() if line.strip() and not line.startswith("#")]
    mac_dependencies = [line for line in effective.splitlines() if line.strip() and not line.startswith("#")]
    assert mac_dependencies == ["onnxruntime==1.19.2" if line == "onnxruntime==1.31.0" else line for line in common_dependencies]


@pytest.mark.parametrize("overrides", ["untracked==1.0", "onnxruntime>=1.19", "onnxruntime==1\nonnxruntime==2"])
def test_mac_requirement_overrides_reject_ambiguous_or_untracked_pins(overrides):
    with pytest.raises(ValueError):
        packaging.effective_macos_requirements("onnxruntime==1.31.0\n", overrides)


def test_lower_target_propagates_through_build_metadata_and_binary_audit(tmp_path, monkeypatch):
    # Keep the policy in one constant; future changes cannot leave a hidden 14.0 gate.
    monkeypatch.setattr(packaging, "MINIMUM_MACOS", (13, 0))
    commands = []
    monkeypatch.setattr(packaging, "run", lambda arguments, **kwargs: commands.append(list(map(str, arguments))))
    packaging.native_build(tmp_path, tmp_path / "native", 2)
    assert "-DCMAKE_OSX_DEPLOYMENT_TARGET=13.0" in commands[0]
    assert packaging.build_environment(tmp_path, tmp_path / "Engine")["MACOSX_DEPLOYMENT_TARGET"] == "13.0"
    assert packaging.installation_plan("0.2.0")["minimum_macos"] == "13.0"
    distribution = ET.fromstring(packaging.distribution_xml("0.2.0", "fixture.pkg"))
    assert distribution.find("volume-check/allowed-os-versions/os-version").attrib["min"] == "13.0"
    options = packaging.compatible_wheel_options()
    assert options[options.index("--platform") + 1] == "macosx_13_0_arm64"
    packaging.validate_host("Darwin", "arm64", "13.0")
    with pytest.raises(ValueError, match="13.0"):
        packaging.validate_host("Darwin", "arm64", "12.0")
    packaging.validate_macos_load_commands("cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 13.0", "fixture")
    with pytest.raises(ValueError, match="13.0 minimum"):
        packaging.validate_macos_load_commands("cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 14.0", "fixture")


def pure_wheel(path, pure=True, tag="py3-none-any", native_file=False):
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("sox-1.5.0.dist-info/WHEEL", "Wheel-Version: 1.0\nRoot-Is-Purelib: " + str(pure).lower() + "\nTag: " + tag + "\n")
        archive.writestr("sox/__init__.py", "")
        if native_file:
            archive.writestr("sox/binary.so", b"fixture")


def test_source_only_dependency_must_produce_a_real_pure_python_wheel(tmp_path):
    path = tmp_path / "sox-1.5.0-py3-none-any.whl"
    pure_wheel(path)
    packaging.verify_pure_python_wheel(path)
    for options in ({"pure": False}, {"tag": "cp312-cp312-macosx_14_0_arm64"}, {"native_file": True}):
        pure_wheel(path, **options)
        with pytest.raises(ValueError, match="pure Python|native binary"):
            packaging.verify_pure_python_wheel(path)
    native = tmp_path / "sox-1.5.0-cp312-cp312-macosx_14_0_arm64.whl"
    pure_wheel(native)
    with pytest.raises(ValueError, match="portable pure-Python"):
        packaging.verify_pure_python_wheel(native)


def test_dependencies_resolve_for_macos12_and_install_from_only_that_wheelhouse(tmp_path, monkeypatch):
    repository, stage = tmp_path / "repository", tmp_path / "stage"
    engine = stage / "payload/Engine"
    (repository / "static/juce").mkdir(parents=True)
    for name in ("index.js", "check_native_interop.js"):
        (repository / "static/juce" / name).write_text("fixture", encoding="utf-8")
    (engine / "static/samples").mkdir(parents=True)
    for name in ("piano.json", "guitar.json", "manifest.json"):
        (engine / "static/samples" / name).write_text("{}", encoding="utf-8")
    (engine / "requirements.txt").write_text("onnxruntime==1.19.2\n", encoding="utf-8")
    monkeypatch.setattr(packaging, "download_runtime", lambda *_args: tmp_path / "runtime.tar.gz")
    def extracted(_archive, runtime):
        (runtime / "bin").mkdir(parents=True)
        (runtime / "bin/python3").write_text("fixture", encoding="utf-8")
    monkeypatch.setattr(packaging, "extract_python", extracted)
    monkeypatch.setattr(packaging, "verify_samples", lambda _engine: None)
    monkeypatch.setattr(packaging, "verify_target_interpreter", lambda *_args: None)
    commands = []
    def run(arguments, **kwargs):
        arguments = list(map(str, arguments))
        commands.append((arguments, kwargs))
        if "wheel" in arguments:
            wheelhouse = Path(arguments[arguments.index("--wheel-dir") + 1])
            pure_wheel(wheelhouse / "sox-1.5.0-py3-none-any.whl")
        return SimpleNamespace(stdout="/bundled/certificate.pem\n")
    monkeypatch.setattr(packaging, "run", run)
    packaging.prepare_dependencies(repository, stage, engine, {"architecture": "arm64"}, tmp_path / "downloads")
    downloads = [(args, kwargs) for args, kwargs in commands if "download" in args]
    installs = [(args, kwargs) for args, kwargs in commands if "install" in args]
    assert len(downloads) == len(installs) == 3
    for args, kwargs in downloads:
        assert args[args.index("--platform") + 1] == "macosx_12_0_arm64"
        assert args[args.index("--python-version") + 1] == "3.12"
        assert args[args.index("--implementation") + 1] == "cp"
        assert args[args.index("--abi") + 1] == "cp312"
        assert "--only-binary=:all:" in args
        assert args[args.index("--dest") + 1] == str(stage / "wheelhouse")
        assert kwargs["env"]["MACOSX_DEPLOYMENT_TARGET"] == "12.0"
    for args, _kwargs in installs:
        assert "--no-index" in args and "--index-url" not in args
        assert args[args.index("--find-links") + 1] == str(stage / "wheelhouse")
        assert "--only-binary=:all:" in args
    assert "--no-deps" in downloads[-1][0] and "--no-deps" in installs[-1][0]
    assert "transkun==2.0.1" in installs[-1][0] and "basic-pitch==0.4.0" in installs[-1][0]
    source_builds = [args for args, _kwargs in commands if "wheel" in args]
    assert len(source_builds) == 1 and source_builds[0][-1] == "sox==1.5.0"
    assert "--no-deps" in source_builds[0] and "--no-build-isolation" in source_builds[0]


def test_native_build_always_produces_universal2_wrappers(tmp_path, monkeypatch):
    commands = []
    monkeypatch.setattr(packaging, "run", lambda arguments, **_kwargs: commands.append(list(map(str, arguments))))
    packaging.native_build(tmp_path, tmp_path / "native", 2)
    assert "-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64" in commands[0]
    assert "-DCMAKE_OSX_DEPLOYMENT_TARGET=12.0" in commands[0]


def test_architecture_selection_uses_physical_cpu_even_under_rosetta():
    assert packaging.validate_host("Darwin", "arm64", "12.0") == "arm64"
    assert packaging.validate_host("Darwin", "x86_64", "12.0") == "x86_64"
    assert packaging.validate_host("Darwin", "x86_64", "12.0", translated=True) == "arm64"
    assert packaging.validate_host("Darwin", "arm64", "12.0", architecture="x86_64") == "x86_64"
    with pytest.raises(ValueError, match="cannot execute"):
        packaging.validate_host("Darwin", "x86_64", "12.0", architecture="arm64")
    with pytest.raises(ValueError, match="Unsupported Mac architecture"):
        packaging.architecture_profile("i386")


@pytest.mark.parametrize("architecture,torch", [("arm64", "2.5.1"), ("x86_64", "2.2.2")])
def test_each_package_plan_and_distribution_match_its_engine(architecture, torch):
    plan = packaging.installation_plan("0.2.0", architecture)
    assert plan["architecture"] == architecture
    assert plan["torch"] == plan["torchaudio"] == torch
    assert plan["native_wrapper_architectures"] == ["arm64", "x86_64"]
    root = ET.fromstring(packaging.distribution_xml("0.2.0", "fixture.pkg", architecture))
    assert root.find("options").attrib["hostArchitectures"] == architecture
    assert root.find("volume-check/allowed-os-versions/os-version").attrib["min"] == "12.0"
    options = packaging.compatible_wheel_options(architecture)
    assert options[options.index("--platform") + 1] == "macosx_12_0_" + architecture


def test_auto_plan_lists_both_packages_without_invoking_mac_tools(monkeypatch, capsys):
    monkeypatch.setattr(packaging, "build", lambda _args: pytest.fail("Plan invoked a build"))
    assert packaging.main(["--plan"]) == 0
    result = json.loads(capsys.readouterr().out)
    assert {plan["architecture"] for plan in result["packages"]} == {"arm64", "x86_64"}
    assert packaging.main(["--plan", "--arch", "x86_64"]) == 0
    assert json.loads(capsys.readouterr().out)["architecture"] == "x86_64"


def test_intel_python_manifest_is_independently_pinned():
    macos = ROOT / "native/macos"
    arm = json.loads((macos / "python-runtime.json").read_text())
    intel = json.loads((macos / "python-runtime-x86_64.json").read_text())
    assert arm["architecture"] == "arm64" and intel["architecture"] == "x86_64"
    assert intel["python"] == arm["python"] == "3.12.12"
    assert intel["sha256"] == "687052a046d33be49dc95dd671816709067cf6176ed36c93ea61b1fe0b883b0f"
    assert intel["sha256"] != arm["sha256"]
    assert "x86_64-apple-darwin-install_only" in intel["url"]


def test_intel_profile_records_constraints_without_changing_shared_pins():
    common = (ROOT / "requirements.txt").read_text()
    shared_override = (ROOT / "native/macos/requirements-macos.txt").read_text()
    intel_constraints = (ROOT / "native/macos/requirements-macos-x86_64.txt").read_text()
    arm = packaging.effective_macos_requirements(common, shared_override)
    intel = packaging.effective_macos_requirements(arm, intel_constraints, allow_new=True)
    assert "onnxruntime==1.31.0" in common
    assert "onnxruntime==1.19.2" in arm and "onnxruntime==1.19.2" in intel
    for pin in ("numba==0.62.1", "llvmlite==0.45.1", "scikit-learn==1.7.2", "pandas==2.3.3", "matplotlib==3.10.8"):
        assert pin in intel
    assert "numba==0.62.1" not in arm and "matplotlib>=3.8,<4" in arm
    assert "ncls==0.0.70" in arm and "ncls==0.0.70" in intel


def test_target_interpreter_must_actually_execute_with_expected_cpu(monkeypatch):
    monkeypatch.setattr(packaging, "run", lambda *_args, **_kwargs: SimpleNamespace(stdout='{"architecture":"x86_64","platform":"darwin"}\n'))
    packaging.verify_target_interpreter("python", {}, "x86_64")
    with pytest.raises(ValueError, match="does not match"):
        packaging.verify_target_interpreter("python", {}, "arm64")
    def failure(*_args, **_kwargs): raise OSError("Bad CPU type in executable")
    monkeypatch.setattr(packaging, "run", failure)
    with pytest.raises(ValueError, match="Rosetta already installed"):
        packaging.verify_target_interpreter("python", {}, "x86_64")


def test_universal_wrappers_are_audited_in_both_architectures(tmp_path, monkeypatch):
    bundle = tmp_path / "Local MIDI.vst3"
    (bundle / "Contents/MacOS").mkdir(parents=True)
    with (bundle / "Contents/Info.plist").open("wb") as output:
        plistlib.dump({"CFBundleExecutable": "Local MIDI"}, output)
    (bundle / "Contents/MacOS/Local MIDI").write_bytes(bytes.fromhex("cffaedfe") + b"fixture")
    calls = []
    def run(arguments, **_kwargs):
        calls.append(arguments)
        return SimpleNamespace(stdout="x86_64 arm64" if "-archs" in arguments else "cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 12.0")
    monkeypatch.setattr(packaging, "run", run)
    packaging.verify_bundle(bundle)
    assert {args[args.index("-arch") + 1] for args in calls if "-arch" in args} == {"arm64", "x86_64"}
    def unsupported_intel(arguments, **kwargs):
        result = run(arguments, **kwargs)
        if "-arch" in arguments and arguments[arguments.index("-arch") + 1] == "x86_64":
            return SimpleNamespace(stdout="cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 14.0")
        return result
    monkeypatch.setattr(packaging, "run", unsupported_intel)
    with pytest.raises(ValueError, match="newer than the package"):
        packaging.verify_bundle(bundle)


@pytest.mark.parametrize("architecture", ["arm64", "x86_64"])
def test_runtime_audit_selects_only_the_used_slice(tmp_path, monkeypatch, architecture):
    (tmp_path / "library.dylib").write_bytes(bytes.fromhex("cffaedfe") + b"fixture")
    calls = []
    def run(arguments, **_kwargs):
        calls.append(arguments)
        return SimpleNamespace(stdout="arm64 x86_64" if "-archs" in arguments else "cmd LC_BUILD_VERSION\ncmdsize 32\nplatform 1\nminos 12.0")
    monkeypatch.setattr(packaging, "run", run)
    packaging.verify_runtime_targets(tmp_path, architecture)
    assert [args[args.index("-arch") + 1] for args in calls if "-arch" in args] == [architecture]
    monkeypatch.setattr(packaging, "run", lambda *_args, **_kwargs: SimpleNamespace(stdout="other"))
    with pytest.raises(ValueError, match="has no " + architecture):
        packaging.verify_runtime_targets(tmp_path, architecture)


def ncls_wheel(path, tag="cp312-cp312-macosx_12_0_x86_64", binary=True):
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("ncls-0.0.70.dist-info/WHEEL", "Wheel-Version: 1.0\nRoot-Is-Purelib: false\nTag: " + tag + "\n")
        if binary:
            archive.writestr("ncls/cncls.cpython-312-darwin.so", bytes.fromhex("cffaedfe") + b"fixture")


def test_ncls_source_wheel_requires_matching_cpu_minimum_and_native_extension(tmp_path):
    wheel = tmp_path / "ncls-0.0.70-cp312-cp312-macosx_12_0_x86_64.whl"
    ncls_wheel(wheel)
    packaging.verify_ncls_wheel(wheel, "x86_64")
    for options in ({"tag": "cp312-cp312-macosx_12_0_arm64"}, {"tag": "cp312-cp312-macosx_14_0_x86_64"}, {"binary": False}):
        ncls_wheel(wheel, **options)
        with pytest.raises(ValueError):
            packaging.verify_ncls_wheel(wheel, "x86_64")


def test_intel_dependency_bootstrap_builds_only_pinned_native_source(tmp_path, monkeypatch):
    repository, stage = tmp_path / "repo", tmp_path / "stage"
    engine = stage / "payload/Engine"
    for folder in (repository / "static/juce", engine / "static/samples"):
        folder.mkdir(parents=True)
    for name in ("index.js", "check_native_interop.js"):
        (repository / "static/juce" / name).write_text("fixture")
    for name in ("piano.json", "guitar.json", "manifest.json"):
        (engine / "static/samples" / name).write_text("{}")
    (engine / "requirements.txt").write_text("onnxruntime==1.19.2\n")
    monkeypatch.setattr(packaging, "download_runtime", lambda *_args: tmp_path / "archive")
    monkeypatch.setattr(packaging, "extract_python", lambda *_args: None)
    monkeypatch.setattr(packaging, "verify_target_interpreter", lambda *_args: None)
    monkeypatch.setattr(packaging, "verify_samples", lambda *_args: None)
    source_calls = []
    monkeypatch.setattr(packaging, "build_intel_ncls_wheel", lambda *args: source_calls.append(args))
    commands = []
    def run(arguments, **kwargs):
        args = list(map(str, arguments));commands.append((args, kwargs))
        if "wheel" in args:
            pure_wheel(Path(args[args.index("--wheel-dir") + 1]) / "sox-1.5.0-py3-none-any.whl")
        return SimpleNamespace(stdout="certificate.pem\n")
    monkeypatch.setattr(packaging, "run", run)
    packaging.prepare_dependencies(repository, stage, engine, {"architecture": "x86_64"}, tmp_path / "downloads", "x86_64")
    downloads = [args for args, _kwargs in commands if "download" in args]
    assert all(args[args.index("--platform") + 1] == "macosx_12_0_x86_64" for args in downloads)
    assert "numpy==1.26.4" in downloads[0] and "Cython==3.0.12" in downloads[0] and "setuptools_scm==8.1.0" in downloads[0]
    assert "torch==2.2.2" in downloads[1] and "torchaudio==2.2.2" in downloads[1]
    assert len(source_calls) == 1
    assert source_calls[0][-1]["ARCHFLAGS"] == "-arch x86_64"
    assert source_calls[0][-1]["MACOSX_DEPLOYMENT_TARGET"] == "12.0"


def test_cached_ncls_source_hash_is_verified_before_code_runs(tmp_path, monkeypatch):
    downloads = tmp_path / "downloads";downloads.mkdir()
    (downloads / packaging.NCLS_SOURCE["archive"]).write_bytes(b"incorrect source")
    monkeypatch.setattr(packaging, "run", lambda *_args, **_kwargs: pytest.fail("Unverified source executed"))
    with pytest.raises(ValueError, match="checksum mismatch"):
        packaging.build_intel_ncls_wheel("python", tmp_path / "wheelhouse", downloads, {})
