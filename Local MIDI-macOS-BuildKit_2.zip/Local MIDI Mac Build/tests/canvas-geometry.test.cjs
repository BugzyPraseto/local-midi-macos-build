const {test}=require('node:test');
const assert=require('node:assert/strict');
const {roundRect}=require('../static/canvas-geometry.js');

test('supported browsers keep their native rounded-rectangle path',()=>{
  let actual;const path={roundRect:(...args)=>{actual=args;}};
  assert.equal(roundRect(path,10,20,30,18,3),path);
  assert.deepEqual(actual,[10,20,30,18,3]);
});

test('older WebKit draws closed circular corners with the same note bounds',()=>{
  const calls=[],path={};
  for(const name of ['moveTo','lineTo','arcTo','closePath'])path[name]=(...args)=>calls.push([name,...args]);
  roundRect(path,10,20,30,18,3);
  assert.deepEqual(calls,[['moveTo',13,20],['lineTo',37,20],['arcTo',40,20,40,23,3],
    ['lineTo',40,35],['arcTo',40,38,37,38,3],['lineTo',13,38],
    ['arcTo',10,38,10,35,3],['lineTo',10,23],['arcTo',10,20,13,20,3],['closePath']]);
});

test('fallback clamps corners on narrow notes and uses a rectangle for zero radius',()=>{
  const arcs=[],path={moveTo(){},lineTo(){},arcTo(...args){arcs.push(args);},closePath(){},rect(...args){this.rectangle=args;}};
  roundRect(path,0,0,2,20,4);assert.equal(arcs.length,4);assert.ok(arcs.every(args=>args[4]===1));
  roundRect(path,0,0,10,18,0);assert.deepEqual(path.rectangle,[0,0,10,18]);
});
