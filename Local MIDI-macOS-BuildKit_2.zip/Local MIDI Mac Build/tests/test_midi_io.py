from io import BytesIO

import mido
import pytest

from localmidi.midi_io import midi_bytes


def messages(content):
    return list(mido.MidiFile(file=BytesIO(content)))


def test_export_preserves_silence_velocity_pedal_and_bend():
    note = {"start": 1.25, "end": 2.75, "pitch": 60, "velocity": 53, "track": 0, "program": 0}
    result = messages(midi_bytes([note], [{"time": 1, "number": 64, "value": 127, "track": 0},
                                        {"time": 3, "number": 64, "value": 0, "track": 0}],
                               [{"time": 1.5, "pitch": 1200, "track": 0}], bpm=93))
    clock = 0
    events = []
    for event in result:
        clock += event.time
        events.append((clock, event))
    on_time, on = next((time, event) for time, event in events if event.type == "note_on")
    off_time, _ = next((time, event) for time, event in events if event.type == "note_off")
    assert on_time == pytest.approx(1.25, abs=.001)
    assert off_time == pytest.approx(2.75, abs=.001)
    assert on.velocity == 53
    assert [event.value for _, event in events if event.type == "control_change"] == [127, 0]
    assert next(event.pitch for _, event in events if event.type == "pitchwheel") == 1200


def test_quantization_is_optional_and_does_not_mutate_notes():
    note = {"start": .17, "end": .44, "pitch": 64, "velocity": 80}
    grid = midi_bytes([note], bpm=120, quantize=True, subdivision=16)
    clock = 0
    times = []
    for event in messages(grid):
        clock += event.time
        if event.type in ("note_on", "note_off"):
            times.append(clock)
    assert times == pytest.approx([.125, .5])
    assert note["start"] == .17
    assert note["end"] == .44


def test_repeated_notes_turn_off_before_next_attack():
    notes = [{"start": 0, "end": .5, "pitch": 60, "velocity": 60},
             {"start": .5, "end": 1, "pitch": 60, "velocity": 100}]
    events = [event.type for event in messages(midi_bytes(notes)) if event.type in ("note_on", "note_off")]
    assert events == ["note_on", "note_off", "note_on", "note_off"]


def test_deleting_all_notes_retains_controller_tracks():
    events = messages(midi_bytes([], [{"time": 2.5, "number": 64, "value": 0, "track": 2}],
                                 [{"time": 1, "pitch": 300, "track": 3}]))
    assert next(event.value for event in events if event.type == "control_change") == 0
    assert next(event.pitch for event in events if event.type == "pitchwheel") == 300


def test_selected_export_shifts_notes_and_reconstructs_pedal_and_bend_state():
    note = {"start": 5, "end": 6, "pitch": 60, "velocity": 74, "track": 0}
    controls = [{"time": 1, "number": 64, "value": 127, "track": 0},
                {"time": 7, "number": 64, "value": 0, "track": 0},
                {"time": 30, "number": 64, "value": 127, "track": 0},
                {"time": 2, "number": 64, "value": 127, "track": 3}]
    bends = [{"time": 2, "pitch": 800, "track": 0},
             {"time": 5.5, "pitch": 1200, "track": 0},
             {"time": 20, "pitch": 0, "track": 0},
             {"time": 1, "pitch": 300, "track": 3}]
    clock = 0
    events = []
    for event in messages(midi_bytes([note], controls, bends, selection_only=True, start_at_first_note=True)):
        clock += event.time
        events.append((clock, event))
    assert [(time, event.note) for time, event in events if event.type == "note_on"] == [(0, 60)]
    assert [(time, event.note) for time, event in events if event.type == "note_off"] == [(1, 60)]
    assert [(time, event.value) for time, event in events if event.type == "control_change"] == [(0, 127), (2, 0)]
    assert [(time, event.pitch) for time, event in events if event.type == "pitchwheel"] == [(0, 800), (.5, 1200), (2, 0)]
    assert clock == 2
    assert note["start"] == 5 and controls[0]["time"] == 1


def test_selected_export_can_keep_source_position_and_releases_unclosed_pedal():
    note = {"start": 5, "end": 6, "pitch": 62, "velocity": 74}
    events = messages(midi_bytes([note], [{"time": 1, "number": 64, "value": 127}], selection_only=True))
    clock = 0
    on, releases = [], []
    for event in events:
        clock += event.time
        if event.type == "note_on":
            on.append(clock)
        if event.type == "control_change" and event.value == 0:
            releases.append(clock)
    assert on == [5]
    assert releases == [6]


def test_empty_selection_does_not_export_unrelated_controller_tracks():
    events = messages(midi_bytes([], [{"time": 90, "number": 64, "value": 127}], selection_only=True))
    assert not any(event.type in ("note_on", "control_change", "pitchwheel") for event in events)

