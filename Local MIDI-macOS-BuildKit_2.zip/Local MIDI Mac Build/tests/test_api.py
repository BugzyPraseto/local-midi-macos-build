from io import BytesIO
import os
from pathlib import Path
import tempfile
import mido

import numpy as np
import soundfile as sf
from fastapi.testclient import TestClient

# These API tests use a separate directory and never transcribe user audio.
temporary = tempfile.TemporaryDirectory(prefix="local-midi-tests-")
os.environ["LOCALMIDI_DATA"] = temporary.name
from localmidi.app import app
from localmidi.paths import DATA
from localmidi.midi_io import midi_bytes


def test_import_reference_edit_restore_and_export_preserves_raw_prediction():
    with TestClient(app) as client:
        buffer = BytesIO()
        sf.write(buffer, np.zeros(32000, dtype=np.float32), 16000, format="WAV")
        response = client.post("/api/audio", files={"file": ("silence.wav", buffer.getvalue(), "audio/wav")})
        assert response.status_code == 200
        audio = response.json()
        assert audio["duration"] == 2
        raw = midi_bytes([{"start": .5, "end": 1.25, "pitch": 60, "velocity": 80}])
        reference = client.post(f"/api/audio/{audio['id']}/reference", files={"file": ("reference.mid", raw)})
        assert reference.status_code == 200
        job = reference.json()["id"]
        original = client.get(f"/api/jobs/{job}/result").json()
        edited = [dict(original["notes"][0], pitch=67, velocity=43)]
        assert client.put(f"/api/jobs/{job}/notes", json={"notes": edited}).status_code == 200
        assert client.get(f"/api/jobs/{job}/result").json()["notes"][0]["pitch"] == 67
        assert client.get(f"/api/jobs/{job}/prediction").json()["notes"][0]["pitch"] == 60
        assert client.get(f"/api/jobs/{job}/result").json()["notes"][0]["pitch"] == 67
        assert client.get(f"/api/jobs/{job}/raw.mid").content == raw
        export = client.post(f"/api/jobs/{job}/export", json={"notes": edited, "bpm": 97, "quantize": False})
        assert export.status_code == 200 and export.content.startswith(b"MThd")
        selection = client.post(f"/api/jobs/{job}/export", json={"notes": edited,
                                "selection_only": True, "start_at_first_note": True})
        assert selection.status_code == 200
        clock = 0
        attacks = []
        for event in mido.MidiFile(file=BytesIO(selection.content)):
            clock += event.time
            if event.type == "note_on":
                attacks.append((clock, event.note))
        assert attacks == [(0, 67)]
        restored = client.post(f"/api/jobs/{job}/restore").json()
        assert restored["notes"][0]["pitch"] == 60
        invalid = [dict(edited[0], end=.1)]
        assert client.put(f"/api/jobs/{job}/notes", json={"notes": invalid}).status_code == 422
        assert client.get("/api/audio/not-a-valid-id").status_code == 404


def test_native_capture_import_is_confined_and_idempotent():
    capture_id = "a" * 32
    captures = DATA / "native-captures"
    captures.mkdir(exist_ok=True)
    sf.write(captures / (capture_id + ".wav"), np.zeros((16000, 2), np.float32), 16000)
    with TestClient(app) as client:
        assert client.get("/api/health").json()["native_protocol"] == 1
        response = client.post(f"/api/native/captures/{capture_id}/import",
                               json={"name": "Native capture.wav", "host_start_seconds": 12.5})
        assert response.status_code == 200
        result = response.json()
        assert result["id"] == capture_id and result["host_start_seconds"] == 12.5
        assert result["duration"] == 1 and result["channels"] == 2
        assert client.post(f"/api/native/captures/{capture_id}/import", json={}).json()["id"] == capture_id
        assert client.post("/api/native/captures/not-a-valid-id/import", json={}).status_code == 404
        assert client.post(f"/api/native/captures/{'b' * 32}/import", json={}).status_code == 404

