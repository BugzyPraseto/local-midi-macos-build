"""Installer upgrades must never merge different native Python runtimes."""
import importlib.util
import json
from pathlib import Path

import pytest

SPEC = importlib.util.spec_from_file_location("mac_layout", Path(__file__).resolve().parents[1] / "native/macos/build_installer.py")
layout = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(layout)


@pytest.mark.parametrize("architecture", ["arm64", "x86_64"])
def test_runtime_tree_is_unique_and_has_a_relocatable_current_link(tmp_path, monkeypatch, architecture):
    engine = tmp_path / "Engine"
    runtime = engine / "runtime"
    (runtime / "bin").mkdir(parents=True)
    (runtime / "bin/python3").write_bytes(b"fixture")
    calls = []
    def create_link(path, target, target_is_directory=False):
        calls.append((path, target, target_is_directory))
    monkeypatch.setattr(Path, "symlink_to", create_link)
    relative = layout.isolate_runtime_payload(engine, architecture)
    assert relative.startswith("runtimes/" + architecture + "-torch")
    assert (engine / relative / "bin/python3").read_bytes() == b"fixture"
    assert calls == [(runtime / "bin/python3", Path("../..") / relative / "bin/python3", False)]
    assert not Path(relative).is_absolute()
    assert json.loads((engine / "architecture-profile.json").read_text())["runtime_directory"] == relative


def test_link_failure_restores_the_staged_runtime(tmp_path, monkeypatch):
    runtime = tmp_path / "Engine/runtime"
    runtime.mkdir(parents=True)
    (runtime / "marker").write_text("original")
    def failed_link(*args, **kwargs): raise OSError("injected link failure")
    monkeypatch.setattr(Path, "symlink_to", failed_link)
    with pytest.raises(OSError, match="injected"):
        layout.isolate_runtime_payload(runtime.parent, "x86_64")
    assert (runtime / "marker").read_text() == "original"


def test_missing_runtime_cannot_reuse_an_old_installation(tmp_path):
    with pytest.raises(ValueError, match="fresh"):
        layout.isolate_runtime_payload(tmp_path / "Engine", "arm64")
